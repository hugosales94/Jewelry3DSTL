<?php
session_start();

// Define the base path correctly
define('BASE_PATH', dirname(__DIR__));

// Create required directories if they don't exist
$directories = [
    BASE_PATH . '/logs',
    BASE_PATH . '/install/views',
    BASE_PATH . '/views/errors'
];

foreach ($directories as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0755, true);
    }
}

// Create log files if they don't exist
$logFiles = [
    BASE_PATH . '/logs/error.log',
    BASE_PATH . '/logs/php_errors.log'
];

foreach ($logFiles as $file) {
    if (!file_exists($file)) {
        touch($file);
        chmod($file, 0644);
    }
}

// Check if already installed
if (file_exists(BASE_PATH . '/install.lock')) {
    header('Location: /');
    exit();
}

$step = $_GET['step'] ?? 'welcome';

// Ensure the view file exists before including
$viewFile = __DIR__ . '/views/' . $step . '.php';
if (!file_exists($viewFile)) {
    header('Location: ?step=welcome');
    exit();
}

require_once $viewFile;

