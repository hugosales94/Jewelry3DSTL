<?php
// This script should be run once to set up proper permissions
$baseDir = dirname(__DIR__);

// Function to recursively chmod directories and files
function setPermissions($path, $dirPermission, $filePermission) {
    if (is_dir($path)) {
        chmod($path, $dirPermission);
        $objects = scandir($path);
        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
                $fullPath = $path . DIRECTORY_SEPARATOR . $object;
                if (is_dir($fullPath)) {
                    setPermissions($fullPath, $dirPermission, $filePermission);
                } else {
                    chmod($fullPath, $filePermission);
                }
            }
        }
    }
}

// Create required directories if they don't exist
$directories = [
    $baseDir . '/logs',
    $baseDir . '/install/views',
    $baseDir . '/views/errors',
    $baseDir . '/public_html/uploads'
];

foreach ($directories as $dir) {
    if (!file_exists($dir)) {
        mkdir($dir, 0755, true);
        echo "Created directory: $dir\n";
    }
}

// Set permissions
setPermissions($baseDir . '/public_html', 0755, 0644);
setPermissions($baseDir . '/logs', 0755, 0644);
setPermissions($baseDir . '/install', 0755, 0644);

// Ensure log files exist and are writable
$logFiles = [
    $baseDir . '/logs/error.log',
    $baseDir . '/logs/php_errors.log'
];

foreach ($logFiles as $file) {
    if (!file_exists($file)) {
        touch($file);
        chmod($file, 0644);
        echo "Created log file: $file\n";
    }
}

echo "Permissions set successfully!\n";

