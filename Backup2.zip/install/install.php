<?php
if (!defined('BASE_PATH')) {
    exit('No direct script access allowed');
}

$step = $_GET['step'] ?? 'welcome';

switch ($step) {
    case 'welcome':
        require_once BASE_PATH . '/install/views/welcome.php';
        break;
    case 'requirements':
        require_once BASE_PATH . '/install/views/requirements.php';
        break;
    case 'database':
        require_once BASE_PATH . '/install/views/database.php';
        break;
    case 'finish':
        require_once BASE_PATH . '/install/views/finish.php';
        break;
    default:
        header('Location: ?step=welcome');
        exit();
}

