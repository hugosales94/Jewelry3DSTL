<?php
// Initialize session for error messages
session_start();

// Function to test database connection
function testDatabaseConnection($host, $user, $pass, $name) {
    try {
        $conn = new mysqli($host, $user, $pass);
        if ($conn->connect_error) {
            throw new Exception($conn->connect_error);
        }
        
        // Try to create database if it doesn't exist
        $conn->query("CREATE DATABASE IF NOT EXISTS `" . $name . "`");
        
        // Try to select the database
        if (!$conn->select_db($name)) {
            throw new Exception("Unable to select database");
        }
        
        return true;
    } catch (Exception $e) {
        return $e->getMessage();
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = $_POST['db_host'] ?? '';
    $db_name = $_POST['db_name'] ?? '';
    $db_user = $_POST['db_user'] ?? '';
    $db_pass = $_POST['db_pass'] ?? '';
    
    $result = testDatabaseConnection($db_host, $db_user, $db_pass, $db_name);
    
    if ($result === true) {
        // Save configuration to .env file
        $envContent = "DB_HOST={$db_host}\n";
        $envContent .= "DB_NAME={$db_name}\n";
        $envContent .= "DB_USER={$db_user}\n";
        $envContent .= "DB_PASS={$db_pass}\n";
        
        $envFile = dirname(__DIR__, 2) . '/.env';
        if (file_put_contents($envFile, $envContent)) {
            header('Location: ?step=finish');
            exit;
        } else {
            $_SESSION['error'] = "Não foi possível salvar as configurações no arquivo .env";
        }
    } else {
        $_SESSION['error'] = "Erro de conexão: " . $result;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuração do Banco de Dados - STL Jewelry 3D</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-body p-5">
                        <h1 class="text-center mb-4">Configuração do Banco de Dados</h1>
                        
                        <?php if (isset($_SESSION['error'])): ?>
                            <div class="alert alert-danger">
                                <?php 
                                echo htmlspecialchars($_SESSION['error']);
                                unset($_SESSION['error']);
                                ?>
                            </div>
                        <?php endif; ?>

                        <form method="post" action="?step=database">
                            <div class="mb-3">
                                <label for="db_host" class="form-label">Host do Banco de Dados</label>
                                <input type="text" class="form-control" id="db_host" name="db_host" value="localhost" required>
                                <div class="form-text">Geralmente é "localhost"</div>
                            </div>

                            <div class="mb-3">
                                <label for="db_name" class="form-label">Nome do Banco de Dados</label>
                                <input type="text" class="form-control" id="db_name" name="db_name" required>
                            </div>

                            <div class="mb-3">
                                <label for="db_user" class="form-label">Usuário do Banco de Dados</label>
                                <input type="text" class="form-control" id="db_user" name="db_user" required>
                            </div>

                            <div class="mb-3">
                                <label for="db_pass" class="form-label">Senha do Banco de Dados</label>
                                <input type="password" class="form-control" id="db_pass" name="db_pass" required>
                            </div>

                            <div class="alert alert-info">
                                <strong>Dica:</strong> Estas informações devem ser fornecidas pelo seu provedor de hospedagem.
                                Se você estiver usando o Hostinger, você pode encontrá-las no painel de controle do MySQL.
                            </div>

                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-primary btn-lg">Testar Conexão e Continuar</button>
                                <a href="?step=requirements" class="btn btn-link">Voltar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

