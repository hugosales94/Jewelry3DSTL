<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalação - STL Jewelry 3D</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-body text-center p-5">
                        <h1 class="mb-4">Bem-vindo à Instalação</h1>
                        <p class="lead mb-4">Este assistente irá guiá-lo através do processo de instalação do STL Jewelry 3D.</p>
                        <div class="alert alert-info">
                            <strong>Antes de começar, certifique-se de que:</strong>
                            <ul class="text-start mt-2 mb-0">
                                <li>Você tem as credenciais do banco de dados MySQL</li>
                                <li>O servidor atende aos requisitos mínimos do sistema</li>
                                <li>As permissões de arquivo estão configuradas corretamente</li>
                            </ul>
                        </div>
                        <a href="?step=requirements" class="btn btn-primary btn-lg mt-3">Iniciar Instalação</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

