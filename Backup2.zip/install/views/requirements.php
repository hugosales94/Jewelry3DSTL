<?php
// Check system requirements
$requirements = [
    'php' => [
        'version' => '7.4.0',
        'current' => PHP_VERSION,
        'status' => version_compare(PHP_VERSION, '7.4.0', '>=')
    ],
    'extensions' => [
        'mysqli' => extension_loaded('mysqli'),
        'pdo_mysql' => extension_loaded('pdo_mysql'),
        'gd' => extension_loaded('gd'),
        'zip' => extension_loaded('zip'),
        'curl' => extension_loaded('curl')
    ],
    'writable_dirs' => [
        '/public_html/uploads' => is_writable(dirname(__DIR__, 2) . '/public_html/uploads'),
        '/logs' => is_writable(dirname(__DIR__, 2) . '/logs'),
        '/cache' => is_writable(dirname(__DIR__, 2) . '/cache')
    ]
];

$allPassed = true;
foreach ($requirements['extensions'] as $status) {
    if (!$status) $allPassed = false;
}
foreach ($requirements['writable_dirs'] as $status) {
    if (!$status) $allPassed = false;
}
if (!$requirements['php']['status']) $allPassed = false;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificação de Requisitos - STL Jewelry 3D</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-body p-5">
                        <h1 class="text-center mb-4">Verificação de Requisitos</h1>
                        
                        <!-- PHP Version -->
                        <div class="mb-4">
                            <h3 class="h5">Versão do PHP</h3>
                            <div class="list-group">
                                <div class="list-group-item d-flex justify-content-between align-items-center">
                                    PHP <?php echo $requirements['php']['version']; ?> ou superior
                                    <?php if ($requirements['php']['status']): ?>
                                        <span class="badge bg-success rounded-pill">✓</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger rounded-pill">✗</span>
                                    <?php endif; ?>
                                </div>
                                <div class="list-group-item text-muted">
                                    Versão atual: PHP <?php echo $requirements['php']['current']; ?>
                                </div>
                            </div>
                        </div>

                        <!-- PHP Extensions -->
                        <div class="mb-4">
                            <h3 class="h5">Extensões PHP Necessárias</h3>
                            <div class="list-group">
                                <?php foreach ($requirements['extensions'] as $ext => $installed): ?>
                                    <div class="list-group-item d-flex justify-content-between align-items-center">
                                        <?php echo $ext; ?>
                                        <?php if ($installed): ?>
                                            <span class="badge bg-success rounded-pill">✓</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger rounded-pill">✗</span>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Directory Permissions -->
                        <div class="mb-4">
                            <h3 class="h5">Permissões de Diretório</h3>
                            <div class="list-group">
                                <?php foreach ($requirements['writable_dirs'] as $dir => $writable): ?>
                                    <div class="list-group-item d-flex justify-content-between align-items-center">
                                        <?php echo $dir; ?>
                                        <?php if ($writable): ?>
                                            <span class="badge bg-success rounded-pill">✓</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger rounded-pill">✗</span>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Navigation -->
                        <div class="text-center mt-4">
                            <?php if ($allPassed): ?>
                                <div class="alert alert-success">
                                    Todos os requisitos foram atendidos!
                                </div>
                                <a href="?step=database" class="btn btn-primary btn-lg">Continuar para Configuração do Banco de Dados</a>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    Alguns requisitos não foram atendidos. Por favor, corrija os itens marcados com ✗ e tente novamente.
                                </div>
                                <button onclick="window.location.reload()" class="btn btn-primary btn-lg">Verificar Novamente</button>
                            <?php endif; ?>
                            <a href="?step=welcome" class="btn btn-link">Voltar</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

