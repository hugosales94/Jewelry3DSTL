<?php
// Create install.lock file to prevent reinstallation
$lockFile = dirname(__DIR__, 2) . '/install.lock';
if (!file_exists($lockFile)) {
    file_put_contents($lockFile, date('Y-m-d H:i:s'));
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalação Concluída - STL Jewelry 3D</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-body p-5 text-center">
                        <h1 class="mb-4">Instalação Concluída!</h1>
                        
                        <div class="alert alert-success mb-4">
                            <strong>Parabéns!</strong> O STL Jewelry 3D foi instalado com sucesso.
                        </div>

                        <div class="mb-4">
                            <h3 class="h5">Próximos Passos:</h3>
                            <ul class="list-unstyled text-start">
                                <li class="mb-2">✓ Configure seu primeiro usuário administrador</li>
                                <li class="mb-2">✓ Personalize as configurações do site</li>
                                <li class="mb-2">✓ Comece a adicionar conteúdo</li>
                            </ul>
                        </div>

                        <div class="alert alert-warning mb-4">
                            <strong>Importante:</strong> Por razões de segurança, remova o diretório "install" após acessar o site.
                        </div>

                        <a href="/" class="btn btn-primary btn-lg">Acessar o Site</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

