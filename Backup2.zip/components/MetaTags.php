<?php

class MetaTags {
    private $title;
    private $description;
    private $keywords;
    private $ogImage;

    public function __construct($title, $description, $keywords = '', $ogImage = '') {
        $this->title = $title;
        $this->description = $description;
        $this->keywords = $keywords;
        $this->ogImage = $ogImage;
    }

    public function render() {
        $output = "<title>" . htmlspecialchars($this->title) . " | STL Jewelry 3D</title>\n";
        $output .= "<meta name='description' content='" . htmlspecialchars($this->description) . "'>\n";
        
        if (!empty($this->keywords)) {
            $output .= "<meta name='keywords' content='" . htmlspecialchars($this->keywords) . "'>\n";
        }

        $output .= "<meta property='og:title' content='" . htmlspecialchars($this->title) . "'>\n";
        $output .= "<meta property='og:description' content='" . htmlspecialchars($this->description) . "'>\n";
        $output .= "<meta property='og:type' content='website'>\n";
        $output .= "<meta property='og:url' content='" . htmlspecialchars($this->getCurrentUrl()) . "'>\n";

        if (!empty($this->ogImage)) {
            $output .= "<meta property='og:image' content='" . htmlspecialchars($this->ogImage) . "'>\n";
        }

        return $output;
    }

    private function getCurrentUrl() {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        return $protocol . "://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    }
}

