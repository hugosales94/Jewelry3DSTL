<?php
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 1);

session_start();

define('BASE_PATH', __DIR__);
require_once BASE_PATH . '/vendor/autoload.php';



// Custom error handler
function customErrorHandler($errno, $errstr, $errfile, $errline) {
    $logMessage = date('Y-m-d H:i:s') . " - Error: [$errno] $errstr in $errfile on line $errline\n";
    error_log($logMessage, 3, BASE_PATH . '/logs/error.log');
    
    // Only show generic error message to users in production
    if (getenv('APP_ENV') === 'production') {
        include BASE_PATH . '/views/errors/500.php';
        exit();
    } else {
        // Show detailed error in development
        echo "<h1>Error</h1>";
        echo "<p>$errstr</p>";
        echo "<p>File: $errfile</p>";
        echo "<p>Line: $errline</p>";
    }
}

// Set custom error handler
set_error_handler("customErrorHandler");

// Custom exception handler
function customExceptionHandler($exception) {
    $logMessage = date('Y-m-d H:i:s') . " - Exception: " . $exception->getMessage() . 
                 " in " . $exception->getFile() . 
                 " on line " . $exception->getLine() . "\n";
    error_log($logMessage, 3, BASE_PATH . '/logs/error.log');
    
    if (getenv('APP_ENV') === 'production') {
        include BASE_PATH . '/views/errors/500.php';
    } else {
        echo "<h1>Exception</h1>";
        echo "<p>" . $exception->getMessage() . "</p>";
        echo "<p>File: " . $exception->getFile() . "</p>";
        echo "<p>Line: " . $exception->getLine() . "</p>";
    }
}

// Set custom exception handler
set_exception_handler("customExceptionHandler");

// Check if the application is installed
if (!file_exists(BASE_PATH . '/install.lock')) {
    // If not installed, include the installer
    require_once BASE_PATH . '/install/install.php';
    exit();
}

require_once BASE_PATH . '/config/app_config.php';
require_once BASE_PATH . '/utils/Router.php';
require_once BASE_PATH . '/controllers/MainController.php';

try {
    $router = new Router();

    // Load routes
    require_once BASE_PATH . '/config/routes.php';

    // Handle the request
    $router->handleRequest();
} catch (Exception $e) {
    // Log the error and show error page
    error_log($e->getMessage());
    include BASE_PATH . '/views/errors/500.php';
}

