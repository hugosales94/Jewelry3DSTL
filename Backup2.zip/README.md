# STL Jewelry 3D

STL Jewelry 3D é uma plataforma para compartilhar e descobrir modelos 3D de joias.

## Instalação na Hospedagem Compartilhada da Hostinger

1. Faça o upload de todos os arquivos e pastas para sua conta na Hostinger:
   - Todos os arquivos e pastas do projeto devem ser colocados diretamente na pasta `public_html` da sua conta Hostinger.

2. Crie um novo banco de dados MySQL e um usuário através do cPanel.

3. Renomeie o arquivo `.env.example` para `.env` e atualize as configurações do banco de dados e outras variáveis de ambiente conforme necessário.

4. Acesse seu domínio em um navegador web (por exemplo, https://seudominio.com). O processo de instalação será iniciado automaticamente.

5. Siga os passos da instalação:
   - Página de boas-vindas
   - Verificação dos requisitos do sistema
   - Configuração do banco de dados (use as credenciais do banco de dados que você criou no passo 2)

6. Após a conclusão da instalação, você será redirecionado para a página inicial do seu site.

7. Faça login no painel de administração e configure as configurações do seu site.

## Solução de Problemas

Se você encontrar problemas durante a instalação:

1. Verifique se todos os arquivos foram enviados para os locais corretos.
2. Certifique-se de que as permissões dos arquivos estejam configuradas corretamente:
   - Diretórios: 755
   - Arquivos: 644
3. Verifique se o PHP está configurado para a versão 7.4 ou superior.
4. Se o instalador não iniciar automaticamente, tente acessar manualmente https://seudominio.com/index.php

## Configurações específicas para Hostinger

1. Cron Jobs:
   - Acesse o cPanel da Hostinger
   - Navegue até a seção "Cron Jobs"
   - Adicione um novo cron job para executar o backup diariamente:
     - Comando: `php /home/username/public_html/backup.php`
     - Frequência: Daily

2. Configuração de e-mail:
   - Use as configurações SMTP fornecidas pela Hostinger no arquivo .env
   - Geralmente, o host SMTP será `smtp.hostinger.com`

3. SSL/HTTPS:
   - Ative o SSL gratuito através do cPanel da Hostinger
   - O arquivo .htaccess já está configurado para redirecionar para HTTPS

4. PHP Version:
   - Verifique se a versão do PHP está configurada para 7.4 ou superior no cPanel

Lembre-se de substituir 'username' pelo seu nome de usuário real na Hostinger em todos os caminhos mencionados acima.

## Notas Importantes

- Certifique-se de que os diretórios `uploads`, `logs` e `cache` tenham permissões de escrita pelo servidor web.
- Se encontrar algum problema, verifique os logs de erro no diretório `logs`.
- Por razões de segurança, remova o diretório `install` após a instalação bem-sucedida.

## Atualização

Para atualizar a aplicação:

1. Faça backup do seu banco de dados e de todos os arquivos.
2. Substitua os arquivos existentes pela nova versão, mantendo seu arquivo `.env` intacto.
3. Execute as migrações de banco de dados necessárias.

## Suporte

Se encontrar algum problema ou precisar de assistência, entre em contato com nossa equipe de suporte.

