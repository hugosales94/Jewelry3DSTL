<?php ob_start(); ?>

<h1>Upload STL File</h1>

<form action="/upload" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
    <div class="mb-3">
        <label for="stl_file" class="form-label">STL File</label>
        <input type="file" class="form-control" id="stl_file" name="stl_file" accept=".stl" required>
        <div class="invalid-feedback">Please select an STL file to upload.</div>
    </div>

    <div class="mb-3">
        <label for="name" class="form-label">File Name</label>
        <input type="text" class="form-control" id="name" name="name" required>
        <div class="invalid-feedback">Please provide a name for your file.</div>
    </div>

    <div class="mb-3">
        <label for="description" class="form-label">Description</label>
        <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
        <div class="invalid-feedback">Please provide a description for your file.</div>
    </div>

    <div class="mb-3">
        <label for="category" class="form-label">Category</label>
        <select class="form-select" id="category" name="category" required>
            <option value="">Select a category</option>
            <option value="rings">Rings</option>
            <option value="necklaces">Necklaces</option>
            <option value="earrings">Earrings</option>
            <option value="bracelets">Bracelets</option>
            <option value="pendants">Pendants</option>
            <option value="other">Other</option>
        </select>
        <div class="invalid-feedback">Please select a category.</div>
    </div>

    <div class="mb-3">
        <label for="tags" class="form-label">Tags (comma-separated)</label>
        <input type="text" class="form-control" id="tags" name="tags">
    </div>

    <div class="mb-3 form-check">
        <input type="checkbox" class="form-check-input" id="terms" required>
        <label class="form-check-label" for="terms">I agree to the <a href="/terms" target="_blank">Terms of Service</a></label>
        <div class="invalid-feedback">You must agree to the Terms of Service.</div>
    </div>

    <button type="submit" class="btn btn-primary">Upload</button>
</form>

<script>
// Form validation
(function () {
  'use strict'

  var forms = document.querySelectorAll('.needs-validation')

  Array.prototype.slice.call(forms)
    .forEach(function (form) {
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })
})()
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/main.php';
?>

