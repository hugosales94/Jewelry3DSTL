<?php ob_start(); ?>

<div class="container mt-4">
    <h1>Edit Subscription Plan</h1>
    <form action="/admin/edit-subscription/<?php echo $subscription['id']; ?>" method="post">
        <div class="mb-3">
            <label for="name" class="form-label">Name</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($subscription['name']); ?>" required>
        </div>
        <div class="mb-3">
            <label for="price" class="form-label">Price</label>
            <input type="number" class="form-control" id="price" name="price" value="<?php echo $subscription['price']; ?>" step="0.01" required>
        </div>
        <div class="mb-3">
            <label for="duration" class="form-label">Duration (days)</label>
            <input type="number" class="form-control" id="duration" name="duration" value="<?php echo $subscription['duration']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="downloads" class="form-label">Downloads</label>
            <input type="number" class="form-control" id="downloads" name="downloads" value="<?php echo $subscription['downloads']; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update Subscription Plan</button>
        <a href="/admin/subscription-management" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/admin_layout.php';
?>

