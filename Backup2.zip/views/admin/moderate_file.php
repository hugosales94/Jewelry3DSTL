<?php ob_start(); ?>

<div class="container mt-4">
    <h1>Moderate File</h1>
    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title"><?php echo htmlspecialchars($file['name']); ?></h5>
            <p class="card-text">Uploader: <?php echo htmlspecialchars($file['username']); ?></p>
            <p class="card-text">Upload Date: <?php echo date('Y-m-d H:i:s', strtotime($file['created_at'])); ?></p>
            <a href="/file/<?php echo $file['id']; ?>" class="btn btn-primary" target="_blank">View File</a>
        </div>
    </div>

    <h2>Reports</h2>
    <?php foreach ($reports as $report): ?>
        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title">Report by <?php echo htmlspecialchars($report['reporter_username']); ?></h5>
                <p class="card-text">Reason: <?php echo htmlspecialchars($report['reason']); ?></p>
                <p class="card-text">Date: <?php echo date('Y-m-d H:i:s', strtotime($report['created_at'])); ?></p>
            </div>
        </div>
    <?php endforeach; ?>

    <form action="/admin/moderate-file/<?php echo $file['id']; ?>" method="post" class="mt-4">
        <div class="mb-3">
            <label for="action" class="form-label">Action</label>
            <select class="form-select" id="action" name="action" required>
                <option value="dismiss">Dismiss Reports</option>
                <option value="delete">Delete File</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Take Action</button>
        <a href="/admin/content-moderation" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/admin_layout.php';
?>

