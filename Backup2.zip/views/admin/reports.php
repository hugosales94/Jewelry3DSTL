<?php ob_start(); ?>

<div class="container mt-4">
    <h1>Reports</h1>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Reporter</th>
                <th>Reported Item</th>
                <th>Reason</th>
                <th>Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($reports as $report): ?>
                <tr>
                    <td><?php echo $report['id']; ?></td>
                    <td><?php echo htmlspecialchars($report['reporter_username']); ?></td>
                    <td><?php echo htmlspecialchars($report['reported_item_name']); ?></td>
                    <td><?php echo htmlspecialchars($report['reason']); ?></td>
                    <td><?php echo date('Y-m-d H:i:s', strtotime($report['created_at'])); ?></td>
                    <td><?php echo $report['status']; ?></td>
                    <td>
                        <?php if ($report['status'] === 'pending'): ?>
                            <a href="/admin/review-report/<?php echo $report['id']; ?>" class="btn btn-sm btn-warning">Review</a>
                        <?php else: ?>
                            <span class="badge bg-secondary">Resolved</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/admin_layout.php';
?>

