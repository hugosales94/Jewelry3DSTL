<?php ob_start(); ?>

<div class="container mt-4">
    <h1>Subscription Management</h1>
    <a href="/admin/add-subscription" class="btn btn-success mb-3">Add New Subscription Plan</a>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Price</th>
                <th>Duration</th>
                <th>Downloads</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($subscriptions as $subscription): ?>
                <tr>
                    <td><?php echo $subscription['id']; ?></td>
                    <td><?php echo htmlspecialchars($subscription['name']); ?></td>
                    <td>$<?php echo number_format($subscription['price'], 2); ?></td>
                    <td><?php echo $subscription['duration']; ?> days</td>
                    <td><?php echo $subscription['downloads']; ?></td>
                    <td>
                        <a href="/admin/edit-subscription/<?php echo $subscription['id']; ?>" class="btn btn-sm btn-primary">Edit</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/admin_layout.php';
?>

