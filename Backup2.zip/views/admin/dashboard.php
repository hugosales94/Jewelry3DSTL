<?php ob_start(); ?>

<div class="container mt-4">
    <h1>Admin Dashboard</h1>
    <div class="row">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Total Users</h5>
                    <p class="card-text display-4"><?php echo $totalUsers; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Total Files</h5>
                    <p class="card-text display-4"><?php echo $totalFiles; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Active Reports</h5>
                    <p class="card-text display-4"><?php echo $totalReports; ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Active Subscriptions</h5>
                    <p class="card-text display-4"><?php echo $totalSubscriptions; ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="mt-4">
        <h2>Quick Links</h2>
        <a href="/admin/user-management" class="btn btn-primary">User Management</a>
        <a href="/admin/content-moderation" class="btn btn-warning">Content Moderation</a>
        <a href="/admin/subscription-management" class="btn btn-info">Subscription Management</a>
        <a href="/admin/reports" class="btn btn-danger">View Reports</a>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/admin_layout.php';
?>

