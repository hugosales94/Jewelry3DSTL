<?php ob_start(); ?>

<div class="container mt-4">
    <h1>Content Moderation</h1>
    <table class="table">
        <thead>
            <tr>
                <th>File ID</th>
                <th>File Name</th>
                <th>Uploader</th>
                <th>Report Count</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($reportedFiles as $file): ?>
                <tr>
                    <td><?php echo $file['id']; ?></td>
                    <td><?php echo htmlspecialchars($file['name']); ?></td>
                    <td><?php echo htmlspecialchars($file['username']); ?></td>
                    <td><?php echo $file['report_count']; ?></td>
                    <td>
                        <a href="/admin/moderate-file/<?php echo $file['id']; ?>" class="btn btn-sm btn-warning">Review</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/admin_layout.php';
?>

