<?php ob_start(); ?>

<div class="container mt-4">
    <h1>Compose Message</h1>
    <form action="/messages/compose" method="post">
        <div class="mb-3">
            <label for="receiver_id" class="form-label">To:</label>
            <select name="receiver_id" id="receiver_id" class="form-select" required>
                <option value="">Select a user</option>
                <?php foreach ($users as $user): ?>
                    <?php if ($user['id'] != $_SESSION['user_id']): ?>
                        <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['username']); ?></option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="subject" class="form-label">Subject:</label>
            <input type="text" name="subject" id="subject" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="content" class="form-label">Message:</label>
            <textarea name="content" id="content" class="form-control" rows="5" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Send Message</button>
        <a href="/messages/inbox" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/main.php';
?>

