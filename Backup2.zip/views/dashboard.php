<?php ob_start(); ?>

<div class="container mt-4">
    <h1 class="mb-4">Welcome back, <?php echo htmlspecialchars($user['username']); ?>!</h1>

    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h2 class="h5 mb-0">Your Recent Activity</h2>
                </div>
                <div class="card-body">
                    <?php if (empty($recentActivities)): ?>
                        <p>No recent activities.</p>
                    <?php else: ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($recentActivities as $activity): ?>
                                <li class="list-group-item">
                                    <strong><?php echo htmlspecialchars($activity['type']); ?>:</strong>
                                    <?php echo htmlspecialchars($activity['description']); ?>
                                    <small class="text-muted d-block"><?php echo date('F j, Y, g:i a', strtotime($activity['created_at'])); ?></small>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h2 class="h5 mb-0">Your Popular Designs</h2>
                </div>
                <div class="card-body">
                    <?php if (empty($popularDesigns)): ?>
                        <p>You haven't uploaded any designs yet.</p>
                    <?php else: ?>
                        <div class="row">
                            <?php foreach ($popularDesigns as $design): ?>
                                <div class="col-md-4 mb-3">
                                    <div class="card">
                                        <img src="<?php echo htmlspecialchars($design['thumbnail_url']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($design['name']); ?>">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo htmlspecialchars($design['name']); ?></h5>
                                            <p class="card-text">Downloads: <?php echo $design['downloads']; ?></p>
                                            <a href="/file/<?php echo $design['id']; ?>" class="btn btn-primary btn-sm">View Details</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h2 class="h5 mb-0">Your Stats</h2>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Uploads
                            <span class="badge bg-primary rounded-pill"><?php echo $userStats['uploads']; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Downloads
                            <span class="badge bg-primary rounded-pill"><?php echo $userStats['downloads']; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Followers
                            <span class="badge bg-primary rounded-pill"><?php echo $userStats['followers']; ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            Following
                            <span class="badge bg-primary rounded-pill"><?php echo $userStats['following']; ?></span>
                        </li>
                    </ul>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h2 class="h5 mb-0">Recommended for You</h2>
                </div>
                <div class="card-body">
                    <?php if (empty($recommendations)): ?>
                        <p>No recommendations available at the moment.</p>
                    <?php else: ?>
                        <div class="list-group">
                            <?php foreach ($recommendations as $recommendation): ?>
                                <a href="/file/<?php echo $recommendation['id']; ?>" class="list-group-item list-group-item-action">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-1"><?php echo htmlspecialchars($recommendation['name']); ?></h5>
                                        <small><?php echo $recommendation['downloads']; ?> downloads</small>
                                    </div>
                                    <p class="mb-1"><?php echo htmlspecialchars(substr($recommendation['description'], 0, 100)) . '...'; ?></p>
                                    <small>By <?php echo htmlspecialchars($recommendation['username']); ?></small>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../views/layout/main.php';
?>

