<?php ob_start(); ?>

<div class="container mt-5">
    <h1 class="text-center mb-4">Welcome to STL Jewelry 3D, <?php echo htmlspecialchars($user['username']); ?>!</h1>
    <p class="text-center lead mb-5">Let's start your journey in the world of 3D jewelry. Complete the steps below to make the most of our platform.</p>

    <div class="row">
        <?php foreach ($onboardingSteps as $step): ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100 <?php echo in_array($step['id'], $completedSteps) ? 'border-success' : ''; ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($step['title']); ?></h5>
                        <p class="card-text"><?php echo htmlspecialchars($step['description']); ?></p>
                        <?php if (in_array($step['id'], $completedSteps)): ?>
                            <button class="btn btn-success" disabled>Completed</button>
                        <?php else: ?>
                            <button class="btn btn-primary complete-step" data-step-id="<?php echo $step['id']; ?>">Complete</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const completeButtons = document.querySelectorAll('.complete-step');
    completeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const stepId = this.getAttribute('data-step-id');
            fetch('/onboarding/complete-step', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'step_id=' + stepId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.textContent = 'Completed';
                    this.classList.remove('btn-primary');
                    this.classList.add('btn-success');
                    this.disabled = true;
                    this.closest('.card').classList.add('border-success');
                } else {
                    alert('Error completing the step. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again later.');
            });
        });
    });
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../views/layout/main.php';
?>

