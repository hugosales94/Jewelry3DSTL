<?php ob_start(); ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title"><?php echo htmlspecialchars($user['username']); ?></h2>
                    <p class="card-text">Member since: <?php echo date('F Y', strtotime($user['created_at'])); ?></p>
                    <p class="card-text">Level: <?php echo $user['level']; ?></p>
                    <p class="card-text">Score: <?php echo number_format($user['score']); ?></p>
                    <p class="card-text">Uploads: <?php echo $user['uploads']; ?></p>
                    <p class="card-text">Downloads: <?php echo $user['downloads']; ?></p>
                    <p class="card-text">Followers: <?php echo count($followers); ?></p>
                    <p class="card-text">Following: <?php echo count($following); ?></p>
                    <?php if ($user['id'] !== $_SESSION['user_id']): ?>
                        <?php if ($isFollowing): ?>
                            <form action="/user/unfollow/<?php echo $user['id']; ?>" method="post">
                                <button type="submit" class="btn btn-secondary">Unfollow</button>
                            </form>
                        <?php else: ?>
                            <form action="/user/follow/<?php echo $user['id']; ?>" method="post">
                                <button type="submit" class="btn btn-primary">Follow</button>
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card mt-4">
                <div class="card-body">
                    <h3 class="card-title">Badges</h3>
                    <div class="row">
                        <?php foreach ($userBadges as $badge): ?>
                            <div class="col-4 mb-3">
                                <img src="/assets/badges/<?php echo $badge['image']; ?>" alt="<?php echo htmlspecialchars($badge['name']); ?>" title="<?php echo htmlspecialchars($badge['description']); ?>" class="img-fluid">
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <h3>Uploaded Designs</h3>
            <div class="row">
                <?php foreach ($userFiles as $file): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="/uploads/thumbnails/<?php echo $file['thumbnail']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($file['name']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($file['name']); ?></h5>
                                <p class="card-text">
                                    <small class="text-muted">Uploaded: <?php echo date('M d, Y', strtotime($file['created_at'])); ?></small>
                                </p>
                                <p class="card-text">
                                    <small class="text-muted">Downloads: <?php echo $file['downloads']; ?></small>
                                </p>
                                <a href="/file/<?php echo $file['id']; ?>" class="btn btn-primary btn-sm">View Details</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php if (count($userFiles) === 0): ?>
                <p>This user hasn't uploaded any designs yet.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/main.php';
?>

