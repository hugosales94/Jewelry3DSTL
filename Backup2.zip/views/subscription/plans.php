<?php ob_start(); ?>

<div class="container mt-5">
    <h1 class="mb-4">Subscription Plans</h1>

    <?php if (isset($currentSubscription)): ?>
        <div class="alert alert-info">
            You are currently subscribed to the <?php echo htmlspecialchars($currentSubscription['plan_name']); ?> plan.
            Your subscription will expire on <?php echo date('F j, Y', strtotime($currentSubscription['end_date'])); ?>.
        </div>
    <?php endif; ?>

    <div class="row">
        <?php foreach ($plans as $plan): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($plan['name']); ?></h5>
                        <h6 class="card-subtitle mb-2 text-muted">$<?php echo number_format($plan['price'], 2); ?> / <?php echo $plan['duration']; ?> days</h6>
                        <p class="card-text"><?php echo htmlspecialchars($plan['description']); ?></p>
                        <ul>
                            <li><?php echo $plan['downloads']; ?> downloads</li>
                            <!-- Add more features here -->
                        </ul>
                        <form action="/subscription/subscribe" method="post">
                            <input type="hidden" name="plan_id" value="<?php echo $plan['id']; ?>">
                            <button type="submit" class="btn btn-primary">Subscribe</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/main.php';
?>

