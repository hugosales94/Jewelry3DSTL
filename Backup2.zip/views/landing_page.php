<?php ob_start(); ?>

<div class="hero bg-primary text-white py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="display-4">Bem-vindo ao STL Jewelry 3D</h1>
                <p class="lead">Descubra, compartilhe e imprima designs incríveis de joias em 3D</p>
                <a href="/register" class="btn btn-light btn-lg mt-3">Comece Agora</a>
            </div>
            <div class="col-md-6">
                <img src="/assets/images/hero-image.png" alt="Joia 3D" class="img-fluid rounded">
            </div>
        </div>
    </div>
</div>

<div class="features py-5">
    <div class="container">
        <h2 class="text-center mb-5">Por que escolher o STL Jewelry 3D?</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-cloud-upload fs-1 text-primary mb-3"></i>
                        <h3 class="card-title">Upload Fácil</h3>
                        <p class="card-text">Faça upload dos seus designs STL com apenas alguns cliques</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-search fs-1 text-primary mb-3"></i>
                        <h3 class="card-title">Pesquisa Avançada</h3>
                        <p class="card-text">Encontre o design perfeito com nossa pesquisa avançada</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100">
                    <div class="card-body text-center">
                        <i class="bi bi-trophy fs-1 text-primary mb-3"></i>
                        <h3 class="card-title">Sistema de Recompensas</h3>
                        <p class="card-text">Ganhe pontos e suba no ranking da comunidade</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="cta bg-light py-5">
    <div class="container text-center">
        <h2>Pronto para começar sua jornada no mundo das joias 3D?</h2>
        <p class="lead">Junte-se a milhares de designers e entusiastas hoje mesmo!</p>
        <a href="/register" class="btn btn-primary btn-lg mt-3">Criar Conta Grátis</a>
    </div>
</div>

<div class="testimonials py-5">
    <div class="container">
        <h2 class="text-center mb-5">O que nossos usuários dizem</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <p class="card-text">"STL Jewelry 3D revolucionou minha forma de criar joias. A comunidade é incrível!"</p>
                        <footer class="blockquote-footer">Maria Silva, Designer de Joias</footer>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <p class="card-text">"Encontrei designs incríveis que não teria descoberto de outra forma. Altamente recomendado!"</p>
                        <footer class="blockquote-footer">João Santos, Entusiasta de Impressão 3D</footer>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <p class="card-text">"A plataforma é intuitiva e os recursos de gamificação tornam tudo mais divertido!"</p>
                        <footer class="blockquote-footer">Ana Oliveira, Estudante de Design</footer>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../views/layout/main.php';
?>

