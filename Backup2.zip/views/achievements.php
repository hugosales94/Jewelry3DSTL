<?php ob_start(); ?>

<h1>Your Achievements</h1>

<div class="row">
    <?php foreach ($allBadges as $badge): ?>
        <?php $earned = in_array($badge, $userBadges); ?>
        <div class="col-md-4 mb-4">
            <div class="card <?php echo $earned ? 'border-success' : 'border-secondary'; ?>">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($badge['name']); ?></h5>
                    <p class="card-text"><?php echo htmlspecialchars($badge['description']); ?></p>
                    <?php if ($earned): ?>
                        <span class="badge bg-success">Earned</span>
                    <?php else: ?>
                        <span class="badge bg-secondary">Not Earned</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/main.php';
?>

