<?php ob_start(); ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body text-center">
                    <h1 class="card-title text-warning">Pagamento Cancelado</h1>
                    <p class="card-text">Seu pagamento foi cancelado. Não se preocupe, nenhum valor foi cobrado.</p>
                    <p class="card-text">Se você tiver alguma dúvida ou quiser tentar novamente, entre em contato conosco.</p>
                    <a href="/subscription/plans" class="btn btn-primary mt-3">Ver Planos Novamente</a>
                    <a href="/dashboard" class="btn btn-secondary mt-3">Voltar ao Dashboard</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../views/layout/main.php';
?>

