<?php ob_start(); ?>

<div class="container mt-4">
    <h1>Inbox</h1>
    <a href="/messages/compose" class="btn btn-primary mb-3">Compose New Message</a>
    <table class="table">
        <thead>
            <tr>
                <th>From</th>
                <th>Subject</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($messages as $message): ?>
                <tr <?php echo $message['is_read'] ? '' : 'class="font-weight-bold"'; ?>>
                    <td><?php echo htmlspecialchars($message['sender_name']); ?></td>
                    <td><?php echo htmlspecialchars($message['subject']); ?></td>
                    <td><?php echo date('M d, Y H:i', strtotime($message['created_at'])); ?></td>
                    <td>
                        <a href="/messages/view/<?php echo $message['id']; ?>" class="btn btn-sm btn-primary">View</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/main.php';
?>

