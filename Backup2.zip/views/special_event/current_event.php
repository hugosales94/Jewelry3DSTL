<?php ob_start(); ?>

<div class="container mt-5">
    <h1 class="mb-4">Special Event</h1>

    <?php if ($currentEvent): ?>
        <div class="card">
            <div class="card-body">
                <h2 class="card-title"><?php echo htmlspecialchars($currentEvent['name']); ?></h2>
                <p class="card-text"><?php echo htmlspecialchars($currentEvent['description']); ?></p>
                <p>Start Date: <?php echo date('F j, Y', strtotime($currentEvent['start_date'])); ?></p>
                <p>End Date: <?php echo date('F j, Y', strtotime($currentEvent['end_date'])); ?></p>
                
                <?php if ($userParticipation): ?>
                    <div class="alert alert-success">
                        You have already participated in this event. Thank you for your participation!
                    </div>
                <?php else: ?>
                    <form action="/special-event/participate" method="post">
                        <input type="hidden" name="event_id" value="<?php echo $currentEvent['id']; ?>">
                        <button type="submit" class="btn btn-primary">Participate</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-info">
            There are no active special events at the moment. Please check back later!
        </div>
    <?php endif; ?>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/main.php';
?>

