<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erro do Servidor - STL Jewelry 3D</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8f9fa;
        }
        .error-container {
            text-align: center;
            padding: 2rem;
            max-width: 600px;
        }
        .error-code {
            font-size: 6rem;
            font-weight: bold;
            color: #dc3545;
            margin-bottom: 1rem;
        }
        .error-message {
            font-size: 1.5rem;
            color: #6c757d;
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <div class="error-code">500</div>
        <h1 class="error-message">Erro Interno do Servidor</h1>
        <p class="mb-4">Desculpe, ocorreu um erro inesperado. Nossa equipe técnica foi notificada e está trabalhando para resolver o problema.</p>
        <div class="d-flex justify-content-center gap-3">
            <a href="/" class="btn btn-primary">Voltar para a Página Inicial</a>
            <button onclick="window.location.reload()" class="btn btn-outline-primary">Tentar Novamente</button>
        </div>
    </div>
</body>
</html>

