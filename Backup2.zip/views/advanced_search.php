<?php ob_start(); ?>

<div class="container mt-4">
    <h1>Advanced Search</h1>

    <form action="/advanced-search" method="GET" class="mb-4">
        <div class="row g-3">
            <div class="col-md-6">
                <label for="q" class="form-label">Search Query</label>
                <input type="text" class="form-control" id="q" name="q" value="<?php echo htmlspecialchars($params['query']); ?>" placeholder="Enter keywords...">
            </div>
            <div class="col-md-6">
                <label for="category" class="form-label">Category</label>
                <select name="category" id="category" class="form-select">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['category']; ?>" <?php echo $params['category'] === $category['category'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($category['category']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label for="price-range" class="form-label">Price Range</label>
                <div id="price-range"></div>
                <div class="d-flex justify-content-between mt-2">
                    <span id="price-range-min"></span>
                    <span id="price-range-max"></span>
                </div>
                <input type="hidden" id="min_price" name="min_price" value="<?php echo htmlspecialchars($params['min_price']); ?>">
                <input type="hidden" id="max_price" name="max_price" value="<?php echo htmlspecialchars($params['max_price']); ?>">
            </div>
            <div class="col-md-3">
                <label for="min_rating" class="form-label">Min Rating</label>
                <select name="min_rating" id="min_rating" class="form-select">
                    <option value="">Any Rating</option>
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <option value="<?php echo $i; ?>" <?php echo $params['min_rating'] == $i ? 'selected' : ''; ?>><?php echo $i; ?> Star<?php echo $i > 1 ? 's' : ''; ?> & Up</option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="sort_by" class="form-label">Sort By</label>
                <select name="sort_by" id="sort_by" class="form-select">
                    <option value="created_at" <?php echo $params['sort_by'] === 'created_at' ? 'selected' : ''; ?>>Newest</option>
                    <option value="price" <?php echo $params['sort_by'] === 'price' ? 'selected' : ''; ?>>Price</option>
                    <option value="average_rating" <?php echo $params['sort_by'] === 'average_rating' ? 'selected' : ''; ?>>Rating</option>
                    <option value="download_count" <?php echo $params['sort_by'] === 'download_count' ? 'selected' : ''; ?>>Popularity</option>
                </select>
            </div>
            <div class="col-md-12">
                <label for="tags" class="form-label">Tags</label>
                <input type="text" class="form-control" id="tags" name="tags" value="<?php echo htmlspecialchars($params['tags']); ?>" placeholder="Enter tags separated by commas">
            </div>
            <div class="col-12">
                <button type="submit" class="btn btn-primary">Search</button>
            </div>
        </div>
    </form>

    <h2>Search Results</h2>
    <div class="row">
        <?php foreach ($results as $file): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="/uploads/thumbnails/<?php echo $file['thumbnail']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($file['name']); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($file['name']); ?></h5>
                        <p class="card-text">
                            <small class="text-muted">By: <?php echo htmlspecialchars($file['username']); ?></small>
                        </p>
                        <p class="card-text">
                            <small class="text-muted">Price: $<?php echo number_format($file['price'], 2); ?></small>
                        </p>
                        <p class="card-text">
                            <small class="text-muted">Rating: <?php echo number_format($file['average_rating'], 1); ?>/5</small>
                        </p>
                        <p class="card-text">
                            <small class="text-muted">Downloads: <?php echo $file['download_count']; ?></small>
                        </p>
                        <a href="/file/<?php echo $file['id']; ?>" class="btn btn-primary btn-sm">View Details</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if ($totalPages > 1): ?>
        <nav aria-label="Search results pages">
            <ul class="pagination justify-content-center">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?php echo $params['page'] === $i ? 'active' : ''; ?>">
                        <a class="page-link" href="<?php echo $this->buildPaginationUrl($params, $i); ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/nouislider@14.6.3/distribute/nouislider.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/nouislider@14.6.3/distribute/nouislider.min.css">
<script src="https://cdn.jsdelivr.net/npm/@tarekraafat/autocomplete.js@10.2.7/dist/autoComplete.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tarekraafat/autocomplete.js@10.2.7/dist/css/autoComplete.min.css">

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Price range slider
    var priceRange = document.getElementById('price-range');
    var minPrice = document.getElementById('min_price');
    var maxPrice = document.getElementById('max_price');
    var priceRangeMin = document.getElementById('price-range-min');
    var priceRangeMax = document.getElementById('price-range-max');

    noUiSlider.create(priceRange, {
        start: [minPrice.value || 0, maxPrice.value || 1000],
        connect: true,
        range: {
            'min': 0,
            'max': 1000
        }
    });

    priceRange.noUiSlider.on('update', function (values, handle) {
        var value = values[handle];
        if (handle) {
            maxPrice.value = Math.round(value);
            priceRangeMax.textContent = '$' + Math.round(value);
        } else {
            minPrice.value = Math.round(value);
            priceRangeMin.textContent = '$' + Math.round(value);
        }
    });

    // Tags autocomplete
    var tagsInput = document.getElementById('tags');
    var autoCompleteJS = new autoComplete({
        selector: "#tags",
        placeHolder: "Enter tags separated by commas",
        data: {
            src: <?php echo json_encode(array_column($tags, 'tag')); ?>,
            cache: true,
        },
        resultsList: {
            element: (list, data) => {
                if (!data.results.length) {
                    const message = document.createElement("div");
                    message.setAttribute("class", "no_result");
                    message.innerHTML = `<span>Found No Results for "${data.query}"</span>`;
                    list.prepend(message);
                }
            },
            noResults: true,
        },
        resultItem: {
            highlight: true
        },
        events: {
            input: {
                selection: (event) => {
                    const selection = event.detail.selection.value;
                    autoCompleteJS.input.value = autoCompleteJS.input.value.replace(/[^,]*$/, '') + selection + ', ';
                }
            }
        }
    });
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/main.php';
?>

