<?php ob_start(); ?>

<div class="container mt-5">
    <h1 class="mb-4">Suas Notificações</h1>

    <?php if (empty($notifications)): ?>
        <p class="text-muted">Você não tem notificações no momento.</p>
    <?php else: ?>
        <div class="list-group">
            <?php foreach ($notifications as $notification): ?>
                <div class="list-group-item list-group-item-action <?php echo $notification['is_read'] ? '' : 'bg-light'; ?>">
                    <div class="d-flex w-100 justify-content-between">
                        <h5 class="mb-1"><?php echo htmlspecialchars($notification['title']); ?></h5>
                        <small><?php echo date('d/m/Y H:i', strtotime($notification['created_at'])); ?></small>
                    </div>
                    <p class="mb-1"><?php echo htmlspecialchars($notification['message']); ?></p>
                    <?php if (!$notification['is_read']): ?>
                        <button class="btn btn-sm btn-primary mt-2 mark-as-read" data-notification-id="<?php echo $notification['id']; ?>">Marcar como lida</button>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const markAsReadButtons = document.querySelectorAll('.mark-as-read');
    markAsReadButtons.forEach(button => {
        button.addEventListener('click', function() {
            const notificationId = this.getAttribute('data-notification-id');
            fetch('/notifications/mark-as-read', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'notification_id=' + notificationId
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.closest('.list-group-item').classList.remove('bg-light');
                    this.remove();
                } else {
                    alert('Erro ao marcar notificação como lida. Por favor, tente novamente.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Ocorreu um erro. Por favor, tente novamente mais tarde.');
            });
        });
    });
});
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../views/layout/main.php';
?>

