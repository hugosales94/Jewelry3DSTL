<?php ob_start(); ?>

<div class="container mt-4">
    <h1>Search Results</h1>

    <form action="/search" method="GET" class="mb-4">
        <div class="row">
            <div class="col-md-6">
                <input type="text" name="q" value="<?php echo htmlspecialchars($query); ?>" class="form-control" placeholder="Search for designs...">
            </div>
            <div class="col-md-3">
                <select name="category" class="form-select">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat['category']; ?>" <?php echo $category === $cat['category'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cat['category']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <select name="sort" class="form-select">
                    <option value="newest" <?php echo $sort === 'newest' ? 'selected' : ''; ?>>Newest</option>
                    <option value="popular" <?php echo $sort === 'popular' ? 'selected' : ''; ?>>Most Popular</option>
                    <option value="downloads" <?php echo $sort === 'downloads' ? 'selected' : ''; ?>>Most Downloads</option>
                </select>
            </div>
        </div>
        <button type="submit" class="btn btn-primary mt-2">Search</button>
    </form>

    <div class="row">
        <?php foreach ($results as $file): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="/uploads/thumbnails/<?php echo $file['thumbnail']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($file['name']); ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars($file['name']); ?></h5>
                        <p class="card-text">
                            <small class="text-muted">By: <?php echo htmlspecialchars($file['username']); ?></small>
                        </p>
                        <p class="card-text">
                            <small class="text-muted">Downloads: <?php echo $file['downloads']; ?></small>
                        </p>
                        <a href="/file/<?php echo $file['id']; ?>" class="btn btn-primary btn-sm">View Details</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <?php if ($totalPages > 1): ?>
        <nav aria-label="Search results pages">
            <ul class="pagination justify-content-center">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?php echo $page === $i ? 'active' : ''; ?>">
                        <a class="page-link" href="/search?q=<?php echo urlencode($query); ?>&category=<?php echo urlencode($category); ?>&sort=<?php echo urlencode($sort); ?>&page=<?php echo $i; ?>">
                            <?php echo $i; ?>
                        </a>
                    </li>
                <?php endfor; ?>
            </ul>
        </nav>
    <?php endif; ?>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/main.php';
?>

