<?php ob_start(); ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body text-center">
                    <h1 class="card-title text-success">Pagamento Bem-sucedido!</h1>
                    <p class="card-text">Sua assinatura para o plano <?php echo htmlspecialchars($plan['name']); ?> foi ativada com sucesso.</p>
                    <p class="card-text">Você agora tem acesso a <?php echo $plan['downloads']; ?> downloads por <?php echo $plan['duration']; ?> dias.</p>
                    <a href="/dashboard" class="btn btn-primary mt-3">Ir para o Dashboard</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../views/layout/main.php';
?>

