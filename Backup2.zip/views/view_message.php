<?php ob_start(); ?>

<div class="container mt-4">
    <h1><?php echo htmlspecialchars($message['subject']); ?></h1>
    <p>
        <strong>From:</strong> <?php echo htmlspecialchars($message['sender_name']); ?><br>
        <strong>Date:</strong> <?php echo date('M d, Y H:i', strtotime($message['created_at'])); ?>
    </p>
    <div class="card">
        <div class="card-body">
            <?php echo nl2br(htmlspecialchars($message['content'])); ?>
        </div>
    </div>
    <a href="/messages/compose?reply_to=<?php echo $message['id']; ?>" class="btn btn-primary mt-3">Reply</a>
    <a href="/messages/inbox" class="btn btn-secondary mt-3">Back to Inbox</a>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/main.php';
?>

