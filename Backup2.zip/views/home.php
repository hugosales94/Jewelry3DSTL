<?php ob_start(); ?>

<div class="container mt-4">
    <h1 class="text-center mb-4">Welcome to STL Jewelry 3D</h1>
    
    <div class="row">
        <div class="col-md-8">
            <h2>Featured Designs</h2>
            <div class="row">
                <?php foreach ($featuredDesigns as $design): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?php echo htmlspecialchars($design['thumbnail_url']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($design['name']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($design['name']); ?></h5>
                                <p class="card-text">
                                    <small class="text-muted">By: <?php echo htmlspecialchars($design['username']); ?></small>
                                </p>
                                <a href="/file/<?php echo $design['id']; ?>" class="btn btn-primary btn-sm">View Details</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Join STL Jewelry 3D</h5>
                    <p class="card-text">Create an account to start uploading and downloading 3D jewelry designs.</p>
                    <a href="/register" class="btn btn-primary">Sign Up Now</a>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Latest Activity</h5>
                    <ul class="list-unstyled">
                        <?php foreach ($latestActivity as $activity): ?>
                            <li class="mb-2">
                                <strong><?php echo htmlspecialchars($activity['username']); ?></strong>
                                <?php echo $activity['action']; ?>
                                <small class="text-muted"><?php echo $activity['time_ago']; ?></small>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../views/layout/main.php';
?>

