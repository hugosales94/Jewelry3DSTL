<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to STL Jewelry 3D Installation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Welcome to STL Jewelry 3D Installation</h1>
        <p>This wizard will guide you through the installation process of STL Jewelry 3D platform.</p>
        <a href="/install/requirements" class="btn btn-primary">Start Installation</a>
    </div>
</body>
</html>

