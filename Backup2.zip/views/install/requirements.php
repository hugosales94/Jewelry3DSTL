<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STL Jewelry 3D Installation - Requirements Check</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">System Requirements Check</h1>
        <?php if (empty($errors)): ?>
            <div class="alert alert-success">All requirements are met!</div>
            <a href="/install/database" class="btn btn-primary">Continue to Database Configuration</a>
        <?php else: ?>
            <div class="alert alert-danger">
                <h4>The following requirements are not met:</h4>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <p>Please fix these issues and refresh the page.</p>
        <?php endif; ?>
    </div>
</body>
</html>

