<?php ob_start(); ?>

<h1>User Ranking</h1>

<div class="row">
    <div class="col-md-8">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Rank</th>
                    <th>Username</th>
                    <th>Score</th>
                    <th>Uploads</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($topUsers as $index => $user): ?>
                    <tr <?php echo $user['id'] == $_SESSION['user_id'] ? 'class="table-primary"' : ''; ?>>
                        <td><?php echo $index + 1; ?></td>
                        <td><a href="/user/profile/<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['username']); ?></a></td>
                        <td><?php echo number_format($user['score']); ?></td>
                        <td><?php echo $user['uploads']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Your Ranking</h5>
                <p class="card-text">Your current rank: <strong><?php echo $currentUserRank; ?></strong></p>
                <p class="card-text">Your score: <strong><?php echo number_format($currentUser['score']); ?></strong></p>
                <p class="card-text">Your uploads: <strong><?php echo $currentUser['uploads']; ?></strong></p>
                <a href="/user/profile/<?php echo $_SESSION['user_id']; ?>" class="btn btn-primary">View Your Profile</a>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/main.php';
?>

