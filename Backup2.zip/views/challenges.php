<?php ob_start(); ?>

<h1>Challenges</h1>

<div class="row">
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Weekly Challenge</h5>
                <p class="card-text"><?php echo htmlspecialchars($weeklyChallenge['description']); ?></p>
                <div class="progress mb-3">
                    <div class="progress-bar" role="progressbar" style="width: <?php echo ($challengeProgress / $weeklyChallenge['goal']) * 100; ?>%" aria-valuenow="<?php echo $challengeProgress; ?>" aria-valuemin="0" aria-valuemax="<?php echo $weeklyChallenge['goal']; ?>"></div>
                </div>
                <p>Progress: <?php echo $challengeProgress; ?> / <?php echo $weeklyChallenge['goal']; ?></p>
                <p>Reward: <?php echo $weeklyChallenge['reward_tokens']; ?> tokens</p>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Daily Challenge</h5>
                <p class="card-text"><?php echo htmlspecialchars($dailyChallenge['description']); ?></p>
                <div class="progress mb-3">
                    <div class="progress-bar" role="progressbar" style="width: <?php echo ($dailyChallengeProgress / $dailyChallenge['goal']) * 100; ?>%" aria-valuenow="<?php echo $dailyChallengeProgress; ?>" aria-valuemin="0" aria-valuemax="<?php echo $dailyChallenge['goal']; ?>"></div>
                </div>
                <p>Progress: <?php echo $dailyChallengeProgress; ?> / <?php echo $dailyChallenge['goal']; ?></p>
                <p>Reward: <?php echo $dailyChallenge['reward_tokens']; ?> tokens</p>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Daily Reward</h5>
                <p class="card-text">Don't forget to claim your daily reward!</p>
                <form action="/daily-reward" method="post">
                    <button type="submit" class="btn btn-primary">Claim Daily Reward</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/main.php';
?>

