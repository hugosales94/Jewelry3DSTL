<?php ob_start(); ?>

<div class="row">
    <div class="col-md-8">
        <h1><?php echo htmlspecialchars($file['name']); ?></h1>
        <p class="text-muted">Uploaded by: <a href="/user/profile/<?php echo $file['user_id']; ?>"><?php echo htmlspecialchars($file['username']); ?></a> on <?php echo date('F j, Y', strtotime($file['created_at'])); ?></p>
        
        <div id="stl_viewer" style="width:100%;height:400px;"></div>

        <div class="mt-4">
            <h3>Description</h3>
            <p><?php echo nl2br(htmlspecialchars($file['description'])); ?></p>
        </div>

        <div class="mt-4">
            <h3>File Details</h3>
            <ul>
                <li>Category: <?php echo htmlspecialchars($file['category']); ?></li>
                <li>File Size: <?php echo number_format($file['size'] / 1024 / 1024, 2); ?> MB</li>
                <li>Downloads: <?php echo $file['downloads']; ?></li>
                <li>Average Rating: <?php echo number_format($averageRating, 1); ?> / 5</li>
            </ul>
        </div>

        <?php if ($file['tags']): ?>
        <div class="mt-4">
            <h3>Tags</h3>
            <?php foreach (explode(',', $file['tags']) as $tag): ?>
                <span class="badge bg-secondary me-1"><?php echo htmlspecialchars(trim($tag)); ?></span>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="mt-4">
            <h3>Rate this file</h3>
            <form action="/file/<?php echo $file['id']; ?>/rate" method="post">
                <div class="mb-3">
                    <select name="rating" class="form-select" required>
                        <option value="">Select a rating</option>
                        <option value="1">1 - Poor</option>
                        <option value="2">2 - Fair</option>
                        <option value="3">3 - Average</option>
                        <option value="4">4 - Good</option>
                        <option value="5">5 - Excellent</option>
                    </select>
                </div>
                <div class="mb-3">
                    <textarea name="comment" class="form-control" rows="3" placeholder="Leave a comment (optional)"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Submit Rating</button>
            </form>
        </div>

        <div class="mt-4">
            <h3>Comments</h3>
            <?php if (empty($ratings)): ?>
                <p>No comments yet. Be the first to rate and comment on this file!</p>
            <?php else: ?>
                <?php foreach ($ratings as $rating): ?>
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($rating['username']); ?> rated it <?php echo $rating['rating']; ?> / 5</h5>
                            <h6 class="card-subtitle mb-2 text-muted"><?php echo date('F j, Y', strtotime($rating['created_at'])); ?></h6>
                            <p class="card-text"><?php echo nl2br(htmlspecialchars($rating['comment'])); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Download</h5>
                <p class="card-text">File Size: <?php echo number_format($file['size'] / 1024 / 1024, 2); ?> MB</p>
                <a href="/file/<?php echo $file['id']; ?>/download" class="btn btn-primary">Download STL File</a>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Creator</h5>
                <h6 class="card-subtitle mb-2 text-muted"><?php echo htmlspecialchars($file['username']); ?></h6>
                <p class="card-text">Member since: <?php echo date('F Y', strtotime($file['user_created_at'])); ?></p>
                <a href="/user/profile/<?php echo $file['user_id']; ?>" class="btn btn-outline-primary">View Profile</a>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Similar Files</h5>
                <ul class="list-unstyled">
                    <?php foreach ($similarFiles as $similarFile): ?>
                        <li class="mb-2">
                            <a href="/file/<?php echo $similarFile['id']; ?>"><?php echo htmlspecialchars($similarFile['name']); ?></a>
                            <br>
                            <small class="text-muted">by <?php echo htmlspecialchars($similarFile['username']); ?></small>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/three@0.132.2/build/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.132.2/examples/js/loaders/STLLoader.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.132.2/examples/js/controls/OrbitControls.js"></script>

<script>
    let scene, camera, renderer, mesh, controls;

    function init() {
        scene = new THREE.Scene();
        scene.background = new THREE.Color(0xffffff);

        camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.z = 5;

        renderer = new THREE.WebGLRenderer();
        renderer.setSize(document.getElementById('stl_viewer').offsetWidth, 400);
        document.getElementById('stl_viewer').appendChild(renderer.domElement);

        controls = new THREE.OrbitControls(camera, renderer.domElement);

        const loader = new THREE.STLLoader();
        loader.load('/uploads/<?php echo $file['filename']; ?>', function (geometry) {
            const material = new THREE.MeshPhongMaterial({ color: 0xAAAAAA, specular: 0x111111, shininess: 200 });
            mesh = new THREE.Mesh(geometry, material);
            
            // Center the mesh
            geometry.computeBoundingBox();
            const center = geometry.boundingBox.getCenter(new THREE.Vector3());
            mesh.position.sub(center);
            
            scene.add(mesh);

            // Add lights
            const ambientLight = new THREE.AmbientLight(0x404040);
            scene.add(ambientLight);

            const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
            directionalLight.position.set(1, 1, 1);
            scene.add(directionalLight);

            animate();
        });
    }

    function animate() {
        requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
    }

    init();

    window.addEventListener('resize', function() {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(document.getElementById('stl_viewer').offsetWidth, 400);
    });
</script>

<?php
$content = ob_get_clean();
require __DIR__ . '/../layout/main.php';
?>

