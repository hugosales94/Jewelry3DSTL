<?php

namespace App\Controllers;

require_once dirname(__DIR__) . '/models/Notification.php';
require_once dirname(__DIR__) . '/models/User.php';

use App\Models\Notification;
use App\Models\User;

class NotificationController {
    private $notificationModel;
    private $userModel;

    public function __construct() {
        $this->notificationModel = new Notification();
        $this->userModel = new User();
    }

    public function index() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                exit();
            }

            $userId = $_SESSION['user_id'];
            $notifications = $this->notificationModel->getUserNotifications($userId);

            // Mark notifications as read
            $this->notificationModel->markAsRead($userId);

            require dirname(__DIR__) . '/views/notifications/index.php';
        } catch (\Exception $e) {
            error_log("Error in NotificationController::index: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }

    public function getUnread() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Unauthorized']);
                exit();
            }

            $userId = $_SESSION['user_id'];
            $notifications = $this->notificationModel->getUnreadNotifications($userId);
            $count = count($notifications);

            header('Content-Type: application/json');
            echo json_encode([
                'count' => $count,
                'notifications' => $notifications
            ]);
        } catch (\Exception $e) {
            error_log("Error in NotificationController::getUnread: " . $e->getMessage());
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Internal server error']);
        }
    }

    public function markRead($id = null) {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Unauthorized']);
                exit();
            }

            $userId = $_SESSION['user_id'];

            if ($id) {
                // Mark specific notification as read
                $this->notificationModel->markNotificationAsRead($id, $userId);
            } else {
                // Mark all notifications as read
                $this->notificationModel->markAsRead($userId);
            }

            header('Content-Type: application/json');
            echo json_encode(['success' => true]);
        } catch (\Exception $e) {
            error_log("Error in NotificationController::markRead: " . $e->getMessage());
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Internal server error']);
        }
    }

    public function delete($id) {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Unauthorized']);
                exit();
            }

            $userId = $_SESSION['user_id'];
            $this->notificationModel->deleteNotification($id, $userId);

            header('Content-Type: application/json');
            echo json_encode(['success' => true]);
        } catch (\Exception $e) {
            error_log("Error in NotificationController::delete: " . $e->getMessage());
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Internal server error']);
        }
    }

    public function preferences() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                exit();
            }

            $userId = $_SESSION['user_id'];

            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $preferences = [
                    'email_notifications' => isset($_POST['email_notifications']),
                    'push_notifications' => isset($_POST['push_notifications']),
                    'notification_types' => $_POST['notification_types'] ?? []
                ];

                $this->userModel->updateNotificationPreferences($userId, $preferences);
                $_SESSION['success'] = 'Notification preferences updated successfully.';
                header('Location: /notifications/preferences');
                return;
            }

            $user = $this->userModel->getUserById($userId);
            require dirname(__DIR__) . '/views/notifications/preferences.php';
        } catch (\Exception $e) {
            error_log("Error in NotificationController::preferences: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }

    public function subscribe() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Unauthorized']);
                exit();
            }

            $userId = $_SESSION['user_id'];
            $subscription = json_decode(file_get_contents('php://input'), true);

            $this->notificationModel->saveSubscription($userId, $subscription);

            header('Content-Type: application/json');
            echo json_encode(['success' => true]);
        } catch (\Exception $e) {
            error_log("Error in NotificationController::subscribe: " . $e->getMessage());
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Internal server error']);
        }
    }

    public function unsubscribe() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Unauthorized']);
                exit();
            }

            $userId = $_SESSION['user_id'];
            $this->notificationModel->removeSubscription($userId);

            header('Content-Type: application/json');
            echo json_encode(['success' => true]);
        } catch (\Exception $e) {
            error_log("Error in NotificationController::unsubscribe: " . $e->getMessage());
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Internal server error']);
        }
    }
}