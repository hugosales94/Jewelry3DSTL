<?php

namespace App\Controllers;

require_once dirname(__DIR__) . '/models/User.php';
require_once dirname(__DIR__) . '/models/File.php';
require_once dirname(__DIR__) . '/models/Report.php';
require_once dirname(__DIR__) . '/models/Payment.php';
require_once dirname(__DIR__) . '/models/Subscription.php';
require_once dirname(__DIR__) . '/models/Notification.php';

use App\Models\User;
use App\Models\File;
use App\Models\Report;
use App\Models\Payment;
use App\Models\Subscription;
use App\Models\Notification;

class AdminController {
    private $userModel;
    private $fileModel;
    private $reportModel;
    private $paymentModel;
    private $subscriptionModel;
    private $notificationModel;
    
    public function __construct() {
        $this->userModel = new User();
        $this->fileModel = new File();
        $this->reportModel = new Report();
        $this->paymentModel = new Payment();
        $this->subscriptionModel = new Subscription();
        $this->notificationModel = new Notification();
    }
    
    private function checkAdminAccess() {
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
            header('Location: /login');
            exit();
        }
    }
    
    public function dashboard() {
        try {
            $this->checkAdminAccess();
            
            // Get dashboard statistics
            $stats = [
                'users' => $this->userModel->getTotalUsers(),
                'active_users' => $this->userModel->getActiveUsers(),
                'files' => $this->fileModel->getTotalFiles(),
                'pending_reports' => $this->reportModel->getPendingReportsCount(),
                'revenue' => $this->paymentModel->getTotalRevenue(),
                'active_subscriptions' => $this->subscriptionModel->getActiveSubscriptionsCount()
            ];
            
            // Get recent activity
            $recentActivity = [
                'new_users' => $this->userModel->getRecentUsers(5),
                'new_files' => $this->fileModel->getRecentFiles(5),
                'recent_payments' => $this->paymentModel->getRecentPayments(5)
            ];
            
            require dirname(__DIR__) . '/views/admin/dashboard.php';
        } catch (\Exception $e) {
            error_log("Error in AdminController::dashboard: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function users() {
        try {
            $this->checkAdminAccess();
            
            $page = $_GET['page'] ?? 1;
            $limit = 20;
            $offset = ($page - 1) * $limit;
            
            $users = $this->userModel->getAllUsers($limit, $offset);
            $totalUsers = $this->userModel->getTotalUsers();
            $totalPages = ceil($totalUsers / $limit);
            
            require dirname(__DIR__) . '/views/admin/users.php';
        } catch (\Exception $e) {
            error_log("Error in AdminController::users: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function editUser($id) {
        try {
            $this->checkAdminAccess();
            
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $userData = [
                    'username' => $_POST['username'],
                    'email' => $_POST['email'],
                    'role' => $_POST['role'],
                    'status' => $_POST['status']
                ];
                
                $this->userModel->updateUser($id, $userData);
                $_SESSION['success'] = 'User updated successfully.';
                header('Location: /admin/users');
                return;
            }
            
            $user = $this->userModel->getUserById($id);
            if (!$user) {
                require dirname(__DIR__) . '/views/error/404.php';
                return;
            }
            
            require dirname(__DIR__) . '/views/admin/edit-user.php';
        } catch (\Exception $e) {
            error_log("Error in AdminController::editUser: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function reports() {
        try {
            $this->checkAdminAccess();
            
            $status = $_GET['status'] ?? 'pending';
            $reports = $this->reportModel->getReportsByStatus($status);
            
            require dirname(__DIR__) . '/views/admin/reports.php';
        } catch (\Exception $e) {
            error_log("Error in AdminController::reports: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function handleReport($id) {
        try {
            $this->checkAdminAccess();
            
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                $report = $this->reportModel->getReportById($id);
                require dirname(__DIR__) . '/views/admin/handle-report.php';
                return;
            }
            
            $resolution = $_POST['resolution'];
            $action = $_POST['action'];
            
            $this->reportModel->updateReportStatus($id, $action, $_SESSION['user_id'], $resolution);
            
            if ($action === 'resolved') {
                // Take action on reported content/user if necessary
                $report = $this->reportModel->getReportById($id);
                switch ($report['type']) {
                    case 'user':
                        $this->userModel->updateStatus($report['reported_user_id'], 'suspended');
                        break;
                    case 'file':
                        $this->fileModel->updateStatus($report['content_id'], 'removed');
                        break;
                }
            }
            
            $_SESSION['success'] = 'Report handled successfully.';
            header('Location: /admin/reports');
        } catch (\Exception $e) {
            error_log("Error in AdminController::handleReport: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function payments() {
        try {
            $this->checkAdminAccess();
            
            $startDate = $_GET['start_date'] ?? date('Y-m-d', strtotime('-30 days'));
            $endDate = $_GET['end_date'] ?? date('Y-m-d');
            
            $payments = $this->paymentModel->getPaymentsByDateRange($startDate, $endDate);
            $stats = $this->paymentModel->getPaymentStats($startDate, $endDate);
            
            require dirname(__DIR__) . '/views/admin/payments.php';
        } catch (\Exception $e) {
            error_log("Error in AdminController::payments: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function files() {
        try {
            $this->checkAdminAccess();
            
            $status = $_GET['status'] ?? 'pending';
            $files = $this->fileModel->getFilesByStatus($status);
            
            require dirname(__DIR__) . '/views/admin/files.php';
        } catch (\Exception $e) {
            error_log("Error in AdminController::files: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function reviewFile($id) {
        try {
            $this->checkAdminAccess();
            
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $status = $_POST['status'];
                $reason = $_POST['reason'] ?? null;
                
                $this->fileModel->updateFileStatus($id, $status, $reason);
                
                $file = $this->fileModel->getFileById($id);
                $this->notificationModel->create([
                    'user_id' => $file['user_id'],
                    'type' => 'file_review',
                    'title' => 'File Review Complete',
                    'message' => "Your file has been {$status}." . ($reason ? " Reason: {$reason}" : ''),
                    'link' => "/files/{$id}"
                ]);
                
                $_SESSION['success'] = 'File review completed successfully.';
                header('Location: /admin/files');
                return;
            }
            
            $file = $this->fileModel->getFileById($id);
            require dirname(__DIR__) . '/views/admin/review-file.php';
        } catch (\Exception $e) {
            error_log("Error in AdminController::reviewFile: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function settings() {
        try {
            $this->checkAdminAccess();
            
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                // Update system settings
                // Implement your settings update logic here
                $_SESSION['success'] = 'Settings updated successfully.';
                header('Location: /admin/settings');
                return;
            }
            
            require dirname(__DIR__) . '/views/admin/settings.php';
        } catch (\Exception $e) {
            error_log("Error in AdminController::settings: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
}