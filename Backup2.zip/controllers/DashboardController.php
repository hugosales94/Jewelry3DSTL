<?php

namespace App\Controllers;

class DashboardController {
    
    public function index() {
        // Check if user is authenticated
        if (!isset($_SESSION['user_id'])) {
            header('Location: /login');
            exit;
        }

        // Get user data
        $userId = $_SESSION['user_id'];
        $db = Database::getInstance();
        
        // Fetch user's recent activity
        $recentActivity = $db->query("
            SELECT * FROM user_activity 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT 5
        ", [$userId]);

        // Fetch user's statistics
        $userStats = $db->query("
            SELECT 
                COUNT(DISTINCT f.id) as total_files,
                SUM(f.download_count) as total_downloads,
                COUNT(DISTINCT r.id) as total_ratings
            FROM files f
            LEFT JOIN ratings r ON f.id = r.file_id
            WHERE f.user_id = ?
        ", [$userId])->fetch();

        // Fetch user's badges
        $badges = $db->query("
            SELECT b.* 
            FROM badges b
            JOIN user_badges ub ON b.id = ub.badge_id
            WHERE ub.user_id = ?
        ", [$userId]);

        // Fetch subscription status
        $subscription = $db->query("
            SELECT * FROM subscriptions 
            WHERE user_id = ? 
            AND status = 'active'
            AND end_date > NOW()
        ", [$userId])->fetch();

        // Render dashboard view with data
        require_once BASE_PATH . '/views/dashboard.php';
    }

    public function getStats() {
        if (!isset($_SESSION['user_id'])) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }

        $userId = $_SESSION['user_id'];
        $db = Database::getInstance();

        // Get monthly statistics
        $monthlyStats = $db->query("
            SELECT 
                DATE_FORMAT(created_at, '%Y-%m') as month,
                COUNT(*) as uploads,
                SUM(download_count) as downloads
            FROM files
            WHERE user_id = ?
            GROUP BY DATE_FORMAT(created_at, '%Y-%m')
            ORDER BY month DESC
            LIMIT 12
        ", [$userId]);

        echo json_encode([
            'success' => true,
            'data' => $monthlyStats
        ]);
    }

    public function updatePreferences() {
        if (!isset($_SESSION['user_id'])) {
            http_response_code(401);
            echo json_encode(['error' => 'Unauthorized']);
            exit;
        }

        $userId = $_SESSION['user_id'];
        $notifications = isset($_POST['notifications']) ? 1 : 0;
        $emailUpdates = isset($_POST['email_updates']) ? 1 : 0;
        $publicProfile = isset($_POST['public_profile']) ? 1 : 0;

        $db = Database::getInstance();
        
        try {
            $db->query("
                UPDATE user_preferences 
                SET 
                    notifications = ?,
                    email_updates = ?,
                    public_profile = ?
                WHERE user_id = ?
            ", [$notifications, $emailUpdates, $publicProfile, $userId]);

            echo json_encode([
                'success' => true,
                'message' => 'Preferences updated successfully'
            ]);
        } catch (\Exception $e) {
            http_response_code(500);
            echo json_encode([
                'error' => 'Failed to update preferences',
                'message' => $e->getMessage()
            ]);
        }
    }
}