<?php

namespace App\Controllers;

require_once dirname(__DIR__) . '/models/File.php';
require_once dirname(__DIR__) . '/models/User.php';
require_once dirname(__DIR__) . '/models/Rating.php';
require_once dirname(__DIR__) . '/models/RecommendationModel.php';
require_once dirname(__DIR__) . '/utils/Mailer.php';

use App\Models\File;
use App\Models\User;
use App\Models\Rating;
use App\Models\RecommendationModel;

class FileController {
    private $fileModel;
    private $userModel;
    private $ratingModel;
    private $recommendationModel;
    
    public function __construct() {
        $this->fileModel = new File();
        $this->userModel = new User();
        $this->ratingModel = new Rating();
        $this->recommendationModel = new RecommendationModel();
    }
    
    public function index() {
        try {
            $files = $this->fileModel->getAllFiles();
            require dirname(__DIR__) . '/views/files/index.php';
        } catch (\Exception $e) {
            error_log("Error in FileController::index: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function view($id) {
        try {
            $file = $this->fileModel->getFileById($id);
            if (!$file) {
                require dirname(__DIR__) . '/views/error/404.php';
                return;
            }
            
            $similarFiles = $this->recommendationModel->getSimilarFiles($id);
            $ratings = $this->ratingModel->getFileRatings($id);
            
            require dirname(__DIR__) . '/views/files/view.php';
        } catch (\Exception $e) {
            error_log("Error in FileController::view: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function upload() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            require dirname(__DIR__) . '/views/files/upload.php';
            return;
        }
        
        try {
            if (!isset($_SESSION['user_id'])) {
                $_SESSION['error'] = 'Please login to upload files.';
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $user = $this->userModel->getUserById($userId);
            
            if (!$user || $user['status'] !== 'active') {
                $_SESSION['error'] = 'Your account must be active to upload files.';
                header('Location: /dashboard');
                return;
            }
            
            $fileData = [
                'user_id' => $userId,
                'title' => $_POST['title'],
                'description' => $_POST['description'],
                'category_id' => $_POST['category_id'],
                'status' => 'pending'
            ];
            
            $uploadedFile = $_FILES['file'];
            $fileId = $this->fileModel->uploadFile($fileData, $uploadedFile);
            
            $_SESSION['success'] = 'File uploaded successfully and pending review.';
            header("Location: /files/view/{$fileId}");
            
        } catch (\Exception $e) {
            error_log("Error in FileController::upload: " . $e->getMessage());
            $_SESSION['error'] = 'Failed to upload file. Please try again.';
            require dirname(__DIR__) . '/views/files/upload.php';
        }
    }
    
    public function download($id) {
        try {
            if (!isset($_SESSION['user_id'])) {
                $_SESSION['error'] = 'Please login to download files.';
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $user = $this->userModel->getUserById($userId);
            
            if (!$user || $user['status'] !== 'active') {
                $_SESSION['error'] = 'Your account must be active to download files.';
                header('Location: /dashboard');
                return;
            }
            
            $file = $this->fileModel->getFileById($id);
            if (!$file || $file['status'] !== 'approved') {
                require dirname(__DIR__) . '/views/error/404.php';
                return;
            }
            
            $downloadUrl = $this->fileModel->getDownloadUrl($id, $userId);
            header("Location: {$downloadUrl}");
            
        } catch (\Exception $e) {
            error_log("Error in FileController::download: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function rate($id) {
        try {
            if (!isset($_SESSION['user_id'])) {
                http_response_code(401);
                echo json_encode(['error' => 'Please login to rate files.']);
                return;
            }
            
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                http_response_code(405);
                echo json_encode(['error' => 'Method not allowed']);
                return;
            }
            
            $data = json_decode(file_get_contents('php://input'), true);
            $rating = $data['rating'] ?? null;
            
            if (!$rating || !is_numeric($rating) || $rating < 1 || $rating > 5) {
                http_response_code(400);
                echo json_encode(['error' => 'Invalid rating value']);
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $this->ratingModel->rateFile($id, $userId, $rating);
            
            $averageRating = $this->ratingModel->getAverageRating($id);
            echo json_encode([
                'success' => true,
                'average_rating' => $averageRating
            ]);
            
        } catch (\Exception $e) {
            error_log("Error in FileController::rate: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['error' => 'Failed to submit rating']);
        }
    }
    
    public function search() {
        try {
            $query = $_GET['q'] ?? '';
            $category = $_GET['category'] ?? null;
            $sort = $_GET['sort'] ?? 'newest';
            
            $files = $this->fileModel->searchFiles($query, $category, $sort);
            require dirname(__DIR__) . '/views/files/search.php';
            
        } catch (\Exception $e) {
            error_log("Error in FileController::search: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function delete($id) {
        try {
            if (!isset($_SESSION['user_id'])) {
                $_SESSION['error'] = 'Please login to delete files.';
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $file = $this->fileModel->getFileById($id);
            
            if (!$file) {
                require dirname(__DIR__) . '/views/error/404.php';
                return;
            }
            
            if ($file['user_id'] !== $userId && $_SESSION['user_role'] !== 'admin') {
                require dirname(__DIR__) . '/views/error/403.php';
                return;
            }
            
            $this->fileModel->deleteFile($id);
            $_SESSION['success'] = 'File deleted successfully.';
            header('Location: /dashboard');
            
        } catch (\Exception $e) {
            error_log("Error in FileController::delete: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
}