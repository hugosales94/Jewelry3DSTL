<?php

namespace App\Controllers;

class AuthController {
    private $db;
    
    public function __construct() {
        $this->db = \Database::getInstance();
    }
    
    public function showLoginForm() {
        // Check if already logged in
        if (isset($_SESSION['user_id'])) {
            header('Location: /dashboard');
            exit;
        }
        
        require_once BASE_PATH . '/views/auth/login.php';
    }
    
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /login');
            exit;
        }
        
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $remember = isset($_POST['remember']);
        
        try {
            // Validate input
            if (empty($email) || empty($password)) {
                throw new \Exception('Email and password are required');
            }
            
            // Get user by email
            $user = $this->db->query(
                "SELECT * FROM users WHERE email = ? AND status = 'active' LIMIT 1",
                [$email]
            )->fetch();
            
            if (!$user || !password_verify($password, $user['password'])) {
                throw new \Exception('Invalid email or password');
            }
            
            // Set session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['username'];
            $_SESSION['user_role'] = $user['role'];
            
            // Set remember me cookie if requested
            if ($remember) {
                $token = bin2hex(random_bytes(32));
                $expiry = time() + (30 * 24 * 60 * 60); // 30 days
                
                $this->db->query(
                    "INSERT INTO remember_tokens (user_id, token, expires_at) VALUES (?, ?, ?)",
                    [$user['id'], $token, date('Y-m-d H:i:s', $expiry)]
                );
                
                setcookie('remember_token', $token, $expiry, '/', '', true, true);
            }
            
            // Log login
            $this->db->query(
                "INSERT INTO login_logs (user_id, ip_address, user_agent) VALUES (?, ?, ?)",
                [$user['id'], $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]
            );
            
            // Redirect to dashboard
            header('Location: /dashboard');
            exit;
            
        } catch (\Exception $e) {
            $_SESSION['login_error'] = $e->getMessage();
            header('Location: /login');
            exit;
        }
    }
    
    public function showRegistrationForm() {
        if (isset($_SESSION['user_id'])) {
            header('Location: /dashboard');
            exit;
        }
        
        require_once BASE_PATH . '/views/auth/register.php';
    }
    
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: /register');
            exit;
        }
        
        $username = $_POST['username'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $passwordConfirm = $_POST['password_confirm'] ?? '';
        
        try {
            // Validate input
            if (empty($username) || empty($email) || empty($password)) {
                throw new \Exception('All fields are required');
            }
            
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new \Exception('Invalid email format');
            }
            
            if (strlen($password) < 8) {
                throw new \Exception('Password must be at least 8 characters long');
            }
            
            if ($password !== $passwordConfirm) {
                throw new \Exception('Passwords do not match');
            }
            
            // Check if email already exists
            $existingUser = $this->db->query(
                "SELECT id FROM users WHERE email = ?",
                [$email]
            )->fetch();
            
            if ($existingUser) {
                throw new \Exception('Email already registered');
            }
            
            // Check if username already exists
            $existingUsername = $this->db->query(
                "SELECT id FROM users WHERE username = ?",
                [$username]
            )->fetch();
            
            if ($existingUsername) {
                throw new \Exception('Username already taken');
            }
            
            // Create user
            $verificationToken = bin2hex(random_bytes(32));
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            $this->db->query(
                "INSERT INTO users (username, email, password, verification_token, created_at) 
                 VALUES (?, ?, ?, ?, NOW())",
                [$username, $email, $hashedPassword, $verificationToken]
            );
            
            $userId = $this->db->lastInsertId();
            
            // Send verification email
            $verificationLink = APP_URL . "/verify-email?token=" . $verificationToken;
            
            $to = $email;
            $subject = "Verify your email address";
            $message = "
                <h2>Welcome to " . APP_NAME . "!</h2>
                <p>Please click the link below to verify your email address:</p>
                <p><a href=\"{$verificationLink}\">{$verificationLink}</a></p>
                <p>If you didn't create this account, you can safely ignore this email.</p>
            ";
            
            $headers = "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM_ADDRESS . ">\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
            
            mail($to, $subject, $message, $headers);
            
            // Set success message
            $_SESSION['registration_success'] = true;
            
            // Redirect to login
            header('Location: /login');
            exit;
            
        } catch (\Exception $e) {
            $_SESSION['registration_error'] = $e->getMessage();
            header('Location: /register');
            exit;
        }
    }
    
    public function verifyEmail() {
        $token = $_GET['token'] ?? '';
        
        try {
            if (empty($token)) {
                throw new \Exception('Invalid verification token');
            }
            
            // Find user by token
            $user = $this->db->query(
                "SELECT id FROM users WHERE verification_token = ? AND email_verified_at IS NULL",
                [$token]
            )->fetch();
            
            if (!$user) {
                throw new \Exception('Invalid or expired verification token');
            }
            
            // Update user
            $this->db->query(
                "UPDATE users SET email_verified_at = NOW(), verification_token = NULL WHERE id = ?",
                [$user['id']]
            );
            
            $_SESSION['verification_success'] = true;
            header('Location: /login');
            exit;
            
        } catch (\Exception $e) {
            $_SESSION['verification_error'] = $e->getMessage();
            header('Location: /login');
            exit;
        }
    }
    
    public function logout() {
        // Clear remember token if exists
        if (isset($_COOKIE['remember_token'])) {
            $token = $_COOKIE['remember_token'];
            
            // Delete token from database
            $this->db->query(
                "DELETE FROM remember_tokens WHERE token = ?",
                [$token]
            );
            
            // Delete cookie
            setcookie('remember_token', '', time() - 3600, '/', '', true, true);
        }
        
        // Clear session
        session_destroy();
        
        // Redirect to login
        header('Location: /login');
        exit;
    }
    
    public function forgotPassword() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            
            try {
                if (empty($email)) {
                    throw new \Exception('Email is required');
                }
                
                // Find user
                $user = $this->db->query(
                    "SELECT id, username FROM users WHERE email = ? AND status = 'active'",
                    [$email]
                )->fetch();
                
                if ($user) {
                    // Generate reset token
                    $token = bin2hex(random_bytes(32));
                    $expiry = date('Y-m-d H:i:s', time() + (2 * 60 * 60)); // 2 hours
                    
                    // Save token
                    $this->db->query(
                        "INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)",
                        [$user['id'], $token, $expiry]
                    );
                    
                    // Send email
                    $resetLink = APP_URL . "/reset-password?token=" . $token;
                    
                    $to = $email;
                    $subject = "Reset your password";
                    $message = "
                        <h2>Password Reset Request</h2>
                        <p>Hi {$user['username']},</p>
                        <p>You recently requested to reset your password. Click the link below to proceed:</p>
                        <p><a href=\"{$resetLink}\">{$resetLink}</a></p>
                        <p>This link will expire in 2 hours.</p>
                        <p>If you didn't request this, you can safely ignore this email.</p>
                    ";
                    
                    $headers = "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM_ADDRESS . ">\r\n";
                    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                    
                    mail($to, $subject, $message, $headers);
                }
                
                // Always show success to prevent email enumeration
                $_SESSION['forgot_password_success'] = true;
                header('Location: /forgot-password');
                exit;
                
            } catch (\Exception $e) {
                $_SESSION['forgot_password_error'] = $e->getMessage();
                header('Location: /forgot-password');
                exit;
            }
        }
        
        require_once BASE_PATH . '/views/auth/forgot-password.php';
    }
    
    public function resetPassword() {
        $token = $_GET['token'] ?? '';
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $password = $_POST['password'] ?? '';
            $passwordConfirm = $_POST['password_confirm'] ?? '';
            
            try {
                if (empty($password) || empty($passwordConfirm)) {
                    throw new \Exception('All fields are required');
                }
                
                if (strlen($password) < 8) {
                    throw new \Exception('Password must be at least 8 characters long');
                }
                
                if ($password !== $passwordConfirm) {
                    throw new \Exception('Passwords do not match');
                }
                
                // Find valid reset token
                $reset = $this->db->query(
                    "SELECT user_id FROM password_resets 
                     WHERE token = ? AND expires_at > NOW() AND used = 0
                     ORDER BY created_at DESC LIMIT 1",
                    [$token]
                )->fetch();
                
                if (!$reset) {
                    throw new \Exception('Invalid or expired reset token');
                }
                
                // Update password
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                $this->db->query(
                    "UPDATE users SET password = ? WHERE id = ?",
                    [$hashedPassword, $reset['user_id']]
                );
                
                // Mark token as used
                $this->db->query(
                    "UPDATE password_resets SET used = 1 WHERE token = ?",
                    [$token]
                );
                
                $_SESSION['password_reset_success'] = true;
                header('Location: /login');
                exit;
                
            } catch (\Exception $e) {
                $_SESSION['password_reset_error'] = $e->getMessage();
                header("Location: /reset-password?token=$token");
                exit;
            }
        }
        
        // Verify token
        $reset = $this->db->query(
            "SELECT user_id FROM password_resets 
             WHERE token = ? AND expires_at > NOW() AND used = 0
             ORDER BY created_at DESC LIMIT 1",
            [$token]
        )->fetch();
        
        if (!$reset) {
            $_SESSION['password_reset_error'] = 'Invalid or expired reset token';
            header('Location: /forgot-password');
            exit;
        }
        
        require_once BASE_PATH . '/views/auth/reset-password.php';
    }
}