<?php

namespace App\Controllers;

require_once dirname(__DIR__) . '/models/User.php';
require_once dirname(__DIR__) . '/models/File.php';
require_once dirname(__DIR__) . '/models/Subscription.php';
require_once dirname(__DIR__) . '/models/Notification.php';
require_once dirname(__DIR__) . '/utils/Mailer.php';

use App\Models\User;
use App\Models\File;
use App\Models\Subscription;
use App\Models\Notification;

class UserController {
    private $userModel;
    private $fileModel;
    private $subscriptionModel;
    private $notificationModel;
    
    public function __construct() {
        $this->userModel = new User();
        $this->fileModel = new File();
        $this->subscriptionModel = new Subscription();
        $this->notificationModel = new Notification();
    }
    
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            require dirname(__DIR__) . '/views/auth/register.php';
            return;
        }
        
        try {
            $userData = [
                'username' => $_POST['username'],
                'email' => $_POST['email'],
                'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
                'role' => 'user',
                'status' => 'pending'
            ];
            
            $userId = $this->userModel->createUser($userData);
            
            // Send verification email
            $verificationToken = bin2hex(random_bytes(32));
            $this->userModel->setVerificationToken($userId, $verificationToken);
            
            $mailer = new \Mailer();
            $mailer->sendVerificationEmail($userData['email'], $verificationToken);
            
            $_SESSION['success'] = 'Registration successful! Please check your email to verify your account.';
            header('Location: /login');
            
        } catch (\Exception $e) {
            error_log("Error in UserController::register: " . $e->getMessage());
            $_SESSION['error'] = 'Registration failed. Please try again.';
            require dirname(__DIR__) . '/views/auth/register.php';
        }
    }
    
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            require dirname(__DIR__) . '/views/auth/login.php';
            return;
        }
        
        try {
            $email = $_POST['email'];
            $password = $_POST['password'];
            
            $user = $this->userModel->getUserByEmail($email);
            
            if (!$user || !password_verify($password, $user['password'])) {
                $_SESSION['error'] = 'Invalid email or password.';
                require dirname(__DIR__) . '/views/auth/login.php';
                return;
            }
            
            if ($user['status'] !== 'active') {
                $_SESSION['error'] = 'Please verify your email address to login.';
                require dirname(__DIR__) . '/views/auth/login.php';
                return;
            }
            
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_role'] = $user['role'];
            
            header('Location: /dashboard');
            
        } catch (\Exception $e) {
            error_log("Error in UserController::login: " . $e->getMessage());
            $_SESSION['error'] = 'Login failed. Please try again.';
            require dirname(__DIR__) . '/views/auth/login.php';
        }
    }
    
    public function verify($token) {
        try {
            $user = $this->userModel->getUserByVerificationToken($token);
            
            if (!$user) {
                $_SESSION['error'] = 'Invalid verification token.';
                header('Location: /login');
                return;
            }
            
            $this->userModel->activateUser($user['id']);
            $_SESSION['success'] = 'Email verified successfully! You can now login.';
            header('Location: /login');
            
        } catch (\Exception $e) {
            error_log("Error in UserController::verify: " . $e->getMessage());
            $_SESSION['error'] = 'Verification failed. Please try again.';
            header('Location: /login');
        }
    }
    
    public function logout() {
        session_destroy();
        header('Location: /login');
    }
    
    public function dashboard() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $user = $this->userModel->getUserById($userId);
            
            if (!$user) {
                session_destroy();
                header('Location: /login');
                return;
            }
            
            $userFiles = $this->fileModel->getUserFiles($userId);
            $subscription = $this->subscriptionModel->getActiveSubscription($userId);
            $notifications = $this->notificationModel->getUserNotifications($userId, 5);
            
            require dirname(__DIR__) . '/views/user/dashboard.php';
            
        } catch (\Exception $e) {
            error_log("Error in UserController::dashboard: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function profile() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $user = $this->userModel->getUserById($userId);
            
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $updateData = [
                    'username' => $_POST['username'],
                    'bio' => $_POST['bio'] ?? null
                ];
                
                if (!empty($_POST['password'])) {
                    $updateData['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
                }
                
                $this->userModel->updateUser($userId, $updateData);
                $_SESSION['success'] = 'Profile updated successfully.';
            }
            
            require dirname(__DIR__) . '/views/user/profile.php';
            
        } catch (\Exception $e) {
            error_log("Error in UserController::profile: " . $e->getMessage());
            $_SESSION['error'] = 'Failed to update profile.';
            require dirname(__DIR__) . '/views/user/profile.php';
        }
    }
    
    public function resetPassword() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            require dirname(__DIR__) . '/views/auth/reset-password.php';
            return;
        }
        
        try {
            $email = $_POST['email'];
            $user = $this->userModel->getUserByEmail($email);
            
            if ($user) {
                $resetToken = bin2hex(random_bytes(32));
                $this->userModel->setResetToken($user['id'], $resetToken);
                
                $mailer = new \Mailer();
                $mailer->sendPasswordResetEmail($email, $resetToken);
            }
            
            $_SESSION['success'] = 'If an account exists with this email, you will receive password reset instructions.';
            header('Location: /login');
            
        } catch (\Exception $e) {
            error_log("Error in UserController::resetPassword: " . $e->getMessage());
            $_SESSION['error'] = 'Password reset failed. Please try again.';
            require dirname(__DIR__) . '/views/auth/reset-password.php';
        }
    }
    
    public function confirmReset($token) {
        try {
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $user = $this->userModel->getUserByResetToken($token);
                
                if (!$user) {
                    $_SESSION['error'] = 'Invalid or expired reset token.';
                    header('Location: /login');
                    return;
                }
                
                $newPassword = password_hash($_POST['password'], PASSWORD_DEFAULT);
                $this->userModel->updatePassword($user['id'], $newPassword);
                
                $_SESSION['success'] = 'Password updated successfully. You can now login.';
                header('Location: /login');
                return;
            }
            
            require dirname(__DIR__) . '/views/auth/confirm-reset.php';
            
        } catch (\Exception $e) {
            error_log("Error in UserController::confirmReset: " . $e->getMessage());
            $_SESSION['error'] = 'Password reset failed. Please try again.';
            header('Location: /login');
        }
    }
}