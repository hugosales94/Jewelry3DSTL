<?php

namespace App\Controllers;

require_once dirname(__DIR__) . '/models/SpecialEvent.php';
require_once dirname(__DIR__) . '/models/User.php';
require_once dirname(__DIR__) . '/models/Notification.php';
require_once dirname(__DIR__) . '/utils/Mailer.php';

use App\Models\SpecialEvent;
use App\Models\User;
use App\Models\Notification;

class SpecialEventController {
    private $eventModel;
    private $userModel;
    private $notificationModel;
    
    public function __construct() {
        $this->eventModel = new SpecialEvent();
        $this->userModel = new User();
        $this->notificationModel = new Notification();
    }
    
    public function index() {
        try {
            $activeEvents = $this->eventModel->getActiveEvents();
            $upcomingEvents = $this->eventModel->getUpcomingEvents();
            
            require dirname(__DIR__) . '/views/events/index.php';
        } catch (\Exception $e) {
            error_log("Error in SpecialEventController::index: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function view($id) {
        try {
            $event = $this->eventModel->getEventById($id);
            
            if (!$event) {
                require dirname(__DIR__) . '/views/error/404.php';
                return;
            }
            
            $participants = $this->eventModel->getEventParticipants($id);
            
            require dirname(__DIR__) . '/views/events/view.php';
        } catch (\Exception $e) {
            error_log("Error in SpecialEventController::view: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function create() {
        try {
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                header('Location: /login');
                return;
            }
            
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                require dirname(__DIR__) . '/views/events/create.php';
                return;
            }
            
            $eventData = [
                'title' => $_POST['title'],
                'description' => $_POST['description'],
                'start_date' => $_POST['start_date'],
                'end_date' => $_POST['end_date'],
                'type' => $_POST['type'],
                'status' => $_POST['status'],
                'reward_points' => $_POST['reward_points'],
                'max_participants' => $_POST['max_participants']
            ];
            
            $eventId = $this->eventModel->createEvent($eventData);
            
            // Notify users about new event
            $users = $this->userModel->getActiveUsers();
            foreach ($users as $user) {
                $this->notificationModel->create([
                    'user_id' => $user['id'],
                    'type' => 'new_event',
                    'title' => 'New Special Event',
                    'message' => "A new event '{$eventData['title']}' has been created!",
                    'link' => "/events/{$eventId}"
                ]);
            }
            
            $_SESSION['success'] = 'Event created successfully.';
            header("Location: /events/{$eventId}");
            
        } catch (\Exception $e) {
            error_log("Error in SpecialEventController::create: " . $e->getMessage());
            $_SESSION['error'] = 'Failed to create event.';
            require dirname(__DIR__) . '/views/events/create.php';
        }
    }
    
    public function edit($id) {
        try {
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                header('Location: /login');
                return;
            }
            
            $event = $this->eventModel->getEventById($id);
            
            if (!$event) {
                require dirname(__DIR__) . '/views/error/404.php';
                return;
            }
            
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                require dirname(__DIR__) . '/views/events/edit.php';
                return;
            }
            
            $eventData = [
                'title' => $_POST['title'],
                'description' => $_POST['description'],
                'start_date' => $_POST['start_date'],
                'end_date' => $_POST['end_date'],
                'type' => $_POST['type'],
                'status' => $_POST['status'],
                'reward_points' => $_POST['reward_points'],
                'max_participants' => $_POST['max_participants']
            ];
            
            $this->eventModel->updateEvent($id, $eventData);
            
            // Notify participants about event update
            $participants = $this->eventModel->getEventParticipants($id);
            foreach ($participants as $participant) {
                $this->notificationModel->create([
                    'user_id' => $participant['id'],
                    'type' => 'event_update',
                    'title' => 'Event Updated',
                    'message' => "The event '{$eventData['title']}' has been updated.",
                    'link' => "/events/{$id}"
                ]);
            }
            
            $_SESSION['success'] = 'Event updated successfully.';
            header("Location: /events/{$id}");
            
        } catch (\Exception $e) {
            error_log("Error in SpecialEventController::edit: " . $e->getMessage());
            $_SESSION['error'] = 'Failed to update event.';
            require dirname(__DIR__) . '/views/events/edit.php';
        }
    }
    
    public function join($id) {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $this->eventModel->registerParticipant($id, $userId);
            
            $_SESSION['success'] = 'Successfully joined the event!';
            header("Location: /events/{$id}");
            
        } catch (\Exception $e) {
            error_log("Error in SpecialEventController::join: " . $e->getMessage());
            $_SESSION['error'] = 'Failed to join event: ' . $e->getMessage();
            header("Location: /events/{$id}");
        }
    }
    
    public function complete($id) {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $this->eventModel->completeEvent($id, $userId);
            
            $_SESSION['success'] = 'Event completed successfully!';
            header("Location: /events/{$id}");
            
        } catch (\Exception $e) {
            error_log("Error in SpecialEventController::complete: " . $e->getMessage());
            $_SESSION['error'] = 'Failed to complete event.';
            header("Location: /events/{$id}");
        }
    }
    
    public function myEvents() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $events = $this->eventModel->getUserEvents($userId);
            
            require dirname(__DIR__) . '/views/events/my-events.php';
        } catch (\Exception $e) {
            error_log("Error in SpecialEventController::myEvents: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
}