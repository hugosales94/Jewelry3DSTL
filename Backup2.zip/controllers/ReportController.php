<?php

namespace App\Controllers;

require_once dirname(__DIR__) . '/models/Report.php';
require_once dirname(__DIR__) . '/models/User.php';
require_once dirname(__DIR__) . '/models/File.php';
require_once dirname(__DIR__) . '/models/Notification.php';

use App\Models\Report;
use App\Models\User;
use App\Models\File;
use App\Models\Notification;

class ReportController {
    private $reportModel;
    private $userModel;
    private $fileModel;
    private $notificationModel;

    public function __construct() {
        $this->reportModel = new Report();
        $this->userModel = new User();
        $this->fileModel = new File();
        $this->notificationModel = new Notification();
    }

    public function index() {
        try {
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                header('Location: /login');
                exit();
            }

            $status = $_GET['status'] ?? 'pending';
            $reports = $this->reportModel->getReportsByStatus($status);

            require dirname(__DIR__) . '/views/reports/index.php';
        } catch (\Exception $e) {
            error_log("Error in ReportController::index: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }

    public function create() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                exit();
            }

            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                require dirname(__DIR__) . '/views/reports/create.php';
                return;
            }

            $reportData = [
                'reporter_id' => $_SESSION['user_id'],
                'reported_user_id' => $_POST['reported_user_id'] ?? null,
                'content_id' => $_POST['content_id'] ?? null,
                'type' => $_POST['type'],
                'reason' => $_POST['reason'],
                'description' => $_POST['description'],
                'status' => 'pending'
            ];

            $reportId = $this->reportModel->createReport($reportData);

            // Notify admins about new report
            $admins = $this->userModel->getAdminUsers();
            foreach ($admins as $admin) {
                $this->notificationModel->create([
                    'user_id' => $admin['id'],
                    'type' => 'new_report',
                    'title' => 'New Report Submitted',
                    'message' => "A new report has been submitted. Report ID: {$reportId}",
                    'link' => "/admin/reports/{$reportId}"
                ]);
            }

            $_SESSION['success'] = 'Report submitted successfully.';
            header('Location: /dashboard');
        } catch (\Exception $e) {
            error_log("Error in ReportController::create: " . $e->getMessage());
            $_SESSION['error'] = 'Failed to submit report.';
            require dirname(__DIR__) . '/views/reports/create.php';
        }
    }

    public function view($id) {
        try {
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                header('Location: /login');
                exit();
            }

            $report = $this->reportModel->getReportById($id);

            if (!$report) {
                require dirname(__DIR__) . '/views/error/404.php';
                return;
            }

            require dirname(__DIR__) . '/views/reports/view.php';
        } catch (\Exception $e) {
            error_log("Error in ReportController::view: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }

    public function update($id) {
        try {
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                header('Location: /login');
                exit();
            }

            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                header('Location: /admin/reports/' . $id);
                return;
            }

            $reportData = [
                'status' => $_POST['status'],
                'admin_notes' => $_POST['admin_notes'],
                'resolved_by' => $_SESSION['user_id'],
                'resolved_at' => date('Y-m-d H:i:s')
            ];

            $this->reportModel->updateReport($id, $reportData);

            // Take action based on report resolution
            if ($_POST['status'] === 'resolved') {
                $report = $this->reportModel->getReportById($id);
                if ($report['type'] === 'user') {
                    $this->userModel->updateUserStatus($report['reported_user_id'], $_POST['user_action']);
                } elseif ($report['type'] === 'file') {
                    $this->fileModel->updateFileStatus($report['content_id'], $_POST['content_action']);
                }
            }

            $_SESSION['success'] = 'Report updated successfully.';
            header('Location: /admin/reports');
        } catch (\Exception $e) {
            error_log("Error in ReportController::update: " . $e->getMessage());
            $_SESSION['error'] = 'Failed to update report.';
            header('Location: /admin/reports/' . $id);
        }
    }

    public function userReports() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                exit();
            }

            $userId = $_SESSION['user_id'];
            $reports = $this->reportModel->getUserReports($userId);

            require dirname(__DIR__) . '/views/reports/user-reports.php';
        } catch (\Exception $e) {
            error_log("Error in ReportController::userReports: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }

    public function statistics() {
        try {
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                header('Location: /login');
                exit();
            }

            $stats = $this->reportModel->getReportStatistics();

            require dirname(__DIR__) . '/views/reports/statistics.php';
        } catch (\Exception $e) {
            error_log("Error in ReportController::statistics: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
}