<?php

require_once __DIR__ . '/../utils/Logger.php';

class InstallController {
    private $installFile;

    public function __construct() {
        $this->installFile = __DIR__ . '/../../install.lock';
    }

    public function isInstalled() {
        return file_exists($this->installFile);
    }

    public function showWelcome() {
        require __DIR__ . '/../views/install/welcome.php';
    }

    public function checkRequirements() {
        $requirements = [
            'php' => ['version' => '7.4.0', 'current' => PHP_VERSION],
            'extensions' => [
                'mysqli',
                'pdo_mysql',
                'gd',
                'zip'
            ],
            'writable_dirs' => [
                __DIR__ . '/../../public/uploads',
                __DIR__ . '/../../logs',
                __DIR__ . '/../../cache'
            ]
        ];

        $errors = [];

        // Check PHP version
        if (version_compare(PHP_VERSION, $requirements['php']['version'], '<')) {
            $errors[] = "PHP version must be at least {$requirements['php']['version']}. Current version is {$requirements['php']['current']}.";
        }

        // Check extensions
        foreach ($requirements['extensions'] as $ext) {
            if (!extension_loaded($ext)) {
                $errors[] = "PHP extension {$ext} is not loaded.";
            }
        }

        // Check writable directories
        foreach ($requirements['writable_dirs'] as $dir) {
            if (!is_writable($dir)) {
                $errors[] = "Directory {$dir} is not writable.";
            }
        }

        require __DIR__ . '/../views/install/requirements.php';
    }

    public function showDatabaseForm() {
        require __DIR__ . '/../views/install/database_form.php';
    }

    public function configureDatabaseAndFinish() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $dbHost = $_POST['db_host'];
            $dbName = $_POST['db_name'];
            $dbUser = $_POST['db_user'];
            $dbPass = $_POST['db_pass'];

            // Test database connection
            try {
                $conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
                if ($conn->connect_error) {
                    throw new Exception("Connection failed: " . $conn->connect_error);
                }
                $conn->close();

                // Update .env file with database credentials
                $envFile = __DIR__ . '/../../.env';
                $envContent = file_get_contents($envFile);
                $envContent = preg_replace('/DB_HOST=.*/', "DB_HOST={$dbHost}", $envContent);
                $envContent = preg_replace('/DB_NAME=.*/', "DB_NAME={$dbName}", $envContent);
                $envContent = preg_replace('/DB_USER=.*/', "DB_USER={$dbUser}", $envContent);
                $envContent = preg_replace('/DB_PASS=.*/', "DB_PASS={$dbPass}", $envContent);
                file_put_contents($envFile, $envContent);

                // Import database schema
                $schemaFile = __DIR__ . '/../../database_schema.sql';
                $command = "mysql -h {$dbHost} -u {$dbUser} -p{$dbPass} {$dbName} < {$schemaFile}";
                exec($command, $output, $returnVar);

                if ($returnVar !== 0) {
                    throw new Exception("Failed to import database schema.");
                }

                // Create install.lock file
                file_put_contents($this->installFile, date('Y-m-d H:i:s'));

                Logger::info("Installation completed successfully.");
                header('Location: /');
                exit();
            } catch (Exception $e) {
                Logger::error("Installation failed: " . $e->getMessage());
                $_SESSION['error'] = "Installation failed: " . $e->getMessage();
                header('Location: /install/database');
                exit();
            }
        }
    }
}

