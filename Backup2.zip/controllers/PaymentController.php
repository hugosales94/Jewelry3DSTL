<?php

namespace App\Controllers;

require_once dirname(__DIR__) . '/models/Payment.php';
require_once dirname(__DIR__) . '/models/Subscription.php';
require_once dirname(__DIR__) . '/models/User.php';
require_once dirname(__DIR__) . '/models/Notification.php';
require_once dirname(__DIR__) . '/utils/Mailer.php';

use App\Models\Payment;
use App\Models\Subscription;
use App\Models\User;
use App\Models\Notification;

class PaymentController {
    private $paymentModel;
    private $subscriptionModel;
    private $userModel;
    private $notificationModel;
    
    public function __construct() {
        $this->paymentModel = new Payment();
        $this->subscriptionModel = new Subscription();
        $this->userModel = new User();
        $this->notificationModel = new Notification();
    }
    
    public function process() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                require dirname(__DIR__) . '/views/payments/form.php';
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $amount = $_POST['amount'];
            $currency = $_POST['currency'];
            $paymentMethod = $_POST['payment_method'];
            $planId = $_POST['plan_id'];
            
            // Process payment (integrate with your payment gateway here)
            $paymentResult = $this->processPayment($amount, $currency, $paymentMethod);
            
            if ($paymentResult['success']) {
                // Create subscription
                $subscriptionData = [
                    'user_id' => $userId,
                    'plan_id' => $planId,
                    'amount' => $amount,
                    'currency' => $currency,
                    'payment_method' => $paymentMethod,
                    'transaction_id' => $paymentResult['transaction_id']
                ];
                
                $subscriptionId = $this->subscriptionModel->create($subscriptionData);
                
                // Create payment record
                $this->paymentModel->createPayment([
                    'user_id' => $userId,
                    'subscription_id' => $subscriptionId,
                    'amount' => $amount,
                    'currency' => $currency,
                    'payment_method' => $paymentMethod,
                    'transaction_id' => $paymentResult['transaction_id'],
                    'status' => 'completed'
                ]);
                
                // Send confirmation email
                $user = $this->userModel->getUserById($userId);
                $mailer = new \Mailer();
                $mailer->sendPaymentConfirmation($user['email'], $amount, $currency, $paymentResult['transaction_id']);
                
                // Create notification
                $this->notificationModel->create([
                    'user_id' => $userId,
                    'type' => 'payment_success',
                    'title' => 'Payment Successful',
                    'message' => "Your payment of {$amount} {$currency} has been processed successfully.",
                    'link' => '/subscriptions'
                ]);
                
                $_SESSION['success'] = 'Payment processed successfully!';
                header('Location: /subscriptions');
            } else {
                throw new \Exception($paymentResult['error']);
            }
        } catch (\Exception $e) {
            error_log("Error in PaymentController::process: " . $e->getMessage());
            $_SESSION['error'] = 'Payment failed: ' . $e->getMessage();
            header('Location: /payments/process');
        }
    }
    
    private function processPayment($amount, $currency, $paymentMethod) {
        // Integrate with your payment gateway here
        // This is a placeholder implementation
        return [
            'success' => true,
            'transaction_id' => uniqid('trx_')
        ];
    }
    
    public function refund($paymentId) {
        try {
            if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
                header('Location: /login');
                return;
            }
            
            $payment = $this->paymentModel->getPaymentById($paymentId);
            
            if (!$payment) {
                $_SESSION['error'] = 'Invalid payment ID.';
                header('Location: /admin/payments');
                return;
            }
            
            // Process refund (integrate with your payment gateway here)
            $refundResult = $this->processRefund($payment['transaction_id'], $payment['amount']);
            
            if ($refundResult['success']) {
                $this->paymentModel->updatePaymentStatus($paymentId, 'refunded');
                
                // Cancel associated subscription
                if ($payment['subscription_id']) {
                    $this->subscriptionModel->cancel($payment['subscription_id']);
                }
                
                // Send refund email
                $user = $this->userModel->getUserById($payment['user_id']);
                $mailer = new \Mailer();
                $mailer->sendRefundConfirmation($user['email'], $payment['amount'], $payment['currency']);
                
                // Create notification
                $this->notificationModel->create([
                    'user_id' => $payment['user_id'],
                    'type' => 'payment_refunded',
                    'title' => 'Payment Refunded',
                    'message' => "Your payment of {$payment['amount']} {$payment['currency']} has been refunded.",
                    'link' => '/payments/history'
                ]);
                
                $_SESSION['success'] = 'Refund processed successfully.';
            } else {
                throw new \Exception($refundResult['error']);
            }
            
            header('Location: /admin/payments');
        } catch (\Exception $e) {
            error_log("Error in PaymentController::refund: " . $e->getMessage());
            $_SESSION['error'] = 'Refund failed: ' . $e->getMessage();
            header('Location: /admin/payments');
        }
    }
    
    private function processRefund($transactionId, $amount) {
        // Integrate with your payment gateway here
        // This is a placeholder implementation
        return [
            'success' => true
        ];
    }
    
    public function history() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $payments = $this->paymentModel->getUserPayments($userId);
            
            require dirname(__DIR__) . '/views/payments/history.php';
        } catch (\Exception $e) {
            error_log("Error in PaymentController::history: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function invoice($paymentId) {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $payment = $this->paymentModel->getPaymentById($paymentId);
            
            if (!$payment || $payment['user_id'] !== $userId) {
                require dirname(__DIR__) . '/views/error/404.php';
                return;
            }
            
            require dirname(__DIR__) . '/views/payments/invoice.php';
        } catch (\Exception $e) {
            error_log("Error in PaymentController::invoice: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
}