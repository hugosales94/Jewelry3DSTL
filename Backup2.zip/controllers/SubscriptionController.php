<?php

namespace App\Controllers;

require_once dirname(__DIR__) . '/models/Subscription.php';
require_once dirname(__DIR__) . '/models/User.php';
require_once dirname(__DIR__) . '/models/Notification.php';
require_once dirname(__DIR__) . '/utils/Mailer.php';

use App\Models\Subscription;
use App\Models\User;
use App\Models\Notification;

class SubscriptionController {
    private $subscriptionModel;
    private $userModel;
    private $notificationModel;
    
    public function __construct() {
        $this->subscriptionModel = new Subscription();
        $this->userModel = new User();
        $this->notificationModel = new Notification();
    }
    
    public function index() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $subscriptions = $this->subscriptionModel->getUserSubscriptions($userId);
            $activeSubscription = $this->subscriptionModel->getActiveSubscription($userId);
            
            require dirname(__DIR__) . '/views/subscriptions/index.php';
        } catch (\Exception $e) {
            error_log("Error in SubscriptionController::index: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function subscribe() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                $plans = $this->subscriptionModel->getAvailablePlans();
                require dirname(__DIR__) . '/views/subscriptions/subscribe.php';
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $planId = $_POST['plan_id'];
            
            // Process payment
            $paymentData = [
                'amount' => $_POST['amount'],
                'currency' => $_POST['currency'],
                'payment_method' => $_POST['payment_method'],
                'transaction_id' => $_POST['transaction_id']
            ];
            
            // Create subscription
            $subscriptionData = array_merge($paymentData, [
                'user_id' => $userId,
                'plan_id' => $planId
            ]);
            
            $subscriptionId = $this->subscriptionModel->create($subscriptionData);
            
            // Send confirmation email
            $user = $this->userModel->getUserById($userId);
            $mailer = new \Mailer();
            $mailer->sendSubscriptionConfirmation($user['email'], $subscriptionId);
            
            // Create notification
            $this->notificationModel->create([
                'user_id' => $userId,
                'type' => 'subscription_created',
                'title' => 'Subscription Activated',
                'message' => 'Your subscription has been successfully activated.',
                'link' => '/subscriptions'
            ]);
            
            $_SESSION['success'] = 'Subscription activated successfully!';
            header('Location: /subscriptions');
            
        } catch (\Exception $e) {
            error_log("Error in SubscriptionController::subscribe: " . $e->getMessage());
            $_SESSION['error'] = 'Failed to process subscription. Please try again.';
            header('Location: /subscriptions/subscribe');
        }
    }
    
    public function cancel($id) {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $subscription = $this->subscriptionModel->getSubscriptionById($id);
            
            if (!$subscription || $subscription['user_id'] !== $userId) {
                $_SESSION['error'] = 'Invalid subscription.';
                header('Location: /subscriptions');
                return;
            }
            
            $this->subscriptionModel->cancel($id);
            
            // Send cancellation email
            $user = $this->userModel->getUserById($userId);
            $mailer = new \Mailer();
            $mailer->sendSubscriptionCancellation($user['email'], $id);
            
            // Create notification
            $this->notificationModel->create([
                'user_id' => $userId,
                'type' => 'subscription_cancelled',
                'title' => 'Subscription Cancelled',
                'message' => 'Your subscription has been cancelled.',
                'link' => '/subscriptions'
            ]);
            
            $_SESSION['success'] = 'Subscription cancelled successfully.';
            header('Location: /subscriptions');
            
        } catch (\Exception $e) {
            error_log("Error in SubscriptionController::cancel: " . $e->getMessage());
            $_SESSION['error'] = 'Failed to cancel subscription. Please try again.';
            header('Location: /subscriptions');
        }
    }
    
    public function renew($id) {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $subscription = $this->subscriptionModel->getSubscriptionById($id);
            
            if (!$subscription || $subscription['user_id'] !== $userId) {
                $_SESSION['error'] = 'Invalid subscription.';
                header('Location: /subscriptions');
                return;
            }
            
            $newSubscriptionId = $this->subscriptionModel->renew($id);
            
            // Send renewal confirmation email
            $user = $this->userModel->getUserById($userId);
            $mailer = new \Mailer();
            $mailer->sendSubscriptionRenewal($user['email'], $newSubscriptionId);
            
            // Create notification
            $this->notificationModel->create([
                'user_id' => $userId,
                'type' => 'subscription_renewed',
                'title' => 'Subscription Renewed',
                'message' => 'Your subscription has been renewed successfully.',
                'link' => '/subscriptions'
            ]);
            
            $_SESSION['success'] = 'Subscription renewed successfully.';
            header('Location: /subscriptions');
            
        } catch (\Exception $e) {
            error_log("Error in SubscriptionController::renew: " . $e->getMessage());
            $_SESSION['error'] = 'Failed to renew subscription. Please try again.';
            header('Location: /subscriptions');
        }
    }
    
    public function history() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $history = $this->subscriptionModel->getSubscriptionHistory($userId);
            
            require dirname(__DIR__) . '/views/subscriptions/history.php';
        } catch (\Exception $e) {
            error_log("Error in SubscriptionController::history: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function invoice($id) {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $subscription = $this->subscriptionModel->getSubscriptionById($id);
            
            if (!$subscription || $subscription['user_id'] !== $userId) {
                require dirname(__DIR__) . '/views/error/404.php';
                return;
            }
            
            require dirname(__DIR__) . '/views/subscriptions/invoice.php';
        } catch (\Exception $e) {
            error_log("Error in SubscriptionController::invoice: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
}