<?php

namespace App\Controllers;

require_once dirname(__DIR__) . '/models/Message.php';
require_once dirname(__DIR__) . '/models/User.php';
require_once dirname(__DIR__) . '/models/Notification.php';
require_once dirname(__DIR__) . '/utils/Mailer.php';

use App\Models\Message;
use App\Models\User;
use App\Models\Notification;

class MessageController {
    private $messageModel;
    private $userModel;
    private $notificationModel;
    
    public function __construct() {
        $this->messageModel = new Message();
        $this->userModel = new User();
        $this->notificationModel = new Notification();
    }
    
    public function index() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $conversations = $this->messageModel->getUserConversations($userId);
            
            require dirname(__DIR__) . '/views/messages/index.php';
        } catch (\Exception $e) {
            error_log("Error in MessageController::index: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function conversation($recipientId) {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $messages = $this->messageModel->getConversation($userId, $recipientId);
            $recipient = $this->userModel->getUserById($recipientId);
            
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $content = $_POST['content'];
                $messageId = $this->messageModel->sendMessage($userId, $recipientId, $content);
                
                // Create notification for recipient
                $this->notificationModel->create([
                    'user_id' => $recipientId,
                    'type' => 'new_message',
                    'title' => 'New Message',
                    'message' => 'You have received a new message.',
                    'link' => "/messages/conversation/{$userId}"
                ]);
                
                // Send email notification
                $recipientEmail = $recipient['email'];
                $mailer = new \Mailer();
                $mailer->sendNewMessageNotification($recipientEmail, $userId);
                
                header("Location: /messages/conversation/{$recipientId}");
                return;
            }
            
            require dirname(__DIR__) . '/views/messages/conversation.php';
        } catch (\Exception $e) {
            error_log("Error in MessageController::conversation: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function delete($messageId) {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $message = $this->messageModel->getMessageById($messageId);
            
            if (!$message || ($message['sender_id'] !== $userId && $message['recipient_id'] !== $userId)) {
                $_SESSION['error'] = 'You do not have permission to delete this message.';
                header('Location: /messages');
                return;
            }
            
            $this->messageModel->deleteMessage($messageId, $userId);
            $_SESSION['success'] = 'Message deleted successfully.';
            header('Location: /messages');
        } catch (\Exception $e) {
            error_log("Error in MessageController::delete: " . $e->getMessage());
            $_SESSION['error'] = 'Failed to delete message.';
            header('Location: /messages');
        }
    }
    
    public function markAsRead($messageId) {
        try {
            if (!isset($_SESSION['user_id'])) {
                http_response_code(401);
                echo json_encode(['error' => 'Unauthorized']);
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $success = $this->messageModel->markAsRead($messageId, $userId);
            
            if ($success) {
                echo json_encode(['success' => true]);
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Failed to mark message as read']);
            }
        } catch (\Exception $e) {
            error_log("Error in MessageController::markAsRead: " . $e->getMessage());
            http_response_code(500);
            echo json_encode(['error' => 'Internal server error']);
        }
    }
    
    public function search() {
        try {
            if (!isset($_SESSION['user_id'])) {
                header('Location: /login');
                return;
            }
            
            $userId = $_SESSION['user_id'];
            $query = $_GET['q'] ?? '';
            
            $results = $this->messageModel->searchMessages($userId, $query);
            
            require dirname(__DIR__) . '/views/messages/search.php';
        } catch (\Exception $e) {
            error_log("Error in MessageController::search: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
}