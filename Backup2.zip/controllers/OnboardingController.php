<?php

require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Onboarding.php';
require_once __DIR__ . '/../utils/Logger.php';

class OnboardingController {
    private $user;
    private $onboarding;

    public function __construct() {
        $this->user = new User();
        $this->onboarding = new Onboarding();
    }

    public function showOnboarding() {
        $userId = $_SESSION['user_id'];
        $user = $this->user->getById($userId);
        $onboardingSteps = $this->onboarding->getOnboardingSteps();
        $completedSteps = $this->onboarding->getCompletedSteps($userId);

        $metaTags = new MetaTags(
            "Welcome to STL Jewelry 3D - Start Your Journey",
            "Complete our onboarding process to make the most of your experience on STL Jewelry 3D.",
            "onboarding, tutorial, STL Jewelry 3D, getting started"
        );

        require __DIR__ . '/../views/onboarding.php';
    }

    public function completeStep() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $userId = $_SESSION['user_id'];
            $stepId = $_POST['step_id'];

            $success = $this->onboarding->completeStep($userId, $stepId);

            if ($success) {
                Logger::info("User $userId completed onboarding step $stepId");
                echo json_encode(['success' => true]);
            } else {
                Logger::error("Failed to complete onboarding step $stepId for user $userId");
                echo json_encode(['success' => false, 'message' => 'Error completing the step.']);
            }
        }
    }
}

