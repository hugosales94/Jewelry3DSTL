<?php

namespace App\Controllers;

use App\Models\File;
use App\Models\User;

class MainController {
    
    public function index() {
        // Check if user is logged in
        $isLoggedIn = isset($_SESSION['user_id']);
        
        // Get database instance
        $db = \Database::getInstance();
        
        try {
            // Fetch featured files
            $featuredFiles = $db->query("
                SELECT f.*, u.username, COUNT(d.id) as download_count 
                FROM files f 
                LEFT JOIN users u ON f.user_id = u.id 
                LEFT JOIN downloads d ON f.id = d.file_id 
                WHERE f.status = 'approved' AND f.featured = 1 
                GROUP BY f.id 
                ORDER BY f.created_at DESC 
                LIMIT 6
            ")->fetchAll();

            // Fetch latest files
            $latestFiles = $db->query("
                SELECT f.*, u.username, COUNT(d.id) as download_count 
                FROM files f 
                LEFT JOIN users u ON f.user_id = u.id 
                LEFT JOIN downloads d ON f.id = d.file_id 
                WHERE f.status = 'approved' 
                GROUP BY f.id 
                ORDER BY f.created_at DESC 
                LIMIT 12
            ")->fetchAll();

            // Fetch top creators
            $topCreators = $db->query("
                SELECT u.*, 
                       COUNT(DISTINCT f.id) as file_count,
                       SUM(d.id) as total_downloads,
                       AVG(r.rating) as avg_rating
                FROM users u
                LEFT JOIN files f ON u.id = f.user_id
                LEFT JOIN downloads d ON f.id = d.file_id
                LEFT JOIN ratings r ON f.id = r.file_id
                WHERE u.status = 'active'
                GROUP BY u.id
                ORDER BY total_downloads DESC
                LIMIT 5
            ")->fetchAll();

            // Fetch categories with file counts
            $categories = $db->query("
                SELECT c.*, COUNT(f.id) as file_count
                FROM categories c
                LEFT JOIN file_categories fc ON c.id = fc.category_id
                LEFT JOIN files f ON fc.file_id = f.id AND f.status = 'approved'
                GROUP BY c.id
                ORDER BY file_count DESC
            ")->fetchAll();

            // Get total stats
            $stats = $db->query("
                SELECT 
                    (SELECT COUNT(*) FROM files WHERE status = 'approved') as total_files,
                    (SELECT COUNT(*) FROM users WHERE status = 'active') as total_users,
                    (SELECT COUNT(*) FROM downloads) as total_downloads
            ")->fetch();

            // Load the view
            require_once BASE_PATH . '/views/main.php';

        } catch (\Exception $e) {
            // Log the error
            error_log("Error in MainController::index: " . $e->getMessage());
            
            // Show error page
            http_response_code(500);
            require_once BASE_PATH . '/views/error/500.php';
        }
    }

    public function search() {
        $query = $_GET['q'] ?? '';
        $category = $_GET['category'] ?? null;
        $sort = $_GET['sort'] ?? 'recent';
        $page = max(1, intval($_GET['page'] ?? 1));
        $perPage = 24;

        try {
            $db = \Database::getInstance();
            
            // Build the base query
            $sql = "
                SELECT f.*, u.username, COUNT(d.id) as download_count 
                FROM files f 
                LEFT JOIN users u ON f.user_id = u.id 
                LEFT JOIN downloads d ON f.id = d.file_id 
                LEFT JOIN file_categories fc ON f.id = fc.file_id
                WHERE f.status = 'approved'
            ";
            
            $params = [];

            // Add search conditions
            if ($query) {
                $sql .= " AND (f.name LIKE ? OR f.description LIKE ?)";
                $params[] = "%{$query}%";
                $params[] = "%{$query}%";
            }

            // Add category filter
            if ($category) {
                $sql .= " AND fc.category_id = ?";
                $params[] = $category;
            }

            // Add grouping
            $sql .= " GROUP BY f.id";

            // Add sorting
            switch ($sort) {
                case 'downloads':
                    $sql .= " ORDER BY download_count DESC";
                    break;
                case 'rating':
                    $sql .= " ORDER BY (
                        SELECT AVG(rating) 
                        FROM ratings 
                        WHERE file_id = f.id
                    ) DESC";
                    break;
                case 'oldest':
                    $sql .= " ORDER BY f.created_at ASC";
                    break;
                case 'recent':
                default:
                    $sql .= " ORDER BY f.created_at DESC";
            }

            // Add pagination
            $sql .= " LIMIT ? OFFSET ?";
            $params[] = $perPage;
            $params[] = ($page - 1) * $perPage;

            // Execute the query
            $files = $db->query($sql, $params)->fetchAll();

            // Get total count for pagination
            $countSql = "
                SELECT COUNT(DISTINCT f.id) as total 
                FROM files f 
                LEFT JOIN file_categories fc ON f.id = fc.file_id
                WHERE f.status = 'approved'
            ";
            
            if ($query) {
                $countSql .= " AND (f.name LIKE ? OR f.description LIKE ?)";
            }
            if ($category) {
                $countSql .= " AND fc.category_id = ?";
            }

            $totalFiles = $db->query($countSql, array_slice($params, 0, -2))->fetch()['total'];
            $totalPages = ceil($totalFiles / $perPage);

            // Load the search results view
            require_once BASE_PATH . '/views/search.php';

        } catch (\Exception $e) {
            error_log("Error in MainController::search: " . $e->getMessage());
            http_response_code(500);
            require_once BASE_PATH . '/views/error/500.php';
        }
    }

    public function contact() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = $_POST['name'] ?? '';
            $email = $_POST['email'] ?? '';
            $subject = $_POST['subject'] ?? '';
            $message = $_POST['message'] ?? '';
            
            // Validate inputs
            $errors = [];
            
            if (empty($name)) {
                $errors['name'] = 'Name is required';
            }
            
            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors['email'] = 'Valid email is required';
            }
            
            if (empty($subject)) {
                $errors['subject'] = 'Subject is required';
            }
            
            if (empty($message)) {
                $errors['message'] = 'Message is required';
            }
            
            if (empty($errors)) {
                try {
                    // Save to database
                    $db = \Database::getInstance();
                    $db->query(
                        "INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)",
                        [$name, $email, $subject, $message]
                    );
                    
                    // Send email notification
                    $to = MAIL_FROM_ADDRESS;
                    $headers = "From: $name <$email>\r\n";
                    $headers .= "Reply-To: $email\r\n";
                    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
                    
                    $emailBody = "
                        <h2>New Contact Form Submission</h2>
                        <p><strong>Name:</strong> $name</p>
                        <p><strong>Email:</strong> $email</p>
                        <p><strong>Subject:</strong> $subject</p>
                        <p><strong>Message:</strong></p>
                        <p>" . nl2br(htmlspecialchars($message)) . "</p>
                    ";
                    
                    mail($to, "Contact Form: $subject", $emailBody, $headers);
                    
                    // Set success message
                    $_SESSION['flash_message'] = [
                        'type' => 'success',
                        'message' => 'Your message has been sent successfully!'
                    ];
                    
                    // Redirect to prevent form resubmission
                    header('Location: /contact');
                    exit;
                    
                } catch (\Exception $e) {
                    error_log("Error in MainController::contact: " . $e->getMessage());
                    $errors['general'] = 'Failed to send message. Please try again later.';
                }
            }
            
            // If we get here, there were errors
            require_once BASE_PATH . '/views/contact.php';
            
        } else {
            // Show the contact form
            require_once BASE_PATH . '/views/contact.php';
        }
    }
}