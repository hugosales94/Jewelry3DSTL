<?php

namespace App\Controllers;

require_once dirname(__DIR__) . '/models/Badge.php';
require_once dirname(__DIR__) . '/models/Achievement.php';
require_once dirname(__DIR__) . '/models/User.php';
require_once dirname(__DIR__) . '/models/Notification.php';

use App\Models\Badge;
use App\Models\Achievement;
use App\Models\User;
use App\Models\Notification;

class GamificationController {
    private $badgeModel;
    private $achievementModel;
    private $userModel;
    private $notificationModel;
    
    public function __construct() {
        $this->badgeModel = new Badge();
        $this->achievementModel = new Achievement();
        $this->userModel = new User();
        $this->notificationModel = new Notification();
    }
    
    public function getUserBadges($userId = null) {
        try {
            if (!$userId && isset($_SESSION['user_id'])) {
                $userId = $_SESSION['user_id'];
            }
            
            if (!$userId) {
                header('Location: /login');
                return;
            }
            
            $badges = $this->badgeModel->getUserBadges($userId);
            $availableBadges = $this->badgeModel->getAvailableBadges($userId);
            
            require dirname(__DIR__) . '/views/gamification/badges.php';
        } catch (\Exception $e) {
            error_log("Error in GamificationController::getUserBadges: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function getUserAchievements($userId = null) {
        try {
            if (!$userId && isset($_SESSION['user_id'])) {
                $userId = $_SESSION['user_id'];
            }
            
            if (!$userId) {
                header('Location: /login');
                return;
            }
            
            $achievements = $this->achievementModel->getUserAchievements($userId);
            $progress = $this->achievementModel->getUserProgress($userId);
            
            require dirname(__DIR__) . '/views/gamification/achievements.php';
        } catch (\Exception $e) {
            error_log("Error in GamificationController::getUserAchievements: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function checkAndAwardBadges($userId) {
        try {
            $newBadges = $this->badgeModel->checkAndAwardBadges($userId);
            
            foreach ($newBadges as $badge) {
                $this->notificationModel->create([
                    'user_id' => $userId,
                    'type' => 'new_badge',
                    'title' => 'New Badge Earned!',
                    'message' => "Congratulations! You've earned the {$badge['name']} badge.",
                    'link' => '/gamification/badges'
                ]);
            }
            
            return $newBadges;
        } catch (\Exception $e) {
            error_log("Error in GamificationController::checkAndAwardBadges: " . $e->getMessage());
            return [];
        }
    }
    
    public function checkAndAwardAchievements($userId) {
        try {
            $newAchievements = $this->achievementModel->checkAndAwardAchievements($userId);
            
            foreach ($newAchievements as $achievement) {
                $this->notificationModel->create([
                    'user_id' => $userId,
                    'type' => 'new_achievement',
                    'title' => 'New Achievement Unlocked!',
                    'message' => "Congratulations! You've unlocked the {$achievement['name']} achievement.",
                    'link' => '/gamification/achievements'
                ]);
            }
            
            return $newAchievements;
        } catch (\Exception $e) {
            error_log("Error in GamificationController::checkAndAwardAchievements: " . $e->getMessage());
            return [];
        }
    }
    
    public function getLeaderboard() {
        try {
            $timeframe = $_GET['timeframe'] ?? 'all-time';
            $category = $_GET['category'] ?? 'points';
            
            switch ($timeframe) {
                case 'weekly':
                    $startDate = date('Y-m-d', strtotime('-1 week'));
                    break;
                case 'monthly':
                    $startDate = date('Y-m-d', strtotime('-1 month'));
                    break;
                default:
                    $startDate = null;
            }
            
            $leaderboard = $this->userModel->getLeaderboard($category, $startDate);
            require dirname(__DIR__) . '/views/gamification/leaderboard.php';
            
        } catch (\Exception $e) {
            error_log("Error in GamificationController::getLeaderboard: " . $e->getMessage());
            require dirname(__DIR__) . '/views/error/500.php';
        }
    }
    
    public function awardPoints($userId, $action, $points = null) {
        try {
            if (!$points) {
                $points = $this->getPointsForAction($action);
            }
            
            $this->userModel->addPoints($userId, $points);
            $this->checkAndAwardBadges($userId);
            $this->checkAndAwardAchievements($userId);
            
            return true;
        } catch (\Exception $e) {
            error_log("Error in GamificationController::awardPoints: " . $e->getMessage());
            return false;
        }
    }
    
    private function getPointsForAction($action) {
        $pointsMap = [
            'upload_file' => 10,
            'download_file' => 2,
            'rate_file' => 5,
            'receive_rating' => 3,
            'complete_profile' => 15,
            'daily_login' => 1,
            'share_file' => 7
        ];
        
        return $pointsMap[$action] ?? 0;
    }
}