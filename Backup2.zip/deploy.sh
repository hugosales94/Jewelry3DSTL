#!/bin/bash

# Pull the latest changes from the repository
git pull origin main

# Install or update dependencies
composer install --no-dev --optimize-autoloader

# Clear cache
php artisan cache:clear

# Run database migrations
php artisan migrate --force

# Restart the web server (adjust as needed for your hosting environment)
sudo service apache2 restart

