<?php

// Application configuration
define('APP_NAME', 'STL Jewelry 3D');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'https://' . $_SERVER['HTTP_HOST']);

// Update the log path
define('LOG_PATH', dirname(__DIR__) . '/logs/app.log');

// Error reporting (disable for production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Time zone
date_default_timezone_set('UTC');

// Try to load environment variables from .env file
$envFile = dirname(__DIR__, 2) . '/.env';
if (file_exists($envFile)) {
    $envVars = parse_ini_file($envFile);
    foreach ($envVars as $key => $value) {
        $_ENV[$key] = $value;
        putenv("$key=$value");
    }
    error_log("Loaded .env file successfully");
} else {
    error_log(".env file not found at: " . $envFile);
}

if (empty($_ENV) && empty($_SERVER['DB_HOST'])) {
    error_log("Warning: Both \$_ENV and \$_SERVER['DB_HOST'] are empty. Check if .env file is being read correctly.");
}

// Database configuration with fallbacks and logging
$dbHost = $_ENV['DB_HOST'] ?? getenv('DB_HOST') ?? null;
$dbUser = $_ENV['DB_USER'] ?? getenv('DB_USER') ?? null;
$dbPass = $_ENV['DB_PASS'] ?? getenv('DB_PASS') ?? null;
$dbName = $_ENV['DB_NAME'] ?? getenv('DB_NAME') ?? null;

error_log("DB_HOST: " . ($dbHost ?? 'not set'));
error_log("DB_USER: " . ($dbUser ?? 'not set'));
error_log("DB_NAME: " . ($dbName ?? 'not set'));
error_log("DB_PASS is " . (empty($dbPass) ? 'empty' : 'set'));

if (!$dbHost || !$dbUser || !$dbName) {
    error_log("Critical database configuration variables are missing");
}

if (!defined('DB_HOST')) define('DB_HOST', $dbHost);
if (!defined('DB_USER')) define('DB_USER', $dbUser);
if (!defined('DB_PASS')) define('DB_PASS', $dbPass);
if (!defined('DB_NAME')) define('DB_NAME', $dbName);

// Stripe configuration with fallbacks
if (!defined('STRIPE_SECRET_KEY')) define('STRIPE_SECRET_KEY', $_ENV['STRIPE_SECRET_KEY'] ?? getenv('STRIPE_SECRET_KEY') ?? '');
if (!defined('STRIPE_PUBLISHABLE_KEY')) define('STRIPE_PUBLISHABLE_KEY', $_ENV['STRIPE_PUBLISHABLE_KEY'] ?? getenv('STRIPE_PUBLISHABLE_KEY') ?? '');
if (!defined('STRIPE_WEBHOOK_SECRET')) define('STRIPE_WEBHOOK_SECRET', $_ENV['STRIPE_WEBHOOK_SECRET'] ?? getenv('STRIPE_WEBHOOK_SECRET') ?? '');

// Mail configuration with fallbacks
if (!defined('MAIL_HOST')) define('MAIL_HOST', $_ENV['MAIL_HOST'] ?? getenv('MAIL_HOST') ?? '');
if (!defined('MAIL_PORT')) define('MAIL_PORT', $_ENV['MAIL_PORT'] ?? getenv('MAIL_PORT') ?? '');
if (!defined('MAIL_USERNAME')) define('MAIL_USERNAME', $_ENV['MAIL_USERNAME'] ?? getenv('MAIL_USERNAME') ?? '');
if (!defined('MAIL_PASSWORD')) define('MAIL_PASSWORD', $_ENV['MAIL_PASSWORD'] ?? getenv('MAIL_PASSWORD') ?? '');
if (!defined('MAIL_ENCRYPTION')) define('MAIL_ENCRYPTION', $_ENV['MAIL_ENCRYPTION'] ?? getenv('MAIL_ENCRYPTION') ?? 'tls');
if (!defined('MAIL_FROM_ADDRESS')) define('MAIL_FROM_ADDRESS', $_ENV['MAIL_FROM_ADDRESS'] ?? getenv('MAIL_FROM_ADDRESS') ?? '');
if (!defined('MAIL_FROM_NAME')) define('MAIL_FROM_NAME', $_ENV['MAIL_FROM_NAME'] ?? getenv('MAIL_FROM_NAME') ?? APP_NAME);

// Autoloader function
spl_autoload_register(function ($class) {
    // Convert namespace separators to directory separators
    $class = str_replace('\\', '/', $class);
    
    // Base directory for classes
    $baseDir = __DIR__ . '/../';
    
    // If it's a controller
    if (strpos($class, 'App/Controllers/') !== false) {
        $class = str_replace('App/Controllers/', 'controllers/', $class);
    }
    
    // If it's a model
    if (strpos($class, 'App/Models/') !== false) {
        $class = str_replace('App/Models/', 'models/', $class);
    }
    
    // Full path to the class file
    $file = $baseDir . $class . '.php';
    
    // Check if file exists and require it
    if (file_exists($file)) {
        require_once $file;
    }
});

require_once dirname(__DIR__) . '/models/Database.php';