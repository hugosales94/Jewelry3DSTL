<?php

// Verificar se as constantes já estão definidas para evitar erros de redefinição
if (!defined('DB_HOST')) define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
if (!defined('DB_USER')) define('DB_USER', getenv('DB_USER') ?: 'u361426828_3duser');
if (!defined('DB_PASS')) define('DB_PASS', getenv('DB_PASS') ?: '>2hUZXjK');
if (!defined('DB_NAME')) define('DB_NAME', getenv('DB_NAME') ?: 'u361426828_3d');

// Não definimos uma nova classe Database aqui