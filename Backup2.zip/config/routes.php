<?php

// Define routes for the application
$router->addRoute('GET', '/', [new \App\Controllers\MainController(), 'index']);
$router->addRoute('GET', '/dashboard', [new \App\Controllers\DashboardController(), 'index']);

// Authentication routes
$router->addRoute('GET', '/login', [new \App\Controllers\AuthController(), 'showLoginForm']);
$router->addRoute('POST', '/login', [new \App\Controllers\AuthController(), 'login']);
$router->addRoute('GET', '/register', [new \App\Controllers\AuthController(), 'showRegistrationForm']);
$router->addRoute('POST', '/register', [new \App\Controllers\AuthController(), 'register']);
$router->addRoute('GET', '/logout', [new \App\Controllers\AuthController(), 'logout']);

// File routes
$router->addRoute('GET', '/file/(\d+)', [new \App\Controllers\FileController(), 'view']);
$router->addRoute('GET', '/file/(\d+)/download', [new \App\Controllers\FileController(), 'download']);
$router->addRoute('POST', '/file/(\d+)/rate', [new \App\Controllers\FileController(), 'rate']);
$router->addRoute('GET', '/upload', [new \App\Controllers\FileController(), 'showUploadForm']);
$router->addRoute('POST', '/upload', [new \App\Controllers\FileController(), 'upload']);
$router->addRoute('GET', '/advanced-search', [new \App\Controllers\FileController(), 'advancedSearch']);

// User routes
$router->addRoute('GET', '/user/profile/(\d+)', [new \App\Controllers\UserController(), 'profile']);
$router->addRoute('POST', '/user/follow/(\d+)', [new \App\Controllers\UserController(), 'follow']);
$router->addRoute('POST', '/user/unfollow/(\d+)', [new \App\Controllers\UserController(), 'unfollow']);

// Message routes
$router->addRoute('GET', '/messages/inbox', [new \App\Controllers\MessageController(), 'inbox']);
$router->addRoute('GET', '/messages/sent', [new \App\Controllers\MessageController(), 'sent']);
$router->addRoute('GET', '/messages/view/(\d+)', [new \App\Controllers\MessageController(), 'view']);
$router->addRoute('GET', '/messages/compose', [new \App\Controllers\MessageController(), 'compose']);
$router->addRoute('POST', '/messages/compose', [new \App\Controllers\MessageController(), 'compose']);

// Gamification routes
$router->addRoute('GET', '/ranking', [new \App\Controllers\GamificationController(), 'showRanking']);
$router->addRoute('GET', '/achievements', [new \App\Controllers\GamificationController(), 'showAchievements']);
$router->addRoute('GET', '/challenges', [new \App\Controllers\GamificationController(), 'showChallenges']);
$router->addRoute('POST', '/daily-reward', [new \App\Controllers\GamificationController(), 'claimDailyReward']);

// Subscription routes
$router->addRoute('GET', '/subscription/plans', [new \App\Controllers\SubscriptionController(), 'showPlans']);
$router->addRoute('POST', '/subscription/subscribe', [new \App\Controllers\SubscriptionController(), 'subscribe']);
$router->addRoute('POST', '/subscription/cancel', [new \App\Controllers\SubscriptionController(), 'cancel']);

// Payment routes
$router->addRoute('POST', '/payment/process', [new \App\Controllers\PaymentController(), 'processPayment']);
$router->addRoute('GET', '/payment/success', [new \App\Controllers\PaymentController(), 'showSuccess']);
$router->addRoute('GET', '/payment/cancel', [new \App\Controllers\PaymentController(), 'showCancel']);

// Admin routes
$router->addRoute('GET', '/admin/dashboard', [new \App\Controllers\AdminController(), 'dashboard']);
$router->addRoute('GET', '/admin/user-management', [new \App\Controllers\AdminController(), 'userManagement']);
$router->addRoute('GET', '/admin/edit-user/(\d+)', [new \App\Controllers\AdminController(), 'editUser']);
$router->addRoute('POST', '/admin/edit-user/(\d+)', [new \App\Controllers\AdminController(), 'editUser']);
$router->addRoute('GET', '/admin/content-moderation', [new \App\Controllers\AdminController(), 'contentModeration']);
$router->addRoute('GET', '/admin/moderate-file/(\d+)', [new \App\Controllers\AdminController(), 'moderateFile']);
$router->addRoute('POST', '/admin/moderate-file/(\d+)', [new \App\Controllers\AdminController(), 'moderateFile']);
$router->addRoute('GET', '/admin/subscription-management', [new \App\Controllers\AdminController(), 'subscriptionManagement']);
$router->addRoute('GET', '/admin/edit-subscription/(\d+)', [new \App\Controllers\AdminController(), 'editSubscription']);
$router->addRoute('POST', '/admin/edit-subscription/(\d+)', [new \App\Controllers\AdminController(), 'editSubscription']);
$router->addRoute('GET', '/admin/reports', [new \App\Controllers\AdminController(), 'reports']);

// Special event routes
$router->addRoute('GET', '/special-event', [new \App\Controllers\SpecialEventController(), 'showCurrentEvent']);
$router->addRoute('POST', '/special-event/participate', [new \App\Controllers\SpecialEventController(), 'participate']);

// Report routes
$router->addRoute('POST', '/report/create', [new \App\Controllers\ReportController(), 'createReport']);
$router->addRoute('GET', '/admin/reports', [new \App\Controllers\ReportController(), 'listReports']);
$router->addRoute('GET', '/admin/handle-report/(\d+)', [new \App\Controllers\ReportController(), 'handleReport']);
$router->addRoute('POST', '/admin/handle-report/(\d+)', [new \App\Controllers\ReportController(), 'handleReport']);

// Notification routes
$router->addRoute('GET', '/notifications', [new \App\Controllers\NotificationController(), 'showAll']);
$router->addRoute('GET', '/notifications/unread', [new \App\Controllers\NotificationController(), 'getUnreadNotifications']);
$router->addRoute('POST', '/notifications/mark-as-read', [new \App\Controllers\NotificationController(), 'markAsRead']);

// Onboarding routes
$router->addRoute('GET', '/onboarding', [new \App\Controllers\OnboardingController(), 'showOnboarding']);
$router->addRoute('POST', '/onboarding/complete-step', [new \App\Controllers\OnboardingController(), 'completeStep']);

// Installation routes (only available when not installed)
if (!file_exists(BASE_PATH . '/install.lock')) {
    $router->addRoute('GET', '/install', [new \App\Controllers\InstallController(), 'showWelcome']);
    $router->addRoute('GET', '/install/requirements', [new \App\Controllers\InstallController(), 'checkRequirements']);
    $router->addRoute('GET', '/install/database', [new \App\Controllers\InstallController(), 'showDatabaseForm']);
    $router->addRoute('POST', '/install/finish', [new \App\Controllers\InstallController(), 'configureDatabaseAndFinish']);
}