<?php

class UserFollow {
    private $db;

    public function __construct() {
        global $conn;
        $this->db = $conn;
    }

    public function followUser($followerId, $followedId) {
        $sql = "INSERT INTO user_follows (follower_id, followed_id) VALUES (?, ?)";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ii", $followerId, $followedId);
        return $stmt->execute();
    }

    public function unfollowUser($followerId, $followedId) {
        $sql = "DELETE FROM user_follows WHERE follower_id = ? AND followed_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ii", $followerId, $followedId);
        return $stmt->execute();
    }

    public function isFollowing($followerId, $followedId) {
        $sql = "SELECT * FROM user_follows WHERE follower_id = ? AND followed_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ii", $followerId, $followedId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;
    }

    public function getFollowers($userId) {
        $sql = "SELECT u.* FROM users u JOIN user_follows uf ON u.id = uf.follower_id WHERE uf.followed_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function getFollowing($userId) {
        $sql = "SELECT u.* FROM users u JOIN user_follows uf ON u.id = uf.followed_id WHERE uf.follower_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
}

