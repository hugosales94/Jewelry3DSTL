<?php

namespace App\Models;
require_once dirname(__DIR__) . '/models/Database.php';

class SpecialEvent {
    private $db;
    
    public function __construct() {
        $this->db = \Database::getInstance();
    }
    
    public function createEvent($data) {
        try {
            $this->db->query(
                "INSERT INTO special_events (
                    title, description, start_date, end_date,
                    type, status, reward_points, max_participants,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())",
                [
                    $data['title'],
                    $data['description'],
                    $data['start_date'],
                    $data['end_date'],
                    $data['type'],
                    $data['status'] ?? 'upcoming',
                    $data['reward_points'] ?? 0,
                    $data['max_participants'] ?? null
                ]
            );
            
            return $this->db->lastInsertId();
        } catch (\Exception $e) {
            error_log("Error creating special event: " . $e->getMessage());
            throw new \Exception("Failed to create special event");
        }
    }
    
    public function getEventById($id) {
        try {
            return $this->db->query(
                "SELECT e.*, 
                    COUNT(DISTINCT p.user_id) as participant_count
                FROM special_events e
                LEFT JOIN event_participants p ON e.id = p.event_id
                WHERE e.id = ?
                GROUP BY e.id",
                [$id]
            )->fetch();
        } catch (\Exception $e) {
            error_log("Error getting event: " . $e->getMessage());
            throw new \Exception("Failed to retrieve event");
        }
    }
    
    public function getActiveEvents() {
        try {
            return $this->db->query(
                "SELECT e.*, 
                    COUNT(DISTINCT p.user_id) as participant_count
                FROM special_events e
                LEFT JOIN event_participants p ON e.id = p.event_id
                WHERE e.status = 'active'
                AND e.start_date <= NOW()
                AND e.end_date >= NOW()
                GROUP BY e.id
                ORDER BY e.start_date ASC"
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting active events: " . $e->getMessage());
            throw new \Exception("Failed to retrieve active events");
        }
    }
    
    public function getUpcomingEvents() {
        try {
            return $this->db->query(
                "SELECT e.*, 
                    COUNT(DISTINCT p.user_id) as participant_count
                FROM special_events e
                LEFT JOIN event_participants p ON e.id = p.event_id
                WHERE e.status = 'upcoming'
                AND e.start_date > NOW()
                GROUP BY e.id
                ORDER BY e.start_date ASC"
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting upcoming events: " . $e->getMessage());
            throw new \Exception("Failed to retrieve upcoming events");
        }
    }
    
    public function updateEvent($id, $data) {
        try {
            return $this->db->query(
                "UPDATE special_events SET
                    title = ?,
                    description = ?,
                    start_date = ?,
                    end_date = ?,
                    type = ?,
                    status = ?,
                    reward_points = ?,
                    max_participants = ?,
                    updated_at = NOW()
                WHERE id = ?",
                [
                    $data['title'],
                    $data['description'],
                    $data['start_date'],
                    $data['end_date'],
                    $data['type'],
                    $data['status'],
                    $data['reward_points'],
                    $data['max_participants'],
                    $id
                ]
            );
        } catch (\Exception $e) {
            error_log("Error updating event: " . $e->getMessage());
            throw new \Exception("Failed to update event");
        }
    }
    
    public function registerParticipant($eventId, $userId) {
        try {
            $this->db->beginTransaction();
            
            // Check if event is active and has space
            $event = $this->getEventById($eventId);
            
            if (!$event || $event['status'] !== 'active') {
                throw new \Exception("Event is not active");
            }
            
            if ($event['max_participants'] && 
                $event['participant_count'] >= $event['max_participants']) {
                throw new \Exception("Event has reached maximum participants");
            }
            
            // Register participant
            $this->db->query(
                "INSERT INTO event_participants (
                    event_id, user_id, joined_at
                ) VALUES (?, ?, NOW())",
                [$eventId, $userId]
            );
            
            // Award points if applicable
            if ($event['reward_points'] > 0) {
                $this->db->query(
                    "UPDATE users 
                    SET points = points + ?
                    WHERE id = ?",
                    [$event['reward_points'], $userId]
                );
            }
            
            $this->db->commit();
            return true;
            
        } catch (\Exception $e) {
            $this->db->rollBack();
            error_log("Error registering event participant: " . $e->getMessage());
            throw new \Exception("Failed to register for event");
        }
    }
    
    public function getEventParticipants($eventId) {
        try {
            return $this->db->query(
                "SELECT u.id, u.username, u.avatar,
                    p.joined_at, p.completed_at
                FROM event_participants p
                JOIN users u ON p.user_id = u.id
                WHERE p.event_id = ?
                ORDER BY p.joined_at ASC",
                [$eventId]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting event participants: " . $e->getMessage());
            throw new \Exception("Failed to retrieve event participants");
        }
    }
    
    public function getUserEvents($userId) {
        try {
            return $this->db->query(
                "SELECT e.*, p.joined_at, p.completed_at
                FROM special_events e
                JOIN event_participants p ON e.id = p.event_id
                WHERE p.user_id = ?
                ORDER BY e.start_date DESC",
                [$userId]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting user events: " . $e->getMessage());
            throw new \Exception("Failed to retrieve user events");
        }
    }
    
    public function completeEvent($eventId, $userId) {
        try {
            return $this->db->query(
                "UPDATE event_participants 
                SET completed_at = NOW()
                WHERE event_id = ? AND user_id = ?",
                [$eventId, $userId]
            );
        } catch (\Exception $e) {
            error_log("Error completing event: " . $e->getMessage());
            throw new \Exception("Failed to complete event");
        }
    }
}