<?php

namespace App\Models;
require_once dirname(__DIR__) . '/models/Database.php';

class Report {
    private $db;
    
    public function __construct() {
        $this->db = \Database::getInstance();
    }
    
    public function createReport($data) {
        try {
            $this->db->query(
                "INSERT INTO reports (
                    user_id, reported_user_id, type, reason,
                    content, status, created_at
                ) VALUES (?, ?, ?, ?, ?, 'pending', NOW())",
                [
                    $data['user_id'],
                    $data['reported_user_id'],
                    $data['type'],
                    $data['reason'],
                    $data['content']
                ]
            );
            
            return $this->db->lastInsertId();
        } catch (\Exception $e) {
            error_log("Error creating report: " . $e->getMessage());
            throw new \Exception("Failed to create report");
        }
    }
    
    public function getReportById($id) {
        try {
            return $this->db->query(
                "SELECT r.*, 
                    u1.username as reporter_name,
                    u2.username as reported_user_name
                FROM reports r
                JOIN users u1 ON r.user_id = u1.id
                JOIN users u2 ON r.reported_user_id = u2.id
                WHERE r.id = ?",
                [$id]
            )->fetch();
        } catch (\Exception $e) {
            error_log("Error getting report: " . $e->getMessage());
            throw new \Exception("Failed to retrieve report");
        }
    }
    
    public function getPendingReports($limit = 10, $offset = 0) {
        try {
            return $this->db->query(
                "SELECT r.*, 
                    u1.username as reporter_name,
                    u2.username as reported_user_name
                FROM reports r
                JOIN users u1 ON r.user_id = u1.id
                JOIN users u2 ON r.reported_user_id = u2.id
                WHERE r.status = 'pending'
                ORDER BY r.created_at DESC
                LIMIT ? OFFSET ?",
                [$limit, $offset]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting pending reports: " . $e->getMessage());
            throw new \Exception("Failed to retrieve pending reports");
        }
    }
    
    public function updateReportStatus($id, $status, $adminId, $resolution = null) {
        try {
            return $this->db->query(
                "UPDATE reports 
                SET status = ?,
                    admin_id = ?,
                    resolution = ?,
                    resolved_at = NOW()
                WHERE id = ?",
                [$status, $adminId, $resolution, $id]
            );
        } catch (\Exception $e) {
            error_log("Error updating report status: " . $e->getMessage());
            throw new \Exception("Failed to update report status");
        }
    }
    
    public function getUserReports($userId) {
        try {
            return $this->db->query(
                "SELECT r.*, 
                    u2.username as reported_user_name
                FROM reports r
                JOIN users u2 ON r.reported_user_id = u2.id
                WHERE r.user_id = ?
                ORDER BY r.created_at DESC",
                [$userId]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting user reports: " . $e->getMessage());
            throw new \Exception("Failed to retrieve user reports");
        }
    }
    
    public function getReportsByType($type, $status = null, $limit = 10, $offset = 0) {
        try {
            $params = [$type];
            $statusCondition = "";
            
            if ($status) {
                $statusCondition = "AND r.status = ?";
                $params[] = $status;
            }
            
            $params[] = $limit;
            $params[] = $offset;
            
            return $this->db->query(
                "SELECT r.*, 
                    u1.username as reporter_name,
                    u2.username as reported_user_name
                FROM reports r
                JOIN users u1 ON r.user_id = u1.id
                JOIN users u2 ON r.reported_user_id = u2.id
                WHERE r.type = ?
                {$statusCondition}
                ORDER BY r.created_at DESC
                LIMIT ? OFFSET ?",
                $params
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting reports by type: " . $e->getMessage());
            throw new \Exception("Failed to retrieve reports");
        }
    }
    
    public function getReportStats($startDate = null, $endDate = null) {
        try {
            $params = [];
            $dateCondition = "";
            
            if ($startDate && $endDate) {
                $dateCondition = "WHERE created_at BETWEEN ? AND ?";
                $params = [$startDate, $endDate];
            }
            
            return $this->db->query(
                "SELECT 
                    COUNT(*) as total_reports,
                    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_reports,
                    COUNT(CASE WHEN status = 'resolved' THEN 1 END) as resolved_reports,
                    COUNT(CASE WHEN status = 'dismissed' THEN 1 END) as dismissed_reports,
                    type,
                    AVG(TIMESTAMPDIFF(HOUR, created_at, 
                        CASE WHEN resolved_at IS NOT NULL THEN resolved_at 
                        ELSE NOW() END)) as avg_resolution_time
                FROM reports
                {$dateCondition}
                GROUP BY type",
                $params
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting report stats: " . $e->getMessage());
            throw new \Exception("Failed to retrieve report statistics");
        }
    }
}