<?php

namespace App\Models;
require_once dirname(__DIR__) . '/models/Database.php';

class RecommendationModel {
    private $db;
    
    public function __construct() {
        $this->db = \Database::getInstance();
    }
    
    public static function getRecommendedFiles($userId, $limit = 10) {
        $db = \Database::getInstance();
        try {
            // Get user's interests based on their download and rating history
            $userInterests = $db->query(
                "SELECT DISTINCT c.id, c.name
                 FROM categories c
                 JOIN file_categories fc ON c.id = fc.category_id
                 JOIN files f ON fc.file_id = f.id
                 LEFT JOIN downloads d ON f.id = d.file_id AND d.user_id = ?
                 LEFT JOIN ratings r ON f.id = r.file_id AND r.user_id = ?
                 WHERE d.id IS NOT NULL OR r.id IS NOT NULL",
                [$userId, $userId]
            )->fetchAll();
            
            if (empty($userInterests)) {
                // If no interests found, return popular files
                return self::getPopularFiles($limit);
            }
            
            // Get category IDs
            $categoryIds = array_column($userInterests, 'id');
            
            // Get recommended files based on user's interests
            $placeholders = str_repeat('?,', count($categoryIds) - 1) . '?';
            $params = array_merge([$userId], $categoryIds);
            
            return $db->query(
                "SELECT DISTINCT f.*, u.username,
                        COUNT(DISTINCT d.id) as download_count,
                        AVG(r.rating) as avg_rating
                 FROM files f
                 JOIN file_categories fc ON f.id = fc.file_id
                 JOIN users u ON f.user_id = u.id
                 LEFT JOIN downloads d ON f.id = d.file_id
                 LEFT JOIN ratings r ON f.id = r.file_id
                 WHERE f.status = 'approved'
                 AND f.user_id != ?
                 AND fc.category_id IN ($placeholders)
                 GROUP BY f.id
                 ORDER BY avg_rating DESC, download_count DESC
                 LIMIT ?",
                array_merge($params, [$limit])
            )->fetchAll();
            
        } catch (\Exception $e) {
            error_log("Error getting recommended files: " . $e->getMessage());
            throw new \Exception("Failed to get recommendations.");
        }
    }
    
    public static function getPopularFiles($limit = 10) {
        $db = \Database::getInstance();
        try {
            return $db->query(
                "SELECT f.*, u.username,
                        COUNT(DISTINCT d.id) as download_count,
                        AVG(r.rating) as avg_rating
                 FROM files f
                 JOIN users u ON f.user_id = u.id
                 LEFT JOIN downloads d ON f.id = d.file_id
                 LEFT JOIN ratings r ON f.id = r.file_id
                 WHERE f.status = 'approved'
                 GROUP BY f.id
                 ORDER BY download_count DESC, avg_rating DESC
                 LIMIT ?",
                [$limit]
            )->fetchAll();
            
        } catch (\Exception $e) {
            error_log("Error getting popular files: " . $e->getMessage());
            throw new \Exception("Failed to get popular files.");
        }
    }
    
    public static function getSimilarFiles($fileId, $limit = 6) {
        $db = \Database::getInstance();
        try {
            // Get file's categories
            $categories = $db->query(
                "SELECT category_id 
                 FROM file_categories 
                 WHERE file_id = ?",
                [$fileId]
            )->fetchAll();
            
            if (empty($categories)) {
                return [];
            }
            
            // Get category IDs
            $categoryIds = array_column($categories, 'category_id');
            
            // Get similar files based on shared categories
            $placeholders = str_repeat('?,', count($categoryIds) - 1) . '?';
            $params = array_merge([$fileId], $categoryIds);
            
            return $db->query(
                "SELECT DISTINCT f.*, u.username,
                        COUNT(DISTINCT d.id) as download_count,
                        AVG(r.rating) as avg_rating,
                        COUNT(DISTINCT fc.category_id) as shared_categories
                 FROM files f
                 JOIN file_categories fc ON f.id = fc.file_id
                 JOIN users u ON f.user_id = u.id
                 LEFT JOIN downloads d ON f.id = d.file_id
                 LEFT JOIN ratings r ON f.id = r.file_id
                 WHERE f.status = 'approved'
                 AND f.id != ?
                 AND fc.category_id IN ($placeholders)
                 GROUP BY f.id
                 ORDER BY shared_categories DESC, avg_rating DESC, download_count DESC
                 LIMIT ?",
                array_merge($params, [$limit])
            )->fetchAll();
            
        } catch (\Exception $e) {
            error_log("Error getting similar files: " . $e->getMessage());
            throw new \Exception("Failed to get similar files.");
        }
    }
    
    public static function getUserRecommendations($userId, $limit = 10) {
        $db = \Database::getInstance();
        try {
            // Get user's download history
            $downloads = $db->query(
                "SELECT DISTINCT f.id
                 FROM files f
                 JOIN downloads d ON f.id = d.file_id
                 WHERE d.user_id = ?",
                [$userId]
            )->fetchAll();
            
            // Get user's ratings
            $ratings = $db->query(
                "SELECT file_id, rating
                 FROM ratings
                 WHERE user_id = ?",
                [$userId]
            )->fetchAll();
            
            // If no history, return popular files
            if (empty($downloads) && empty($ratings)) {
                return self::getPopularFiles($limit);
            }
            
            // Get files from users who downloaded the same files
            $downloadedFiles = array_column($downloads, 'id');
            if (!empty($downloadedFiles)) {
                $placeholders = str_repeat('?,', count($downloadedFiles) - 1) . '?';
                $params = array_merge([$userId], $downloadedFiles);
                
                $similarUserFiles = $db->query(
                    "SELECT DISTINCT f.*, u.username,
                            COUNT(DISTINCT d2.user_id) as shared_users
                     FROM files f
                     JOIN downloads d ON f.id = d.file_id
                     JOIN downloads d2 ON d2.user_id = d.user_id
                     JOIN users u ON f.user_id = u.id
                     WHERE f.status = 'approved'
                     AND f.user_id != ?
                     AND d2.file_id IN ($placeholders)
                     GROUP BY f.id
                     ORDER BY shared_users DESC
                     LIMIT ?",
                    array_merge($params, [$limit])
                )->fetchAll();
                
                if (!empty($similarUserFiles)) {
                    return $similarUserFiles;
                }
            }
            
            // Fallback to category-based recommendations
            return self::getRecommendedFiles($userId, $limit);
            
        } catch (\Exception $e) {
            error_log("Error getting user recommendations: " . $e->getMessage());
            throw new \Exception("Failed to get user recommendations.");
        }
    }
}