<?php

namespace App\Models;
require_once dirname(__DIR__) . '/models/Database.php';

class User {
    private $db;
    
    public function __construct() {
        $this->db = \Database::getInstance();
    }
    
    public static function create($data) {
        $db = \Database::getInstance();
        try {
            $db->beginTransaction();
            
            // Check if email already exists
            $existingUser = $db->query(
                "SELECT id FROM users WHERE email = ?",
                [$data['email']]
            )->fetch();
            
            if ($existingUser) {
                throw new \Exception('Email already registered');
            }
            
            // Check if username already exists
            $existingUsername = $db->query(
                "SELECT id FROM users WHERE username = ?",
                [$data['username']]
            )->fetch();
            
            if ($existingUsername) {
                throw new \Exception('Username already taken');
            }
            
            // Hash password
            $hashedPassword = password_hash($data['password'], PASSWORD_DEFAULT);
            
            // Generate verification token
            $verificationToken = bin2hex(random_bytes(32));
            
            // Create user
            $stmt = $db->query(
                "INSERT INTO users (username, email, password, verification_token, status, role, created_at) 
                 VALUES (?, ?, ?, ?, ?, ?, NOW())",
                [
                    $data['username'],
                    $data['email'],
                    $hashedPassword,
                    $verificationToken,
                    'pending',
                    $data['role'] ?? 'user'
                ]
            );
            
            $userId = $db->lastInsertId();
            
            // Create user preferences
            $db->query(
                "INSERT INTO user_preferences (user_id) VALUES (?)",
                [$userId]
            );
            
            $db->commit();
            
            return [
                'id' => $userId,
                'verification_token' => $verificationToken
            ];
            
        } catch (\Exception $e) {
            $db->rollBack();
            error_log("Error creating user: " . $e->getMessage());
            throw new \Exception($e->getMessage());
        }
    }
    
    public static function findById($id) {
        $db = \Database::getInstance();
        try {
            return $db->query(
                "SELECT u.*, up.notifications, up.email_updates, up.public_profile 
                 FROM users u 
                 LEFT JOIN user_preferences up ON u.id = up.user_id 
                 WHERE u.id = ?",
                [$id]
            )->fetch();
            
        } catch (\Exception $e) {
            error_log("Error finding user: " . $e->getMessage());
            throw new \Exception("Failed to retrieve user information.");
        }
    }
    
    public static function findByEmail($email) {
        $db = \Database::getInstance();
        try {
            return $db->query(
                "SELECT u.*, up.notifications, up.email_updates, up.public_profile 
                 FROM users u 
                 LEFT JOIN user_preferences up ON u.id = up.user_id 
                 WHERE u.email = ?",
                [$email]
            )->fetch();
            
        } catch (\Exception $e) {
            error_log("Error finding user by email: " . $e->getMessage());
            throw new \Exception("Failed to retrieve user information.");
        }
    }
    
    public static function update($id, $data) {
        $db = \Database::getInstance();
        try {
            $db->beginTransaction();
            
            $updateFields = [];
            $updateParams = [];
            
            if (isset($data['username'])) {
                // Check if username is taken by another user
                $existing = $db->query(
                    "SELECT id FROM users WHERE username = ? AND id != ?",
                    [$data['username'], $id]
                )->fetch();
                
                if ($existing) {
                    throw new \Exception('Username already taken');
                }
                
                $updateFields[] = "username = ?";
                $updateParams[] = $data['username'];
            }
            
            if (isset($data['email'])) {
                // Check if email is taken by another user
                $existing = $db->query(
                    "SELECT id FROM users WHERE email = ? AND id != ?",
                    [$data['email'], $id]
                )->fetch();
                
                if ($existing) {
                    throw new \Exception('Email already registered');
                }
                
                $updateFields[] = "email = ?";
                $updateParams[] = $data['email'];
            }
            
            if (isset($data['password'])) {
                $updateFields[] = "password = ?";
                $updateParams[] = password_hash($data['password'], PASSWORD_DEFAULT);
            }
            
            if (isset($data['status'])) {
                $updateFields[] = "status = ?";
                $updateParams[] = $data['status'];
            }
            
            if (!empty($updateFields)) {
                $updateParams[] = $id;
                $db->query(
                    "UPDATE users SET " . implode(", ", $updateFields) . " WHERE id = ?",
                    $updateParams
                );
            }
            
            // Update preferences if provided
            if (isset($data['preferences'])) {
                $db->query(
                    "UPDATE user_preferences SET 
                     notifications = ?, 
                     email_updates = ?, 
                     public_profile = ? 
                     WHERE user_id = ?",
                    [
                        $data['preferences']['notifications'] ?? 0,
                        $data['preferences']['email_updates'] ?? 0,
                        $data['preferences']['public_profile'] ?? 0,
                        $id
                    ]
                );
            }
            
            $db->commit();
            return true;
            
        } catch (\Exception $e) {
            $db->rollBack();
            error_log("Error updating user: " . $e->getMessage());
            throw new \Exception($e->getMessage());
        }
    }
    
    public static function delete($id) {
        $db = \Database::getInstance();
        try {
            $db->beginTransaction();
            
            // Delete user related data
            $db->query("DELETE FROM user_preferences WHERE user_id = ?", [$id]);
            $db->query("DELETE FROM remember_tokens WHERE user_id = ?", [$id]);
            $db->query("DELETE FROM password_resets WHERE user_id = ?", [$id]);
            $db->query("DELETE FROM login_logs WHERE user_id = ?", [$id]);
            
            // Delete user
            $db->query("DELETE FROM users WHERE id = ?", [$id]);
            
            $db->commit();
            return true;
            
        } catch (\Exception $e) {
            $db->rollBack();
            error_log("Error deleting user: " . $e->getMessage());
            throw new \Exception("Failed to delete user.");
        }
    }
    
    public static function verifyEmail($token) {
        $db = \Database::getInstance();
        try {
            $user = $db->query(
                "SELECT id FROM users WHERE verification_token = ? AND email_verified_at IS NULL",
                [$token]
            )->fetch();
            
            if (!$user) {
                throw new \Exception('Invalid or expired verification token');
            }
            
            $db->query(
                "UPDATE users SET 
                 email_verified_at = NOW(),
                 verification_token = NULL,
                 status = 'active'
                 WHERE id = ?",
                [$user['id']]
            );
            
            return true;
            
        } catch (\Exception $e) {
            error_log("Error verifying email: " . $e->getMessage());
            throw new \Exception($e->getMessage());
        }
    }
}