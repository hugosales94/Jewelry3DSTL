<?php

namespace App\Models;
require_once dirname(__DIR__) . '/models/Database.php';

class Badge {
    private $db;
    
    public function __construct() {
        $this->db = \Database::getInstance();
    }
    
    public function getUserBadges($userId) {
        try {
            return $this->db->query(
                "SELECT b.*, ub.awarded_at
                FROM badges b
                JOIN user_badges ub ON b.id = ub.badge_id
                WHERE ub.user_id = ?
                ORDER BY ub.awarded_at DESC",
                [$userId]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting user badges: " . $e->getMessage());
            throw new \Exception("Failed to retrieve badges");
        }
    }
    
    public function getAvailableBadges($userId) {
        try {
            return $this->db->query(
                "SELECT b.*
                FROM badges b
                LEFT JOIN user_badges ub ON b.id = ub.badge_id AND ub.user_id = ?
                WHERE ub.id IS NULL
                ORDER BY b.required_points ASC",
                [$userId]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting available badges: " . $e->getMessage());
            throw new \Exception("Failed to retrieve available badges");
        }
    }
    
    public function checkAndAwardBadges($userId) {
        try {
            $this->db->beginTransaction();
            
            // Get user's current stats
            $userStats = $this->db->query(
                "SELECT 
                    points,
                    (SELECT COUNT(*) FROM files WHERE user_id = u.id) as upload_count,
                    (SELECT COUNT(*) FROM downloads WHERE user_id = u.id) as download_count,
                    (SELECT COUNT(*) FROM ratings WHERE user_id = u.id) as rating_count
                FROM users u
                WHERE u.id = ?",
                [$userId]
            )->fetch();
            
            // Get badges user doesn't have yet
            $availableBadges = $this->getAvailableBadges($userId);
            $newBadges = [];
            
            foreach ($availableBadges as $badge) {
                $qualified = false;
                
                switch ($badge['condition_type']) {
                    case 'points':
                        $qualified = $userStats['points'] >= $badge['required_points'];
                        break;
                    case 'uploads':
                        $qualified = $userStats['upload_count'] >= $badge['required_count'];
                        break;
                    case 'downloads':
                        $qualified = $userStats['download_count'] >= $badge['required_count'];
                        break;
                    case 'ratings':
                        $qualified = $userStats['rating_count'] >= $badge['required_count'];
                        break;
                }
                
                if ($qualified) {
                    // Award the badge
                    $this->db->query(
                        "INSERT INTO user_badges (user_id, badge_id, awarded_at)
                        VALUES (?, ?, NOW())",
                        [$userId, $badge['id']]
                    );
                    
                    // Add points for earning the badge
                    if ($badge['points_reward'] > 0) {
                        $this->db->query(
                            "UPDATE users 
                            SET points = points + ?
                            WHERE id = ?",
                            [$badge['points_reward'], $userId]
                        );
                    }
                    
                    $newBadges[] = $badge;
                }
            }
            
            $this->db->commit();
            return $newBadges;
            
        } catch (\Exception $e) {
            $this->db->rollBack();
            error_log("Error checking and awarding badges: " . $e->getMessage());
            throw new \Exception("Failed to check and award badges");
        }
    }
    
    public function createBadge($data) {
        try {
            $this->db->query(
                "INSERT INTO badges (
                    name, description, icon, condition_type,
                    required_points, required_count, points_reward,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())",
                [
                    $data['name'],
                    $data['description'],
                    $data['icon'],
                    $data['condition_type'],
                    $data['required_points'] ?? 0,
                    $data['required_count'] ?? 0,
                    $data['points_reward'] ?? 0
                ]
            );
            
            return $this->db->lastInsertId();
        } catch (\Exception $e) {
            error_log("Error creating badge: " . $e->getMessage());
            throw new \Exception("Failed to create badge");
        }
    }
    
    public function updateBadge($id, $data) {
        try {
            return $this->db->query(
                "UPDATE badges SET
                    name = ?,
                    description = ?,
                    icon = ?,
                    condition_type = ?,
                    required_points = ?,
                    required_count = ?,
                    points_reward = ?,
                    updated_at = NOW()
                WHERE id = ?",
                [
                    $data['name'],
                    $data['description'],
                    $data['icon'],
                    $data['condition_type'],
                    $data['required_points'] ?? 0,
                    $data['required_count'] ?? 0,
                    $data['points_reward'] ?? 0,
                    $id
                ]
            );
        } catch (\Exception $e) {
            error_log("Error updating badge: " . $e->getMessage());
            throw new \Exception("Failed to update badge");
        }
    }
    
    public function deleteBadge($id) {
        try {
            return $this->db->query(
                "DELETE FROM badges WHERE id = ?",
                [$id]
            );
        } catch (\Exception $e) {
            error_log("Error deleting badge: " . $e->getMessage());
            throw new \Exception("Failed to delete badge");
        }
    }
}