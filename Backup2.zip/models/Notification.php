<?php

namespace App\Models;
require_once dirname(__DIR__) . '/models/Database.php';

class Notification {
    private $db;
    
    public function __construct() {
        $this->db = \Database::getInstance();
    }
    
    public static function create($data) {
        $db = \Database::getInstance();
        try {
            return $db->query(
                "INSERT INTO notifications (
                    user_id, type, title, message, link, 
                    is_read, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, NOW())",
                [
                    $data['user_id'],
                    $data['type'],
                    $data['title'],
                    $data['message'],
                    $data['link'] ?? null,
                    0 // Not read by default
                ]
            );
            
        } catch (\Exception $e) {
            error_log("Error creating notification: " . $e->getMessage());
            throw new \Exception("Failed to create notification.");
        }
    }
    
    public static function getUserNotifications($userId, $limit = 20, $offset = 0) {
        $db = \Database::getInstance();
        try {
            return $db->query(
                "SELECT * FROM notifications 
                 WHERE user_id = ? 
                 ORDER BY created_at DESC 
                 LIMIT ? OFFSET ?",
                [$userId, $limit, $offset]
            )->fetchAll();
            
        } catch (\Exception $e) {
            error_log("Error getting user notifications: " . $e->getMessage());
            throw new \Exception("Failed to retrieve notifications.");
        }
    }
    
    public static function getUnreadCount($userId) {
        $db = \Database::getInstance();
        try {
            return $db->query(
                "SELECT COUNT(*) as count 
                 FROM notifications 
                 WHERE user_id = ? AND is_read = 0",
                [$userId]
            )->fetch()['count'];
            
        } catch (\Exception $e) {
            error_log("Error getting unread count: " . $e->getMessage());
            throw new \Exception("Failed to get unread count.");
        }
    }
    
    public static function markAsRead($id) {
        $db = \Database::getInstance();
        try {
            return $db->query(
                "UPDATE notifications SET is_read = 1 WHERE id = ?",
                [$id]
            );
            
        } catch (\Exception $e) {
            error_log("Error marking notification as read: " . $e->getMessage());
            throw new \Exception("Failed to mark notification as read.");
        }
    }
    
    public static function markAllAsRead($userId) {
        $db = \Database::getInstance();
        try {
            return $db->query(
                "UPDATE notifications SET is_read = 1 WHERE user_id = ?",
                [$userId]
            );
            
        } catch (\Exception $e) {
            error_log("Error marking all notifications as read: " . $e->getMessage());
            throw new \Exception("Failed to mark notifications as read.");
        }
    }
    
    public static function delete($id) {
        $db = \Database::getInstance();
        try {
            return $db->query(
                "DELETE FROM notifications WHERE id = ?",
                [$id]
            );
            
        } catch (\Exception $e) {
            error_log("Error deleting notification: " . $e->getMessage());
            throw new \Exception("Failed to delete notification.");
        }
    }
    
    public static function deleteAllRead($userId) {
        $db = \Database::getInstance();
        try {
            return $db->query(
                "DELETE FROM notifications 
                 WHERE user_id = ? AND is_read = 1",
                [$userId]
            );
            
        } catch (\Exception $e) {
            error_log("Error deleting read notifications: " . $e->getMessage());
            throw new \Exception("Failed to delete read notifications.");
        }
    }
}