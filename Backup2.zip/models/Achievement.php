<?php

namespace App\Models;
require_once dirname(__DIR__) . '/models/Database.php';

class Achievement {
    private $db;
    
    public function __construct() {
        $this->db = \Database::getInstance();
    }
    
    public function getUserAchievements($userId) {
        try {
            return $this->db->query(
                "SELECT a.*, ua.awarded_at, ua.progress
                FROM achievements a
                JOIN user_achievements ua ON a.id = ua.achievement_id
                WHERE ua.user_id = ?
                ORDER BY ua.awarded_at DESC",
                [$userId]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting user achievements: " . $e->getMessage());
            throw new \Exception("Failed to retrieve achievements");
        }
    }
    
    public function getUserProgress($userId) {
        try {
            return $this->db->query(
                "SELECT a.*, 
                    COALESCE(ua.progress, 0) as current_progress,
                    CASE 
                        WHEN ua.awarded_at IS NOT NULL THEN 100
                        WHEN a.required_count > 0 THEN 
                            LEAST(ROUND((COALESCE(ua.progress, 0) / a.required_count) * 100), 99)
                        ELSE 0
                    END as progress_percentage
                FROM achievements a
                LEFT JOIN user_achievements ua 
                    ON a.id = ua.achievement_id 
                    AND ua.user_id = ?
                ORDER BY a.required_count ASC",
                [$userId]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting achievement progress: " . $e->getMessage());
            throw new \Exception("Failed to retrieve achievement progress");
        }
    }
    
    public function checkAndAwardAchievements($userId) {
        try {
            $this->db->beginTransaction();
            
            // Get user's current stats
            $userStats = $this->db->query(
                "SELECT 
                    points,
                    (SELECT COUNT(*) FROM files WHERE user_id = u.id) as upload_count,
                    (SELECT COUNT(*) FROM downloads WHERE user_id = u.id) as download_count,
                    (SELECT COUNT(*) FROM ratings WHERE user_id = u.id) as rating_count,
                    (SELECT COUNT(DISTINCT DATE(created_at)) FROM user_logins WHERE user_id = u.id) as login_days,
                    (SELECT COUNT(*) FROM user_badges WHERE user_id = u.id) as badge_count
                FROM users u
                WHERE u.id = ?",
                [$userId]
            )->fetch();
            
            // Get achievements user hasn't completed yet
            $uncompletedAchievements = $this->db->query(
                "SELECT a.*
                FROM achievements a
                LEFT JOIN user_achievements ua 
                    ON a.id = ua.achievement_id 
                    AND ua.user_id = ?
                WHERE ua.awarded_at IS NULL",
                [$userId]
            )->fetchAll();
            
            $newAchievements = [];
            
            foreach ($uncompletedAchievements as $achievement) {
                $progress = 0;
                $completed = false;
                
                switch ($achievement['type']) {
                    case 'points':
                        $progress = $userStats['points'];
                        $completed = $progress >= $achievement['required_count'];
                        break;
                    case 'uploads':
                        $progress = $userStats['upload_count'];
                        $completed = $progress >= $achievement['required_count'];
                        break;
                    case 'downloads':
                        $progress = $userStats['download_count'];
                        $completed = $progress >= $achievement['required_count'];
                        break;
                    case 'ratings':
                        $progress = $userStats['rating_count'];
                        $completed = $progress >= $achievement['required_count'];
                        break;
                    case 'login_streak':
                        $progress = $userStats['login_days'];
                        $completed = $progress >= $achievement['required_count'];
                        break;
                    case 'badges':
                        $progress = $userStats['badge_count'];
                        $completed = $progress >= $achievement['required_count'];
                        break;
                }
                
                // Update or insert progress
                $existingProgress = $this->db->query(
                    "SELECT id FROM user_achievements 
                    WHERE user_id = ? AND achievement_id = ?",
                    [$userId, $achievement['id']]
                )->fetch();
                
                if ($existingProgress) {
                    $this->db->query(
                        "UPDATE user_achievements 
                        SET progress = ?,
                            awarded_at = CASE WHEN ? THEN NOW() ELSE awarded_at END
                        WHERE id = ?",
                        [$progress, $completed, $existingProgress['id']]
                    );
                } else {
                    $this->db->query(
                        "INSERT INTO user_achievements 
                        (user_id, achievement_id, progress, awarded_at)
                        VALUES (?, ?, ?, ?)",
                        [$userId, $achievement['id'], $progress, $completed ? date('Y-m-d H:i:s') : null]
                    );
                }
                
                if ($completed) {
                    // Add points reward
                    if ($achievement['points_reward'] > 0) {
                        $this->db->query(
                            "UPDATE users 
                            SET points = points + ?
                            WHERE id = ?",
                            [$achievement['points_reward'], $userId]
                        );
                    }
                    
                    $newAchievements[] = $achievement;
                }
            }
            
            $this->db->commit();
            return $newAchievements;
            
        } catch (\Exception $e) {
            $this->db->rollBack();
            error_log("Error checking and awarding achievements: " . $e->getMessage());
            throw new \Exception("Failed to check and award achievements");
        }
    }
    
    public function createAchievement($data) {
        try {
            $this->db->query(
                "INSERT INTO achievements (
                    name, description, icon, type,
                    required_count, points_reward, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, NOW())",
                [
                    $data['name'],
                    $data['description'],
                    $data['icon'],
                    $data['type'],
                    $data['required_count'],
                    $data['points_reward'] ?? 0
                ]
            );
            
            return $this->db->lastInsertId();
        } catch (\Exception $e) {
            error_log("Error creating achievement: " . $e->getMessage());
            throw new \Exception("Failed to create achievement");
        }
    }
    
    public function updateAchievement($id, $data) {
        try {
            return $this->db->query(
                "UPDATE achievements SET
                    name = ?,
                    description = ?,
                    icon = ?,
                    type = ?,
                    required_count = ?,
                    points_reward = ?,
                    updated_at = NOW()
                WHERE id = ?",
                [
                    $data['name'],
                    $data['description'],
                    $data['icon'],
                    $data['type'],
                    $data['required_count'],
                    $data['points_reward'] ?? 0,
                    $id
                ]
            );
        } catch (\Exception $e) {
            error_log("Error updating achievement: " . $e->getMessage());
            throw new \Exception("Failed to update achievement");
        }
    }
    
    public function deleteAchievement($id) {
        try {
            return $this->db->query(
                "DELETE FROM achievements WHERE id = ?",
                [$id]
            );
        } catch (\Exception $e) {
            error_log("Error deleting achievement: " . $e->getMessage());
            throw new \Exception("Failed to delete achievement");
        }
    }
}