<?php

namespace App\Models;
require_once dirname(__DIR__) . '/models/Database.php';

class Payment {
    private $db;
    
    public function __construct() {
        $this->db = \Database::getInstance();
    }
    
    public function createPayment($data) {
        try {
            $this->db->query(
                "INSERT INTO payments (
                    user_id, subscription_id, amount, currency,
                    payment_method, status, transaction_id,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())",
                [
                    $data['user_id'],
                    $data['subscription_id'],
                    $data['amount'],
                    $data['currency'],
                    $data['payment_method'],
                    $data['status'],
                    $data['transaction_id']
                ]
            );
            
            return $this->db->lastInsertId();
        } catch (\Exception $e) {
            error_log("Error creating payment: " . $e->getMessage());
            throw new \Exception("Failed to create payment record");
        }
    }
    
    public function getPaymentById($id) {
        try {
            return $this->db->query(
                "SELECT p.*, u.email as user_email
                FROM payments p
                JOIN users u ON p.user_id = u.id
                WHERE p.id = ?",
                [$id]
            )->fetch();
        } catch (\Exception $e) {
            error_log("Error getting payment: " . $e->getMessage());
            throw new \Exception("Failed to retrieve payment");
        }
    }
    
    public function getUserPayments($userId, $limit = 10, $offset = 0) {
        try {
            return $this->db->query(
                "SELECT p.*, s.name as subscription_name
                FROM payments p
                LEFT JOIN subscriptions sub ON p.subscription_id = sub.id
                LEFT JOIN subscription_plans s ON sub.plan_id = s.id
                WHERE p.user_id = ?
                ORDER BY p.created_at DESC
                LIMIT ? OFFSET ?",
                [$userId, $limit, $offset]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting user payments: " . $e->getMessage());
            throw new \Exception("Failed to retrieve payments");
        }
    }
    
    public function updatePaymentStatus($id, $status) {
        try {
            return $this->db->query(
                "UPDATE payments 
                SET status = ?,
                    updated_at = NOW()
                WHERE id = ?",
                [$status, $id]
            );
        } catch (\Exception $e) {
            error_log("Error updating payment status: " . $e->getMessage());
            throw new \Exception("Failed to update payment status");
        }
    }
    
    public function getPaymentsByDateRange($startDate, $endDate) {
        try {
            return $this->db->query(
                "SELECT p.*, u.email as user_email,
                    s.name as subscription_name
                FROM payments p
                JOIN users u ON p.user_id = u.id
                LEFT JOIN subscriptions sub ON p.subscription_id = sub.id
                LEFT JOIN subscription_plans s ON sub.plan_id = s.id
                WHERE p.created_at BETWEEN ? AND ?
                ORDER BY p.created_at DESC",
                [$startDate, $endDate]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting payments by date range: " . $e->getMessage());
            throw new \Exception("Failed to retrieve payments");
        }
    }
    
    public function getPaymentStats($startDate = null, $endDate = null) {
        try {
            $params = [];
            $dateCondition = "";
            
            if ($startDate && $endDate) {
                $dateCondition = "WHERE created_at BETWEEN ? AND ?";
                $params = [$startDate, $endDate];
            }
            
            return $this->db->query(
                "SELECT 
                    COUNT(*) as total_payments,
                    SUM(amount) as total_amount,
                    COUNT(DISTINCT user_id) as unique_users,
                    AVG(amount) as average_amount,
                    currency,
                    payment_method,
                    status
                FROM payments
                {$dateCondition}
                GROUP BY currency, payment_method, status",
                $params
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting payment stats: " . $e->getMessage());
            throw new \Exception("Failed to retrieve payment statistics");
        }
    }
    
    public function createRefund($paymentId, $amount, $reason) {
        try {
            $this->db->beginTransaction();
            
            $payment = $this->getPaymentById($paymentId);
            if (!$payment) {
                throw new \Exception("Payment not found");
            }
            
            // Create refund record
            $this->db->query(
                "INSERT INTO refunds (
                    payment_id, amount, reason, status,
                    created_at
                ) VALUES (?, ?, ?, 'pending', NOW())",
                [$paymentId, $amount, $reason]
            );
            
            $refundId = $this->db->lastInsertId();
            
            // Update payment status
            $this->updatePaymentStatus($paymentId, 'refunded');
            
            $this->db->commit();
            return $refundId;
            
        } catch (\Exception $e) {
            $this->db->rollBack();
            error_log("Error creating refund: " . $e->getMessage());
            throw new \Exception("Failed to create refund");
        }
    }
    
    public function updateRefundStatus($refundId, $status) {
        try {
            return $this->db->query(
                "UPDATE refunds 
                SET status = ?,
                    updated_at = NOW()
                WHERE id = ?",
                [$status, $refundId]
            );
        } catch (\Exception $e) {
            error_log("Error updating refund status: " . $e->getMessage());
            throw new \Exception("Failed to update refund status");
        }
    }
}