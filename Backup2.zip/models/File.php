<?php

namespace App\Models;
require_once dirname(__DIR__) . '/models/Database.php';

class File {
    private $db;
    
    public function __construct() {
        $this->db = \Database::getInstance();
    }
    
    public static function create($data) {
        $db = \Database::getInstance();
        try {
            $db->beginTransaction();
            
            $stmt = $db->query(
                "INSERT INTO files (user_id, name, description, file_path, file_size, mime_type, status, created_at) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, NOW())",
                [
                    $data['user_id'],
                    $data['name'],
                    $data['description'] ?? null,
                    $data['file_path'],
                    $data['file_size'],
                    $data['mime_type'],
                    $data['status'] ?? 'pending'
                ]
            );
            
            $fileId = $db->lastInsertId();
            
            // Add categories if provided
            if (!empty($data['categories'])) {
                foreach ($data['categories'] as $categoryId) {
                    $db->query(
                        "INSERT INTO file_categories (file_id, category_id) VALUES (?, ?)",
                        [$fileId, $categoryId]
                    );
                }
            }
            
            $db->commit();
            return $fileId;
            
        } catch (\Exception $e) {
            $db->rollBack();
            error_log("Error creating file: " . $e->getMessage());
            throw new \Exception("Failed to create file. Please try again.");
        }
    }
    
    public static function findById($id) {
        $db = \Database::getInstance();
        try {
            $file = $db->query(
                "SELECT f.*, u.username, GROUP_CONCAT(c.name) as categories
                 FROM files f
                 LEFT JOIN users u ON f.user_id = u.id
                 LEFT JOIN file_categories fc ON f.id = fc.file_id
                 LEFT JOIN categories c ON fc.category_id = c.id
                 WHERE f.id = ?
                 GROUP BY f.id",
                [$id]
            )->fetch();
            
            if ($file) {
                $file['categories'] = $file['categories'] ? explode(',', $file['categories']) : [];
            }
            
            return $file;
            
        } catch (\Exception $e) {
            error_log("Error finding file: " . $e->getMessage());
            throw new \Exception("Failed to retrieve file information.");
        }
    }
    
    public static function findByUser($userId, $page = 1, $limit = 20) {
        $db = \Database::getInstance();
        try {
            $offset = ($page - 1) * $limit;
            
            $files = $db->query(
                "SELECT f.*, COUNT(d.id) as download_count
                 FROM files f
                 LEFT JOIN downloads d ON f.id = d.file_id
                 WHERE f.user_id = ?
                 GROUP BY f.id
                 ORDER BY f.created_at DESC
                 LIMIT ? OFFSET ?",
                [$userId, $limit, $offset]
            )->fetchAll();
            
            $total = $db->query(
                "SELECT COUNT(*) as count FROM files WHERE user_id = ?",
                [$userId]
            )->fetch()['count'];
            
            return [
                'files' => $files,
                'total' => $total,
                'pages' => ceil($total / $limit)
            ];
            
        } catch (\Exception $e) {
            error_log("Error finding user files: " . $e->getMessage());
            throw new \Exception("Failed to retrieve files.");
        }
    }
    
    public static function search($params = [], $page = 1, $limit = 20) {
        $db = \Database::getInstance();
        try {
            $conditions = [];
            $queryParams = [];
            
            if (!empty($params['query'])) {
                $conditions[] = "(f.name LIKE ? OR f.description LIKE ?)";
                $queryParams[] = "%{$params['query']}%";
                $queryParams[] = "%{$params['query']}%";
            }
            
            if (!empty($params['category'])) {
                $conditions[] = "c.id = ?";
                $queryParams[] = $params['category'];
            }
            
            if (!empty($params['user'])) {
                $conditions[] = "f.user_id = ?";
                $queryParams[] = $params['user'];
            }
            
            if (!empty($params['status'])) {
                $conditions[] = "f.status = ?";
                $queryParams[] = $params['status'];
            }
            
            $whereClause = !empty($conditions) ? "WHERE " . implode(" AND ", $conditions) : "";
            $offset = ($page - 1) * $limit;
            
            // Add limit and offset to params
            $queryParams[] = $limit;
            $queryParams[] = $offset;
            
            $files = $db->query(
                "SELECT f.*, u.username, COUNT(d.id) as download_count
                 FROM files f
                 LEFT JOIN users u ON f.user_id = u.id
                 LEFT JOIN file_categories fc ON f.id = fc.file_id
                 LEFT JOIN categories c ON fc.category_id = c.id
                 LEFT JOIN downloads d ON f.id = d.file_id
                 $whereClause
                 GROUP BY f.id
                 ORDER BY f.created_at DESC
                 LIMIT ? OFFSET ?",
                $queryParams
            )->fetchAll();
            
            // Count total without limit
            array_pop($queryParams); // remove offset
            array_pop($queryParams); // remove limit
            
            $total = $db->query(
                "SELECT COUNT(DISTINCT f.id) as count
                 FROM files f
                 LEFT JOIN file_categories fc ON f.id = fc.file_id
                 LEFT JOIN categories c ON fc.category_id = c.id
                 $whereClause",
                $queryParams
            )->fetch()['count'];
            
            return [
                'files' => $files,
                'total' => $total,
                'pages' => ceil($total / $limit)
            ];
            
        } catch (\Exception $e) {
            error_log("Error searching files: " . $e->getMessage());
            throw new \Exception("Failed to search files.");
        }
    }
    
    public static function update($id, $data) {
        $db = \Database::getInstance();
        try {
            $db->beginTransaction();
            
            $updateFields = [];
            $updateParams = [];
            
            if (isset($data['name'])) {
                $updateFields[] = "name = ?";
                $updateParams[] = $data['name'];
            }
            
            if (isset($data['description'])) {
                $updateFields[] = "description = ?";
                $updateParams[] = $data['description'];
            }
            
            if (isset($data['status'])) {
                $updateFields[] = "status = ?";
                $updateParams[] = $data['status'];
            }
            
            if (!empty($updateFields)) {
                $updateParams[] = $id;
                $db->query(
                    "UPDATE files SET " . implode(", ", $updateFields) . " WHERE id = ?",
                    $updateParams
                );
            }
            
            // Update categories if provided
            if (isset($data['categories'])) {
                // Remove existing categories
                $db->query("DELETE FROM file_categories WHERE file_id = ?", [$id]);
                
                // Add new categories
                foreach ($data['categories'] as $categoryId) {
                    $db->query(
                        "INSERT INTO file_categories (file_id, category_id) VALUES (?, ?)",
                        [$id, $categoryId]
                    );
                }
            }
            
            $db->commit();
            return true;
            
        } catch (\Exception $e) {
            $db->rollBack();
            error_log("Error updating file: " . $e->getMessage());
            throw new \Exception("Failed to update file.");
        }
    }
    
    public static function delete($id) {
        $db = \Database::getInstance();
        try {
            $db->beginTransaction();
            
            // Get file info for physical deletion
            $file = $db->query("SELECT file_path FROM files WHERE id = ?", [$id])->fetch();
            
            if ($file) {
                // Delete physical file
                $fullPath = dirname(__DIR__) . '/uploads/' . $file['file_path'];
                if (file_exists($fullPath)) {
                    unlink($fullPath);
                }
                
                // Delete database records
                $db->query("DELETE FROM file_categories WHERE file_id = ?", [$id]);
                $db->query("DELETE FROM downloads WHERE file_id = ?", [$id]);
                $db->query("DELETE FROM ratings WHERE file_id = ?", [$id]);
                $db->query("DELETE FROM files WHERE id = ?", [$id]);
            }
            
            $db->commit();
            return true;
            
        } catch (\Exception $e) {
            $db->rollBack();
            error_log("Error deleting file: " . $e->getMessage());
            throw new \Exception("Failed to delete file.");
        }
    }
}