<?php

namespace App\Models;
require_once dirname(__DIR__) . '/models/Database.php';

class Rating {
    private $db;
    
    public function __construct() {
        $this->db = \Database::getInstance();
    }
    
    public static function create($data) {
        $db = \Database::getInstance();
        try {
            // Check if user has already rated this file
            $existingRating = $db->query(
                "SELECT id FROM ratings WHERE user_id = ? AND file_id = ?",
                [$data['user_id'], $data['file_id']]
            )->fetch();
            
            if ($existingRating) {
                throw new \Exception('You have already rated this file');
            }
            
            // Create rating
            $db->query(
                "INSERT INTO ratings (user_id, file_id, rating, comment, created_at) 
                 VALUES (?, ?, ?, ?, NOW())",
                [
                    $data['user_id'],
                    $data['file_id'],
                    $data['rating'],
                    $data['comment'] ?? null
                ]
            );
            
            // Update file average rating
            $db->query(
                "UPDATE files SET 
                 avg_rating = (
                     SELECT AVG(rating) 
                     FROM ratings 
                     WHERE file_id = ?
                 ),
                 rating_count = (
                     SELECT COUNT(*) 
                     FROM ratings 
                     WHERE file_id = ?
                 )
                 WHERE id = ?",
                [$data['file_id'], $data['file_id'], $data['file_id']]
            );
            
            return true;
            
        } catch (\Exception $e) {
            error_log("Error creating rating: " . $e->getMessage());
            throw new \Exception($e->getMessage());
        }
    }
    
    public static function getFileRatings($fileId, $page = 1, $limit = 10) {
        $db = \Database::getInstance();
        try {
            $offset = ($page - 1) * $limit;
            
            $ratings = $db->query(
                "SELECT r.*, u.username 
                 FROM ratings r
                 LEFT JOIN users u ON r.user_id = u.id
                 WHERE r.file_id = ?
                 ORDER BY r.created_at DESC
                 LIMIT ? OFFSET ?",
                [$fileId, $limit, $offset]
            )->fetchAll();
            
            $total = $db->query(
                "SELECT COUNT(*) as count FROM ratings WHERE file_id = ?",
                [$fileId]
            )->fetch()['count'];
            
            return [
                'ratings' => $ratings,
                'total' => $total,
                'pages' => ceil($total / $limit)
            ];
            
        } catch (\Exception $e) {
            error_log("Error getting file ratings: " . $e->getMessage());
            throw new \Exception("Failed to retrieve ratings.");
        }
    }
    
    public static function getUserRatings($userId, $page = 1, $limit = 10) {
        $db = \Database::getInstance();
        try {
            $offset = ($page - 1) * $limit;
            
            $ratings = $db->query(
                "SELECT r.*, f.name as file_name 
                 FROM ratings r
                 LEFT JOIN files f ON r.file_id = f.id
                 WHERE r.user_id = ?
                 ORDER BY r.created_at DESC
                 LIMIT ? OFFSET ?",
                [$userId, $limit, $offset]
            )->fetchAll();
            
            $total = $db->query(
                "SELECT COUNT(*) as count FROM ratings WHERE user_id = ?",
                [$userId]
            )->fetch()['count'];
            
            return [
                'ratings' => $ratings,
                'total' => $total,
                'pages' => ceil($total / $limit)
            ];
            
        } catch (\Exception $e) {
            error_log("Error getting user ratings: " . $e->getMessage());
            throw new \Exception("Failed to retrieve ratings.");
        }
    }
    
    public static function update($id, $data) {
        $db = \Database::getInstance();
        try {
            // Get current rating
            $rating = $db->query(
                "SELECT file_id FROM ratings WHERE id = ?",
                [$id]
            )->fetch();
            
            if (!$rating) {
                throw new \Exception('Rating not found');
            }
            
            // Update rating
            $db->query(
                "UPDATE ratings SET rating = ?, comment = ? WHERE id = ?",
                [$data['rating'], $data['comment'] ?? null, $id]
            );
            
            // Update file average rating
            $db->query(
                "UPDATE files SET 
                 avg_rating = (
                     SELECT AVG(rating) 
                     FROM ratings 
                     WHERE file_id = ?
                 )
                 WHERE id = ?",
                [$rating['file_id'], $rating['file_id']]
            );
            
            return true;
            
        } catch (\Exception $e) {
            error_log("Error updating rating: " . $e->getMessage());
            throw new \Exception($e->getMessage());
        }
    }
    
    public static function delete($id) {
        $db = \Database::getInstance();
        try {
            // Get rating info
            $rating = $db->query(
                "SELECT file_id FROM ratings WHERE id = ?",
                [$id]
            )->fetch();
            
            if (!$rating) {
                throw new \Exception('Rating not found');
            }
            
            // Delete rating
            $db->query("DELETE FROM ratings WHERE id = ?", [$id]);
            
            // Update file average rating
            $db->query(
                "UPDATE files SET 
                 avg_rating = (
                     SELECT AVG(rating) 
                     FROM ratings 
                     WHERE file_id = ?
                 ),
                 rating_count = (
                     SELECT COUNT(*) 
                     FROM ratings 
                     WHERE file_id = ?
                 )
                 WHERE id = ?",
                [$rating['file_id'], $rating['file_id'], $rating['file_id']]
            );
            
            return true;
            
        } catch (\Exception $e) {
            error_log("Error deleting rating: " . $e->getMessage());
            throw new \Exception("Failed to delete rating.");
        }
    }
}