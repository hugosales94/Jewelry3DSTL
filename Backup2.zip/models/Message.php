<?php

namespace App\Models;
require_once dirname(__DIR__) . '/models/Database.php';

class Message {
    private $db;
    
    public function __construct() {
        $this->db = \Database::getInstance();
    }
    
    public function getUserConversations($userId) {
        try {
            return $this->db->query(
                "SELECT 
                    m.*,
                    u.username as other_user_name,
                    u.avatar as other_user_avatar,
                    (
                        SELECT COUNT(*) 
                        FROM messages 
                        WHERE ((sender_id = ? AND recipient_id = m.other_user_id) 
                        OR (sender_id = m.other_user_id AND recipient_id = ?))
                        AND is_read = 0 
                        AND recipient_id = ?
                    ) as unread_count
                FROM (
                    SELECT 
                        CASE 
                            WHEN sender_id = ? THEN recipient_id
                            ELSE sender_id 
                        END as other_user_id,
                        MAX(created_at) as last_message_time,
                        MAX(id) as last_message_id
                    FROM messages 
                    WHERE sender_id = ? OR recipient_id = ?
                    GROUP BY other_user_id
                ) m
                JOIN users u ON u.id = m.other_user_id
                ORDER BY m.last_message_time DESC",
                [$userId, $userId, $userId, $userId, $userId, $userId]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting user conversations: " . $e->getMessage());
            throw new \Exception("Failed to retrieve conversations");
        }
    }
    
    public function getConversation($userId, $otherUserId, $limit = 50, $offset = 0) {
        try {
            return $this->db->query(
                "SELECT m.*, 
                    sender.username as sender_name,
                    sender.avatar as sender_avatar
                FROM messages m
                JOIN users sender ON sender.id = m.sender_id
                WHERE (sender_id = ? AND recipient_id = ?)
                OR (sender_id = ? AND recipient_id = ?)
                ORDER BY created_at DESC
                LIMIT ? OFFSET ?",
                [$userId, $otherUserId, $otherUserId, $userId, $limit, $offset]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting conversation: " . $e->getMessage());
            throw new \Exception("Failed to retrieve messages");
        }
    }
    
    public function sendMessage($senderId, $recipientId, $content) {
        try {
            $this->db->query(
                "INSERT INTO messages (sender_id, recipient_id, content, created_at)
                VALUES (?, ?, ?, NOW())",
                [$senderId, $recipientId, $content]
            );
            
            return $this->db->lastInsertId();
        } catch (\Exception $e) {
            error_log("Error sending message: " . $e->getMessage());
            throw new \Exception("Failed to send message");
        }
    }
    
    public function getMessageById($messageId) {
        try {
            return $this->db->query(
                "SELECT * FROM messages WHERE id = ?",
                [$messageId]
            )->fetch();
        } catch (\Exception $e) {
            error_log("Error getting message: " . $e->getMessage());
            throw new \Exception("Failed to retrieve message");
        }
    }
    
    public function deleteMessage($messageId, $userId) {
        try {
            return $this->db->query(
                "UPDATE messages 
                SET deleted_at = NOW(),
                    deleted_by = ?
                WHERE id = ? 
                AND (sender_id = ? OR recipient_id = ?)",
                [$userId, $messageId, $userId, $userId]
            );
        } catch (\Exception $e) {
            error_log("Error deleting message: " . $e->getMessage());
            throw new \Exception("Failed to delete message");
        }
    }
    
    public function markAsRead($messageId, $userId) {
        try {
            return $this->db->query(
                "UPDATE messages 
                SET is_read = 1,
                    read_at = NOW()
                WHERE id = ? 
                AND recipient_id = ?",
                [$messageId, $userId]
            );
        } catch (\Exception $e) {
            error_log("Error marking message as read: " . $e->getMessage());
            throw new \Exception("Failed to mark message as read");
        }
    }
    
    public function searchMessages($userId, $query) {
        try {
            $searchTerm = "%{$query}%";
            return $this->db->query(
                "SELECT m.*, 
                    sender.username as sender_name,
                    recipient.username as recipient_name
                FROM messages m
                JOIN users sender ON sender.id = m.sender_id
                JOIN users recipient ON recipient.id = m.recipient_id
                WHERE (sender_id = ? OR recipient_id = ?)
                AND content LIKE ?
                AND deleted_at IS NULL
                ORDER BY created_at DESC",
                [$userId, $userId, $searchTerm]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error searching messages: " . $e->getMessage());
            throw new \Exception("Failed to search messages");
        }
    }
    
    public function getUnreadCount($userId) {
        try {
            return $this->db->query(
                "SELECT COUNT(*) as count
                FROM messages 
                WHERE recipient_id = ?
                AND is_read = 0
                AND deleted_at IS NULL",
                [$userId]
            )->fetch()['count'];
        } catch (\Exception $e) {
            error_log("Error getting unread count: " . $e->getMessage());
            throw new \Exception("Failed to get unread message count");
        }
    }
}