<?php

namespace App\Models;

// Incluir o arquivo de configuração do banco de dados
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/models/Database.php';

class Onboarding {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function createOnboardingStep($userId, $step, $data) {
        try {
            return $this->db->query(
                "INSERT INTO onboarding_progress (user_id, step, data, completed_at) 
                 VALUES (?, ?, ?, NOW())",
                [$userId, $step, json_encode($data)]
            );
        } catch (\Exception $e) {
            error_log("Error creating onboarding step: " . $e->getMessage());
            throw new \Exception("Failed to save onboarding progress");
        }
    }

    public function getOnboardingProgress($userId) {
        try {
            return $this->db->query(
                "SELECT step, data, completed_at 
                 FROM onboarding_progress 
                 WHERE user_id = ? 
                 ORDER BY completed_at ASC",
                [$userId]
            )->fetchAll();
        } catch (\Exception $e) {
            error_log("Error getting onboarding progress: " . $e->getMessage());
            throw new \Exception("Failed to retrieve onboarding progress");
        }
    }

    public function getCurrentStep($userId) {
        try {
            $result = $this->db->query(
                "SELECT step 
                 FROM onboarding_progress 
                 WHERE user_id = ? 
                 ORDER BY completed_at DESC 
                 LIMIT 1",
                [$userId]
            )->fetch();

            return $result ? $result['step'] : 0;
        } catch (\Exception $e) {
            error_log("Error getting current onboarding step: " . $e->getMessage());
            throw new \Exception("Failed to retrieve current onboarding step");
        }
    }

    public function updateOnboardingStep($userId, $step, $data) {
        try {
            return $this->db->query(
                "UPDATE onboarding_progress 
                 SET data = ?, completed_at = NOW() 
                 WHERE user_id = ? AND step = ?",
                [json_encode($data), $userId, $step]
            );
        } catch (\Exception $e) {
            error_log("Error updating onboarding step: " . $e->getMessage());
            throw new \Exception("Failed to update onboarding progress");
        }
    }

    public function resetOnboarding($userId) {
        try {
            return $this->db->query(
                "DELETE FROM onboarding_progress WHERE user_id = ?",
                [$userId]
            );
        } catch (\Exception $e) {
            error_log("Error resetting onboarding: " . $e->getMessage());
            throw new \Exception("Failed to reset onboarding progress");
        }
    }

    public function isOnboardingComplete($userId) {
        try {
            $totalSteps = 5; // Update this based on your total number of onboarding steps
            $completedSteps = $this->db->query(
                "SELECT COUNT(DISTINCT step) as count 
                 FROM onboarding_progress 
                 WHERE user_id = ?",
                [$userId]
            )->fetch();

            return $completedSteps['count'] >= $totalSteps;
        } catch (\Exception $e) {
            error_log("Error checking onboarding completion: " . $e->getMessage());
            throw new \Exception("Failed to check onboarding completion status");
        }
    }
}