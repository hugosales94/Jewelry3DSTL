<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../utils/Logger.php';

class Activity {
    private $conn;

    public function __construct() {
        global $conn;
        $this->conn = $conn;
    }

    public function getRecentActivitiesForUser($userId, $limit = 5) {
        $sql = "SELECT * FROM activities 
                WHERE user_id = ? 
                ORDER BY created_at DESC 
                LIMIT ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ii", $userId, $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function logActivity($userId, $type, $description) {
        $sql = "INSERT INTO activities (user_id, type, description) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("iss", $userId, $type, $description);
        $result = $stmt->execute();
        
        if ($result) {
            Logger::info("Activity logged for user $userId: $type - $description");
        } else {
            Logger::error("Failed to log activity for user $userId: " . $stmt->error);
        }
        
        return $result;
    }
}

