<?php

class Gamification {
    private $db;

    public function __construct() {
        global $conn;
        $this->db = $conn;
    }

    public function updateUserScore($userId, $action) {
        $points = $this->getPointsForAction($action);
        $sql = "UPDATE users SET score = score + ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ii", $points, $userId);
        $stmt->execute();

        $this->checkForNewBadges($userId);
    }

    private function getPointsForAction($action) {
        $pointsMap = [
            'upload' => 10,
            'download' => 5,
            'rate' => 2,
            'comment' => 1
        ];

        return $pointsMap[$action] ?? 0;
    }

    public function getUserBadges($userId) {
        $sql = "SELECT b.* FROM user_badges ub
                JOIN badges b ON ub.badge_id = b.id
                WHERE ub.user_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getAllBadges() {
        $sql = "SELECT * FROM badges";
        $result = $this->db->query($sql);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    private function checkForNewBadges($userId) {
        $userStats = $this->getUserStats($userId);
        $allBadges = $this->getAllBadges();

        foreach ($allBadges as $badge) {
            if ($this->userQualifiesForBadge($userStats, $badge) && !$this->userHasBadge($userId, $badge['id'])) {
                $this->awardBadgeToUser($userId, $badge['id']);
            }
        }
    }

    private function userQualifiesForBadge($userStats, $badge) {
        $condition = $badge['condition'];
        $requirement = $badge['requirement'];

        return $userStats[$condition] >= $requirement;
    }

    private function userHasBadge($userId, $badgeId) {
        $sql = "SELECT * FROM user_badges WHERE user_id = ? AND badge_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ii", $userId, $badgeId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->num_rows > 0;
    }

    private function awardBadgeToUser($userId, $badgeId) {
        $sql = "INSERT INTO user_badges (user_id, badge_id, awarded_at) VALUES (?, ?, NOW())";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ii", $userId, $badgeId);
        $stmt->execute();
    }

    public function getTopUsers($limit = 10) {
        $sql = "SELECT u.id, u.username, u.score, COUNT(f.id) as uploads
                FROM users u
                LEFT JOIN files f ON u.id = f.user_id
                GROUP BY u.id
                ORDER BY u.score DESC
                LIMIT ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function getUserRank($userId) {
        $sql = "SELECT (SELECT COUNT(*) FROM users u2 WHERE u2.score > u1.score) + 1 AS rank
                FROM users u1
                WHERE u1.id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $rank = $result->fetch_assoc();
        return $rank['rank'];
    }

    public function getWeeklyChallenge() {
        $sql = "SELECT * FROM challenges WHERE type = 'weekly' AND start_date <= NOW() AND end_date > NOW() LIMIT 1";
        $result = $this->db->query($sql);
        return $result->fetch_assoc();
    }

    public function getDailyChallenge() {
        $sql = "SELECT * FROM challenges WHERE type = 'daily' AND DATE(start_date) = CURDATE() LIMIT 1";
        $result = $this->db->query($sql);
        return $result->fetch_assoc();
    }

    public function getUserChallengeProgress($userId, $challengeId) {
        $sql = "SELECT progress FROM user_challenges WHERE user_id = ? AND challenge_id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ii", $userId, $challengeId);
        $stmt->execute();
        $result = $stmt->get_result();
        $progress = $result->fetch_assoc();
        return $progress ? $progress['progress'] : 0;
    }

    public function updateChallengeProgress($userId, $challengeId, $action) {
        $sql = "INSERT INTO user_challenges (user_id, challenge_id, progress)
                VALUES (?, ?, 1)
                ON DUPLICATE KEY UPDATE progress = progress + 1";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ii", $userId, $challengeId);
        $stmt->execute();

        $this->checkChallengeCompletion($userId, $challengeId);
    }

    private function checkChallengeCompletion($userId, $challengeId) {
        $challenge = $this->getChallengeById($challengeId);
        $progress = $this->getUserChallengeProgress($userId, $challengeId);

        if ($progress >= $challenge['goal']) {
            $this->completeChallenge($userId, $challengeId);
        }
    }

    private function completeChallenge($userId, $challengeId) {
        $challenge = $this->getChallengeById($challengeId);
        $reward = $challenge['reward_tokens'];

        $sql = "UPDATE users SET download_tokens = download_tokens + ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ii", $reward, $userId);
        $stmt->execute();

        $this->updateUserScore($userId, 'challenge_complete');
    }

    private function getChallengeById($challengeId) {
        $sql = "SELECT * FROM challenges WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $challengeId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    public function claimDailyReward($userId) {
        $lastClaim = $this->getLastDailyRewardClaim($userId);
        
        if ($lastClaim && date('Y-m-d', strtotime($lastClaim)) === date('Y-m-d')) {
            return ['success' => false, 'message' => 'You have already claimed your daily reward today.'];
        }

        $tokens = $this->calculateDailyReward($userId);
        $this->updateUserTokens($userId, $tokens);
        $this->updateDailyRewardClaim($userId);

        return ['success' => true, 'tokens' => $tokens];
    }

    private function getLastDailyRewardClaim($userId) {
        $sql = "SELECT last_daily_reward FROM users WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        return $user['last_daily_reward'];
    }

    private function calculateDailyReward($userId) {
        $baseReward = 5;
        $streak = $this->getDailyRewardStreak($userId);
        return $baseReward + min($streak, 5);
    }

    private function getDailyRewardStreak($userId) {
        $sql = "SELECT daily_reward_streak FROM users WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        return $user['daily_reward_streak'];
    }

    private function updateUserTokens($userId, $tokens) {
        $sql = "UPDATE users SET download_tokens = download_tokens + ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("ii", $tokens, $userId);
        $stmt->execute();
    }

    private function updateDailyRewardClaim($userId) {
        $sql = "UPDATE users SET last_daily_reward = NOW(), daily_reward_streak = daily_reward_streak + 1 WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $userId);
        $stmt->execute();
    }
}

