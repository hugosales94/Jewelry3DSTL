<?php

namespace App\Models;
require_once dirname(__DIR__) . '/models/Database.php';

class Subscription {
    private $db;
    
    public function __construct() {
        $this->db = \Database::getInstance();
    }
    
    public static function create($data) {
        $db = \Database::getInstance();
        try {
            $db->beginTransaction();
            
            // Check if user already has an active subscription
            $activeSubscription = $db->query(
                "SELECT id FROM subscriptions 
                 WHERE user_id = ? AND status = 'active' AND end_date > NOW()",
                [$data['user_id']]
            )->fetch();
            
            if ($activeSubscription) {
                throw new \Exception('User already has an active subscription');
            }
            
            // Create subscription
            $db->query(
                "INSERT INTO subscriptions (
                    user_id, plan_id, status, start_date, end_date, 
                    payment_method, amount, currency, created_at
                ) VALUES (?, ?, ?, NOW(), ?, ?, ?, ?, NOW())",
                [
                    $data['user_id'],
                    $data['plan_id'],
                    'active',
                    date('Y-m-d H:i:s', strtotime('+1 month')),
                    $data['payment_method'],
                    $data['amount'],
                    $data['currency'] ?? 'USD'
                ]
            );
            
            $subscriptionId = $db->lastInsertId();
            
            // Create payment record
            $db->query(
                "INSERT INTO payments (
                    user_id, subscription_id, amount, currency, 
                    payment_method, status, transaction_id, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())",
                [
                    $data['user_id'],
                    $subscriptionId,
                    $data['amount'],
                    $data['currency'] ?? 'USD',
                    $data['payment_method'],
                    'completed',
                    $data['transaction_id']
                ]
            );
            
            // Update user role
            $db->query(
                "UPDATE users SET role = 'subscriber' WHERE id = ?",
                [$data['user_id']]
            );
            
            $db->commit();
            return $subscriptionId;
            
        } catch (\Exception $e) {
            $db->rollBack();
            error_log("Error creating subscription: " . $e->getMessage());
            throw new \Exception("Failed to create subscription: " . $e->getMessage());
        }
    }
    
    public static function cancel($id) {
        $db = \Database::getInstance();
        try {
            $db->beginTransaction();
            
            // Get subscription info
            $subscription = $db->query(
                "SELECT user_id FROM subscriptions WHERE id = ? AND status = 'active'",
                [$id]
            )->fetch();
            
            if (!$subscription) {
                throw new \Exception('Active subscription not found');
            }
            
            // Update subscription status
            $db->query(
                "UPDATE subscriptions SET 
                 status = 'cancelled',
                 cancelled_at = NOW()
                 WHERE id = ?",
                [$id]
            );
            
            // Check if user has other active subscriptions
            $activeSubscriptions = $db->query(
                "SELECT COUNT(*) as count 
                 FROM subscriptions 
                 WHERE user_id = ? AND status = 'active' AND end_date > NOW()",
                [$subscription['user_id']]
            )->fetch()['count'];
            
            // If no other active subscriptions, update user role
            if ($activeSubscriptions === 0) {
                $db->query(
                    "UPDATE users SET role = 'user' WHERE id = ?",
                    [$subscription['user_id']]
                );
            }
            
            $db->commit();
            return true;
            
        } catch (\Exception $e) {
            $db->rollBack();
            error_log("Error cancelling subscription: " . $e->getMessage());
            throw new \Exception("Failed to cancel subscription: " . $e->getMessage());
        }
    }
    
    public static function renew($id) {
        $db = \Database::getInstance();
        try {
            $db->beginTransaction();
            
            // Get subscription info
            $subscription = $db->query(
                "SELECT * FROM subscriptions WHERE id = ?",
                [$id]
            )->fetch();
            
            if (!$subscription) {
                throw new \Exception('Subscription not found');
            }
            
            // Create new subscription period
            $db->query(
                "INSERT INTO subscriptions (
                    user_id, plan_id, status, start_date, end_date,
                    payment_method, amount, currency, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())",
                [
                    $subscription['user_id'],
                    $subscription['plan_id'],
                    'active',
                    $subscription['end_date'], // Start from previous end date
                    date('Y-m-d H:i:s', strtotime($subscription['end_date'] . ' +1 month')),
                    $subscription['payment_method'],
                    $subscription['amount'],
                    $subscription['currency']
                ]
            );
            
            $newSubscriptionId = $db->lastInsertId();
            
            // Update user role if needed
            $db->query(
                "UPDATE users SET role = 'subscriber' WHERE id = ?",
                [$subscription['user_id']]
            );
            
            $db->commit();
            return $newSubscriptionId;
            
        } catch (\Exception $e) {
            $db->rollBack();
            error_log("Error renewing subscription: " . $e->getMessage());
            throw new \Exception("Failed to renew subscription: " . $e->getMessage());
        }
    }
    
    public static function getUserSubscriptions($userId) {
        $db = \Database::getInstance();
        try {
            return $db->query(
                "SELECT s.*, p.name as plan_name 
                 FROM subscriptions s
                 LEFT JOIN plans p ON s.plan_id = p.id
                 WHERE s.user_id = ?
                 ORDER BY s.created_at DESC",
                [$userId]
            )->fetchAll();
            
        } catch (\Exception $e) {
            error_log("Error getting user subscriptions: " . $e->getMessage());
            throw new \Exception("Failed to retrieve subscriptions.");
        }
    }
    
    public static function getActiveSubscription($userId) {
        $db = \Database::getInstance();
        try {
            return $db->query(
                "SELECT s.*, p.name as plan_name, p.features
                 FROM subscriptions s
                 LEFT JOIN plans p ON s.plan_id = p.id
                 WHERE s.user_id = ? 
                 AND s.status = 'active' 
                 AND s.end_date > NOW()
                 ORDER BY s.end_date DESC
                 LIMIT 1",
                [$userId]
            )->fetch();
            
        } catch (\Exception $e) {
            error_log("Error getting active subscription: " . $e->getMessage());
            throw new \Exception("Failed to retrieve active subscription.");
        }
    }
}