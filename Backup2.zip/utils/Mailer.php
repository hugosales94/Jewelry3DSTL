<?php

class Mailer {
    private static $from;
    private static $fromName;
    
    public static function init($fromAddress = null, $fromName = null) {
        self::$from = $fromAddress ?? MAIL_FROM_ADDRESS;
        self::$fromName = $fromName ?? MAIL_FROM_NAME;
    }
    
    public static function send($to, $subject, $body, $attachments = []) {
        try {
            // Generate a unique boundary
            $boundary = md5(uniqid(time()));
            
            // Headers
            $headers = [];
            $headers[] = "MIME-Version: 1.0";
            $headers[] = "From: " . self::$fromName . " <" . self::$from . ">";
            $headers[] = "Content-Type: multipart/mixed; boundary=\"" . $boundary . "\"";
            
            // Message body
            $message = "";
            
            // Add HTML part
            $message .= "--" . $boundary . "\r\n";
            $message .= "Content-Type: text/html; charset=UTF-8\r\n";
            $message .= "Content-Transfer-Encoding: base64\r\n\r\n";
            $message .= chunk_split(base64_encode($body)) . "\r\n";
            
            // Add attachments if any
            foreach ($attachments as $attachment) {
                if (file_exists($attachment['path'])) {
                    $message .= "--" . $boundary . "\r\n";
                    $message .= "Content-Type: " . $attachment['type'] . "; name=\"" . $attachment['name'] . "\"\r\n";
                    $message .= "Content-Disposition: attachment; filename=\"" . $attachment['name'] . "\"\r\n";
                    $message .= "Content-Transfer-Encoding: base64\r\n\r\n";
                    $message .= chunk_split(base64_encode(file_get_contents($attachment['path']))) . "\r\n";
                }
            }
            
            // End message
            $message .= "--" . $boundary . "--";
            
            // Log attempt
            error_log("Attempting to send email to: " . $to);
            error_log("Subject: " . $subject);
            
            // Send email
            $result = mail($to, $subject, $message, implode("\r\n", $headers));
            
            if (!$result) {
                throw new Exception("Failed to send email");
            }
            
            // Log success
            error_log("Email sent successfully to: " . $to);
            
            return true;
            
        } catch (Exception $e) {
            error_log("Error sending email: " . $e->getMessage());
            throw new Exception("Failed to send email: " . $e->getMessage());
        }
    }
    
    public static function sendTemplate($to, $subject, $template, $data = [], $attachments = []) {
        try {
            // Check if template exists
            $templatePath = dirname(__DIR__) . '/views/emails/' . $template . '.php';
            
            if (!file_exists($templatePath)) {
                throw new Exception("Email template not found: " . $template);
            }
            
            // Extract data for template
            extract($data);
            
            // Start output buffering
            ob_start();
            
            // Include template
            include $templatePath;
            
            // Get template content
            $body = ob_get_clean();
            
            // Send email with rendered template
            return self::send($to, $subject, $body, $attachments);
            
        } catch (Exception $e) {
            error_log("Error sending template email: " . $e->getMessage());
            throw new Exception("Failed to send template email: " . $e->getMessage());
        }
    }
    
    public static function validateEmail($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
}

// Initialize mailer with default settings
Mailer::init();