<?php

class Router {
    private $routes = [];

    public function addRoute($method, $path, $handler) {
        $this->routes[] = [
            'method' => $method,
            'path' => $path,
            'handler' => $handler
        ];
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

        foreach ($this->routes as $route) {
            if ($route['method'] === $method) {
                $pattern = '#^' . $route['path'] . '$#';
                if (preg_match($pattern, $path, $matches)) {
                    array_shift($matches);
                    call_user_func_array($route['handler'], $matches);
                    return;
                }
            }
        }

        // If no route matches, show 404 error
        header("HTTP/1.0 404 Not Found");
        echo "404 Not Found";
    }
}

