# Deployment Guide for STL Jewelry 3D on Hostinger

## Prerequisites
- A Hostinger shared hosting account
- FTP access to your Hostinger account
- MySQL database credentials

## Steps

1. Upload files:
   - Use FTP to upload all files and folders to your Hostinger account.
   - Ensure the `public_html` folder contains only the files that should be publicly accessible.

2. Set up the database:
   - Create a new MySQL database in your Hostinger control panel.
   - Import the `database_schema.sql` file to set up the database structure.

3. Configure environment variables:
   - In the Hostinger control panel, navigate to the PHP Options section.
   - Add the following environment variables:
     - DB_HOST
     - DB_USER
     - DB_PASS
     - DB_NAME
     - STRIPE_SECRET_KEY
     - STRIPE_PUBLISHABLE_KEY
     - STRIPE_WEBHOOK_SECRET

4. Update configuration files:
   - If necessary, update `src/config/database.php` with the correct database credentials.

5. Set file permissions:
   - Set the correct permissions for the `uploads` folder:

