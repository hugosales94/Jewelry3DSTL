<?php
require_once __DIR__ . '/../config/app_config.php';

try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    echo "Connected successfully to the database.";
    $conn->close();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

