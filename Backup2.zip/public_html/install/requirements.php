<?php
$requirements = [
    'php' => ['version' => '7.4.0', 'current' => PHP_VERSION],
    'extensions' => [
        'mysqli',
        'pdo_mysql',
        'gd',
        'zip'
    ],
    'writable_dirs' => [
        BASE_PATH . '/public_html/uploads',
        BASE_PATH . '/app/logs',
        BASE_PATH . '/app/cache'
    ]
];

$errors = [];

// Check PHP version
if (version_compare(PHP_VERSION, $requirements['php']['version'], '<')) {
    $errors[] = "PHP version must be at least {$requirements['php']['version']}. Current version is {$requirements['php']['current']}.";
}

// Check extensions
foreach ($requirements['extensions'] as $ext) {
    if (!extension_loaded($ext)) {
        $errors[] = "PHP extension {$ext} is not loaded.";
    }
}

// Check writable directories
foreach ($requirements['writable_dirs'] as $dir) {
    if (!is_writable($dir)) {
        $errors[] = "Directory {$dir} is not writable.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STL Jewelry 3D Installation - Requirements Check</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">System Requirements Check</h1>
        <?php if (empty($errors)): ?>
            <div class="alert alert-success">All requirements are met!</div>
            <a href="?step=database" class="btn btn-primary">Continue to Database Configuration</a>
        <?php else: ?>
            <div class="alert alert-danger">
                <h4>The following requirements are not met:</h4>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <p>Please fix these issues and refresh the page.</p>
        <?php endif; ?>
    </div>
</body>
</html>

