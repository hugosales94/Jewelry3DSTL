<?php
session_start();
define('BASE_PATH', dirname(__DIR__, 2));

if (file_exists(BASE_PATH . '/install.lock')) {
    header('Location: /');
    exit();
}

$step = $_GET['step'] ?? 'welcome';

switch ($step) {
    case 'welcome':
        require_once 'welcome.php';
        break;
    case 'requirements':
        require_once 'requirements.php';
        break;
    case 'database':
        require_once 'database.php';
        break;
    case 'finish':
        require_once 'finish.php';
        break;
    default:
        header('Location: ?step=welcome');
        exit();
}

