<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dbHost = $_POST['db_host'];
    $dbName = $_POST['db_name'];
    $dbUser = $_POST['db_user'];
    $dbPass = $_POST['db_pass'];

    // Test database connection
    try {
        $conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
        if ($conn->connect_error) {
            throw new Exception("Connection failed: " . $conn->connect_error);
        }
        $conn->close();

        // Update .env file with database credentials
        $envFile = BASE_PATH . '/.env';
        $envExample = BASE_PATH . '/.env.example';
        if (!file_exists($envFile) && file_exists($envExample)) {
            copy($envExample, $envFile);
        }
        $envContent = file_get_contents($envFile);
        $envContent = preg_replace('/DB_HOST=.*/', "DB_HOST={$dbHost}", $envContent);
        $envContent = preg_replace('/DB_NAME=.*/', "DB_NAME={$dbName}", $envContent);
        $envContent = preg_replace('/DB_USER=.*/', "DB_USER={$dbUser}", $envContent);
        $envContent = preg_replace('/DB_PASS=.*/', "DB_PASS={$dbPass}", $envContent);
        file_put_contents($envFile, $envContent);

        // Import database schema
        $schemaFile = BASE_PATH . '/database_schema.sql';
        $command = "mysql -h {$dbHost} -u {$dbUser} -p{$dbPass} {$dbName} < {$schemaFile}";
        exec($command, $output, $returnVar);

        if ($returnVar !== 0) {
            throw new Exception("Failed to import database schema.");
        }

        // Redirect to finish page
        header('Location: ?step=finish');
        exit();
    } catch (Exception $e) {
        $error = "Installation failed: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STL Jewelry 3D Installation - Database Configuration</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Database Configuration</h1>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form action="?step=database" method="post">
            <div class="mb-3">
                <label for="db_host" class="form-label">Database Host</label>
                <input type="text" class="form-control" id="db_host" name="db_host" required>
            </div>
            <div class="mb-3">
                <label for="db_name" class="form-label">Database Name</label>
                <input type="text" class="form-control" id="db_name" name="db_name" required>
            </div>
            <div class="mb-3">
                <label for="db_user" class="form-label">Database User</label>
                <input type="text" class="form-control" id="db_user" name="db_user" required>
            </div>
            <div class="mb-3">
                <label for="db_pass" class="form-label">Database Password</label>
                <input type="password" class="form-control" id="db_pass" name="db_pass" required>
            </div>
            <button type="submit" class="btn btn-primary">Finish Installation</button>
        </form>
    </div>
</body>
</html>

