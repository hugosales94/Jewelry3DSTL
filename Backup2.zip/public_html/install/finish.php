<?php
// Create install.lock file
file_put_contents(BASE_PATH . '/install.lock', date('Y-m-d H:i:s'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STL Jewelry 3D Installation - Finished</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Installation Complete</h1>
        <div class="alert alert-success">
            Congratulations! STL Jewelry 3D has been successfully installed.
        </div>
        <p>You can now access your website by clicking the button below:</p>
        <a href="/" class="btn btn-primary">Go to Homepage</a>
    </div>
</body>
</html>

