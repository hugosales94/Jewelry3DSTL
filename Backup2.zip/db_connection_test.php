<?php
require_once __DIR__ . '/config/app_config.php';
require_once __DIR__ . '/config/database.php';

if (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
    echo "Database connection successful!<br>";
    echo "Connected to MySQL server version: " . $conn->server_info . "<br>";
    echo "Database name: " . DB_NAME . "<br>";
    echo "Host: " . DB_HOST . "<br>";
} else {
    echo "Database connection failed!<br>";
    if (isset($conn)) {
        echo "Error: " . $conn->connect_error . "<br>";
    }
}

echo "<h2>Environment Variables:</h2>";
echo "<pre>";
print_r($_ENV);
echo "</pre>";

echo "<h2>Server Variables:</h2>";
echo "<pre>";
print_r($_SERVER);
echo "</pre>";

