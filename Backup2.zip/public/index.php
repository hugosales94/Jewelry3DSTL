<?php
session_start();

require_once BASE_PATH . '/src/controllers/InstallController.php';
$installController = new InstallController();

if (!$installController->isInstalled()) {
    $router->addRoute('GET', '/install', [$installController, 'showWelcome']);
    $router->addRoute('GET', '/install/requirements', [$installController, 'checkRequirements']);
    $router->addRoute('GET', '/install/database', [$installController, 'showDatabaseForm']);
    $router->addRoute('POST', '/install/finish', [$installController, 'configureDatabaseAndFinish']);

    if ($_SERVER['REQUEST_URI'] === '/') {
        header('Location: /install');
        exit();
    }
}

define('BASE_PATH', __DIR__ . '/..');
require_once BASE_PATH . '/vendor/autoload.php';
require_once BASE_PATH . '/src/utils/Router.php';
require_once BASE_PATH . '/src/controllers/AuthController.php';
require_once BASE_PATH . '/src/controllers/FileController.php';
require_once BASE_PATH . '/src/controllers/PaymentController.php';
require_once BASE_PATH . '/src/controllers/AdminController.php';
require_once BASE_PATH . '/src/controllers/MessageController.php';
require_once BASE_PATH . '/src/controllers/UserController.php';
require_once BASE_PATH . '/src/controllers/SubscriptionController.php';
require_once BASE_PATH . '/src/controllers/GamificationController.php';
require_once BASE_PATH . '/src/controllers/SpecialEventController.php';
require_once BASE_PATH . '/src/controllers/ReportController.php';
require_once BASE_PATH . '/src/controllers/NotificationController.php';
require_once BASE_PATH . '/src/controllers/OnboardingController.php';
require_once BASE_PATH . '/src/controllers/DashboardController.php';
require_once BASE_PATH . '/src/components/MetaTags.php';

$router = new Router();

// Main routes
$router->addRoute('GET', '/', [new MainController(), 'index']);
$router->addRoute('GET', '/dashboard', [new DashboardController(), 'index']);

// Authentication routes
$router->addRoute('GET', '/login', [new AuthController(), 'showLoginForm']);
$router->addRoute('POST', '/login', [new AuthController(), 'login']);
$router->addRoute('GET', '/register', [new AuthController(), 'showRegistrationForm']);
$router->addRoute('POST', '/register', [new AuthController(), 'register']);
$router->addRoute('GET', '/logout', [new AuthController(), 'logout']);

// File routes
$router->addRoute('GET', '/file/(\d+)', [new FileController(), 'view']);
$router->addRoute('GET', '/file/(\d+)/download', [new FileController(), 'download']);
$router->addRoute('POST', '/file/(\d+)/rate', [new FileController(), 'rate']);
$router->addRoute('GET', '/upload', [new FileController(), 'showUploadForm']);
$router->addRoute('POST', '/upload', [new FileController(), 'upload']);
$router->addRoute('GET', '/advanced-search', [new FileController(), 'advancedSearch']);

// User routes
$router->addRoute('GET', '/user/profile/(\d+)', [new UserController(), 'profile']);
$router->addRoute('POST', '/user/follow/(\d+)', [new UserController(), 'follow']);
$router->addRoute('POST', '/user/unfollow/(\d+)', [new UserController(), 'unfollow']);

// Message routes
$router->addRoute('GET', '/messages/inbox', [new MessageController(), 'inbox']);
$router->addRoute('GET', '/messages/sent', [new MessageController(), 'sent']);
$router->addRoute('GET', '/messages/view/(\d+)', [new MessageController(), 'view']);
$router->addRoute('GET', '/messages/compose', [new MessageController(), 'compose']);
$router->addRoute('POST', '/messages/compose', [new MessageController(), 'compose']);

// Gamification routes
$router->addRoute('GET', '/ranking', [new GamificationController(), 'showRanking']);
$router->addRoute('GET', '/achievements', [new GamificationController(), 'showAchievements']);
$router->addRoute('GET', '/challenges', [new GamificationController(), 'showChallenges']);
$router->addRoute('POST', '/daily-reward', [new GamificationController(), 'claimDailyReward']);

// Subscription routes
$router->addRoute('GET', '/subscription/plans', [new SubscriptionController(), 'showPlans']);
$router->addRoute('POST', '/subscription/subscribe', [new SubscriptionController(), 'subscribe']);
$router->addRoute('POST', '/subscription/cancel', [new SubscriptionController(), 'cancel']);

// Payment routes
$router->addRoute('POST', '/payment/process', [new PaymentController(), 'processPayment']);
$router->addRoute('GET', '/payment/success', [new PaymentController(), 'showSuccess']);
$router->addRoute('GET', '/payment/cancel', [new PaymentController(), 'showCancel']);

// Admin routes
$router->addRoute('GET', '/admin/dashboard', [new AdminController(), 'dashboard']);
$router->addRoute('GET', '/admin/user-management', [new AdminController(), 'userManagement']);
$router->addRoute('GET', '/admin/edit-user/(\d+)', [new AdminController(), 'editUser']);
$router->addRoute('POST', '/admin/edit-user/(\d+)', [new AdminController(), 'editUser']);
$router->addRoute('GET', '/admin/content-moderation', [new AdminController(), 'contentModeration']);
$router->addRoute('GET', '/admin/moderate-file/(\d+)', [new AdminController(), 'moderateFile']);
$router->addRoute('POST', '/admin/moderate-file/(\d+)', [new AdminController(), 'moderateFile']);
$router->addRoute('GET', '/admin/subscription-management', [new AdminController(), 'subscriptionManagement']);
$router->addRoute('GET', '/admin/edit-subscription/(\d+)', [new AdminController(), 'editSubscription']);
$router->addRoute('POST', '/admin/edit-subscription/(\d+)', [new AdminController(), 'editSubscription']);
$router->addRoute('GET', '/admin/reports', [new AdminController(), 'reports']);

// Special event routes
$router->addRoute('GET', '/special-event', [new SpecialEventController(), 'showCurrentEvent']);
$router->addRoute('POST', '/special-event/participate', [new SpecialEventController(), 'participate']);

// Report routes
$router->addRoute('POST', '/report/create', [new ReportController(), 'createReport']);
$router->addRoute('GET', '/admin/reports', [new ReportController(), 'listReports']);
$router->addRoute('GET', '/admin/handle-report/(\d+)', [new ReportController(), 'handleReport']);
$router->addRoute('POST', '/admin/handle-report/(\d+)', [new ReportController(), 'handleReport']);

// Notification routes
$router->addRoute('GET', '/notifications', [new NotificationController(), 'showAll']);
$router->addRoute('GET', '/notifications/unread', [new NotificationController(), 'getUnreadNotifications']);
$router->addRoute('POST', '/notifications/mark-as-read', [new NotificationController(), 'markAsRead']);

// Onboarding routes
$router->addRoute('GET', '/onboarding', [new OnboardingController(), 'showOnboarding']);
$router->addRoute('POST', '/onboarding/complete-step', [new OnboardingController(), 'completeStep']);

// Handle the route
$route = $_GET['route'] ?? '';
$action = $_GET['action'] ?? '';
$id = $_GET['id'] ?? null;

// Set up default meta tags
$defaultMetaTags = new MetaTags(
    "STL Jewelry 3D - Share and Discover 3D Jewelry Models",
    "Upload, download, and explore unique 3D jewelry designs. Join our community of designers and enthusiasts.",
    "3D jewelry, STL files, jewelry design, 3D modeling, 3D printing"
);

// Define specific meta tags for each route
switch ($route) {
    case 'file':
        if ($action === 'view' && $id) {
            $file = (new FileController())->getFileById($id);
            $metaTags = new MetaTags(
                $file['name'],
                "Explore the 3D jewelry design '{$file['name']}' by {$file['username']}. Download and print this amazing STL model.",
                "3D jewelry, {$file['name']}, {$file['category']}, STL, jewelry design",
                $file['thumbnail_url']
            );
        } elseif ($action === 'advancedSearch') {
            $metaTags = new MetaTags(
                "Advanced Search - STL Jewelry 3D",
                "Use our advanced search to find the best 3D jewelry models. Filter by category, price, and more.",
                "3D jewelry search, STL filter, jewelry models, advanced search"
            );
        }
        break;
    case 'user':
        if ($action === 'profile' && $id) {
            $user = (new UserController())->getUserById($id);
            $metaTags = new MetaTags(
                "{$user['username']}'s Profile - STL Jewelry 3D",
                "Explore {$user['username']}'s profile and designs on STL Jewelry 3D. See their creations and achievements.",
                "designer profile, {$user['username']}, 3D jewelry, STL portfolio"
            );
        }
        break;
    case 'onboarding':
        $metaTags = new MetaTags(
            "Get Started with STL Jewelry 3D",
            "Complete your onboarding process and start your journey with STL Jewelry 3D. Learn how to make the most of our platform.",
            "onboarding, tutorial, STL Jewelry 3D, getting started"
        );
        break;
    case 'dashboard':
        $metaTags = new MetaTags(
            "Your Dashboard - STL Jewelry 3D",
            "View your recent activities, popular designs, and personalized recommendations on STL Jewelry 3D.",
            "dashboard, 3D jewelry, user activity, popular designs, recommendations"
        );
        break;
    // Add more cases as needed for other routes
}

// Use default meta tags if no specific ones are defined
$metaTags = $metaTags ?? $defaultMetaTags;

$router->handleRequest();

