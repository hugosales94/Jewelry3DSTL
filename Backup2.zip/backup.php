<?php
// Configurações
$backupDir = __DIR__ . '/backups/';
$databaseName = 'your_database_name';
$databaseUser = 'your_database_user';
$databasePass = 'your_database_password';

// Cria o diretório de backup se não existir
if (!file_exists($backupDir)) {
    mkdir($backupDir, 0755, true);
}

// Nome do arquivo de backup
$backupFile = $backupDir . 'backup_' . date('Y-m-d_H-i-s') . '.sql.gz';

// Comando para fazer o backup do banco de dados
$command = "mysqldump -u$databaseUser -p$databasePass $databaseName | gzip > $backupFile";

// Executa o comando
system($command, $returnVar);

// Verifica se o backup foi bem-sucedido
if ($returnVar === 0) {
    echo "Backup criado com sucesso: $backupFile\n";
} else {
    echo "Erro ao criar o backup\n";
}

// Remove backups antigos (mantém apenas os últimos 7 dias)
$oldBackups = glob($backupDir . 'backup_*.sql.gz');
foreach ($oldBackups as $backup) {
    if (filemtime($backup) < time() - 7 * 24 * 60 * 60) {
        unlink($backup);
    }
}

